package com.scholarship.util;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Enterprise Password Utility providing:
 * 1. Cryptographically strong PBKDF2WithHmacSHA256 slow hashing (65,536 iterations).
 * 2. 16-byte random salt generation.
 * 3. Constant-time equality checks against timing attacks.
 * 4. Backward-compatible verification for legacy SHA-256 hashes.
 */
public class PasswordUtil {

    private static final Logger LOGGER = Logger.getLogger(PasswordUtil.class.getName());
    private static final SecureRandom RANDOM = new SecureRandom();

    private static final String ALGORITHM = "PBKDF2WithHmacSHA256";
    private static final int ITERATIONS = 65536;
    private static final int KEY_LENGTH = 256; // bits

    /**
     * Generates a 16-byte cryptographically secure random salt in hexadecimal format.
     */
    public static String generateSalt() {
        byte[] salt = new byte[16];
        RANDOM.nextBytes(salt);
        return bytesToHex(salt);
    }

    /**
     * Hashes a password using PBKDF2WithHmacSHA256 with provided salt.
     * Returns string formatted as: pbkdf2:65536:<salt>:<hexHash>
     */
    public static String hashPassword(String password, String salt) {
        if (password == null) {
            throw new IllegalArgumentException("Password cannot be null");
        }
        if (salt == null || salt.trim().isEmpty()) {
            salt = generateSalt();
        }
        try {
            PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt.getBytes(StandardCharsets.UTF_8), ITERATIONS, KEY_LENGTH);
            SecretKeyFactory skf = SecretKeyFactory.getInstance(ALGORITHM);
            byte[] hash = skf.generateSecret(spec).getEncoded();
            return "pbkdf2:" + ITERATIONS + ":" + salt + ":" + bytesToHex(hash);
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            LOGGER.log(Level.WARNING, "PBKDF2 not available, falling back to salted SHA-256", e);
            return hashSha256(password, salt);
        }
    }

    /**
     * Verifies raw password against stored hash (supports both PBKDF2 and legacy SHA-256).
     */
    public static boolean verifyPassword(String rawPassword, String storedHash, String salt) {
        if (rawPassword == null || storedHash == null) {
            return false;
        }

        // Check if stored hash is PBKDF2 formatted
        if (storedHash.startsWith("pbkdf2:")) {
            String[] parts = storedHash.split(":");
            if (parts.length == 4) {
                int iters = Integer.parseInt(parts[1]);
                String hashSalt = parts[2];
                String expectedHex = parts[3];
                try {
                    PBEKeySpec spec = new PBEKeySpec(rawPassword.toCharArray(), hashSalt.getBytes(StandardCharsets.UTF_8), iters, KEY_LENGTH);
                    SecretKeyFactory skf = SecretKeyFactory.getInstance(ALGORITHM);
                    byte[] testHash = skf.generateSecret(spec).getEncoded();
                    String actualHex = bytesToHex(testHash);
                    return constantTimeEquals(actualHex, expectedHex);
                } catch (Exception e) {
                    LOGGER.log(Level.SEVERE, "Error verifying PBKDF2 password", e);
                    return false;
                }
            }
        }

        // Fallback for legacy SHA-256 salted hashes
        if (salt != null && !salt.trim().isEmpty()) {
            String sha256Salted = hashSha256(rawPassword, salt);
            if (constantTimeEquals(sha256Salted, storedHash)) {
                return true;
            }
        }

        // Fallback for plain SHA-256 without salt (initial seed data)
        String sha256Plain = hashSha256(rawPassword, null);
        return constantTimeEquals(sha256Plain, storedHash);
    }

    /**
     * Checks if a stored password hash needs migration to PBKDF2.
     */
    public static boolean needsRehash(String storedHash) {
        return storedHash == null || !storedHash.startsWith("pbkdf2:");
    }

    /**
     * Legacy SHA-256 calculation for backward compatibility.
     */
    private static String hashSha256(String password, String salt) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            if (salt != null && !salt.trim().isEmpty()) {
                md.update(salt.getBytes(StandardCharsets.UTF_8));
            }
            byte[] hashed = md.digest(password.getBytes(StandardCharsets.UTF_8));
            return bytesToHex(hashed);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm missing", e);
        }
    }

    /**
     * Constant time string equality comparison to prevent timing attacks.
     */
    public static boolean constantTimeEquals(String a, String b) {
        if (a == null || b == null || a.length() != b.length()) {
            return false;
        }
        int result = 0;
        for (int i = 0; i < a.length(); i++) {
            result |= a.charAt(i) ^ b.charAt(i);
        }
        return result == 0;
    }

    public static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
}
