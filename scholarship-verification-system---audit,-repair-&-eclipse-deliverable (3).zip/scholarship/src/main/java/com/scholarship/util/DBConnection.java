package com.scholarship.util;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Enterprise Database Connection Manager for MySQL 8 and Apache Tomcat 9.
 * Handles property loading, driver registration, and resource cleanup.
 */
public class DBConnection {

    private static final Logger LOGGER = Logger.getLogger(DBConnection.class.getName());
    private static final Properties PROPS = new Properties();

    private static String dbDriver = "com.mysql.cj.jdbc.Driver";
    private static String dbUrl = "jdbc:mysql://localhost:3306/scholarship_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC&characterEncoding=UTF-8";
    private static String dbUser = "root";
    private static String dbPassword = "root";
    private static boolean driverLoaded = false;

    static {
        loadConfiguration();
        loadDriver();
    }

    private static void loadConfiguration() {
        try (InputStream in = DBConnection.class.getClassLoader().getResourceAsStream("db.properties")) {
            if (in != null) {
                PROPS.load(in);
                if (PROPS.getProperty("db.driver") != null) dbDriver = PROPS.getProperty("db.driver");
                if (PROPS.getProperty("db.url") != null) dbUrl = PROPS.getProperty("db.url");
                if (PROPS.getProperty("db.username") != null) dbUser = PROPS.getProperty("db.username");
                if (PROPS.getProperty("db.password") != null) dbPassword = PROPS.getProperty("db.password");
                LOGGER.info("DBConnection loaded configuration from db.properties");
            } else {
                LOGGER.warning("db.properties not found in classpath. Using default environment configuration.");
            }
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Failed reading db.properties. Falling back to environment defaults.", e);
        }

        // Support environment variable overrides for Cloud/Container deployment
        String envUrl = System.getenv("JDBC_DATABASE_URL");
        if (envUrl != null && !envUrl.trim().isEmpty()) dbUrl = envUrl;

        String envUser = System.getenv("JDBC_DATABASE_USERNAME");
        if (envUser != null && !envUser.trim().isEmpty()) dbUser = envUser;

        String envPass = System.getenv("JDBC_DATABASE_PASSWORD");
        if (envPass != null) dbPassword = envPass;
    }

    private static synchronized void loadDriver() {
        if (!driverLoaded) {
            try {
                Class.forName(dbDriver);
                driverLoaded = true;
                LOGGER.info("MySQL JDBC driver successfully loaded: " + dbDriver);
            } catch (ClassNotFoundException e) {
                try {
                    // Fallback to legacy driver name if newer CJ driver not found
                    Class.forName("com.mysql.jdbc.Driver");
                    driverLoaded = true;
                    LOGGER.info("Fallback MySQL JDBC driver loaded: com.mysql.jdbc.Driver");
                } catch (ClassNotFoundException ex) {
                    LOGGER.log(Level.SEVERE, "Could not load MySQL JDBC Driver: " + dbDriver, ex);
                }
            }
        }
    }

    /**
     * Obtains an active connection to the scholarship database.
     */
    public static Connection getConnection() throws SQLException {
        if (!driverLoaded) {
            loadDriver();
        }
        return DriverManager.getConnection(dbUrl, dbUser, dbPassword);
    }

    /**
     * Checks whether database server is currently reachable.
     */
    public static boolean isDatabaseReachable() {
        try (Connection conn = getConnection()) {
            return conn != null && !conn.isClosed();
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Safe resource closer for Statements, ResultSets, Connections.
     */
    public static void close(AutoCloseable... resources) {
        if (resources == null) return;
        for (AutoCloseable res : resources) {
            if (res != null) {
                try {
                    res.close();
                } catch (Exception e) {
                    LOGGER.log(Level.FINE, "Error closing database resource", e);
                }
            }
        }
    }

    /**
     * Rolls back a transaction quietly if active.
     */
    public static void rollback(Connection conn) {
        if (conn != null) {
            try {
                conn.rollback();
            } catch (SQLException e) {
                LOGGER.log(Level.WARNING, "Failed to rollback database transaction", e);
            }
        }
    }

    public static String getDbUrl() { return dbUrl; }
    public static String getDbUser() { return dbUser; }
}
