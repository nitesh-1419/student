package com.scholarship.util;

import java.io.File;
import java.io.InputStream;
import java.security.MessageDigest;

/**
 * File Security verification utility inspecting binary magic bytes,
 * calculating cryptographic hashes, and sanitizing paths against traversal attacks.
 */
public class FileSecurityUtil {

    private static final byte[] PDF_MAGIC = new byte[]{0x25, 0x50, 0x44, 0x46}; // %PDF
    private static final byte[] JPEG_MAGIC = new byte[]{(byte) 0xFF, (byte) 0xD8, (byte) 0xFF};
    private static final byte[] PNG_MAGIC = new byte[]{(byte) 0x89, 0x50, 0x4E, 0x47}; // .PNG

    /**
     * Validates that raw bytes match declared extension magic bytes signature.
     */
    public static boolean isValidSignature(byte[] headerBytes, String extension) {
        if (headerBytes == null || headerBytes.length < 4 || extension == null) {
            return false;
        }
        String ext = extension.toLowerCase().trim();
        if ("pdf".equals(ext)) {
            return matchPrefix(headerBytes, PDF_MAGIC);
        } else if ("jpg".equals(ext) || "jpeg".equals(ext)) {
            return matchPrefix(headerBytes, JPEG_MAGIC);
        } else if ("png".equals(ext)) {
            return matchPrefix(headerBytes, PNG_MAGIC);
        }
        return false;
    }

    private static boolean matchPrefix(byte[] data, byte[] magic) {
        if (data.length < magic.length) return false;
        for (int i = 0; i < magic.length; i++) {
            if (data[i] != magic[i]) return false;
        }
        return true;
    }

    /**
     * Sanitizes a user-supplied filename to prevent directory traversal attacks.
     */
    public static String sanitizeFilename(String filename) {
        if (filename == null) return "document";
        // Strip path components
        String name = new File(filename).getName();
        // Remove illegal characters
        return name.replaceAll("[^a-zA-Z0-9._-]", "_");
    }

    /**
     * Calculates SHA-256 hash of a byte array.
     */
    public static String calculateSha256(byte[] data) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(data);
            StringBuilder sb = new StringBuilder(digest.length * 2);
            for (byte b : digest) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            return "hash_error";
        }
    }
}
