package com.scholarship.util;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * In-memory brute-force defense utility tracking consecutive failed attempts.
 */
public class LoginThrottler {

    private static final int MAX_FAILED_ATTEMPTS = 5;
    private static final long LOCKOUT_DURATION_MS = 15 * 60 * 1000; // 15 minutes

    private static class AttemptRecord {
        int count;
        long lastAttemptTime;
        long lockedUntil;

        AttemptRecord() {
            this.count = 1;
            this.lastAttemptTime = System.currentTimeMillis();
            this.lockedUntil = 0;
        }
    }

    private static final Map<String, AttemptRecord> IP_ATTEMPTS = new ConcurrentHashMap<>();
    private static final Map<String, AttemptRecord> USER_ATTEMPTS = new ConcurrentHashMap<>();

    public static boolean isBlocked(String ipAddress, String username) {
        long now = System.currentTimeMillis();

        if (ipAddress != null && IP_ATTEMPTS.containsKey(ipAddress)) {
            AttemptRecord rec = IP_ATTEMPTS.get(ipAddress);
            if (rec.lockedUntil > now) return true;
            if (now - rec.lastAttemptTime > LOCKOUT_DURATION_MS) IP_ATTEMPTS.remove(ipAddress);
        }

        if (username != null && USER_ATTEMPTS.containsKey(username.toLowerCase())) {
            AttemptRecord rec = USER_ATTEMPTS.get(username.toLowerCase());
            if (rec.lockedUntil > now) return true;
            if (now - rec.lastAttemptTime > LOCKOUT_DURATION_MS) USER_ATTEMPTS.remove(username.toLowerCase());
        }

        return false;
    }

    public static void recordFailedAttempt(String ipAddress, String username) {
        long now = System.currentTimeMillis();

        if (ipAddress != null) {
            IP_ATTEMPTS.compute(ipAddress, (k, v) -> {
                if (v == null || (now - v.lastAttemptTime > LOCKOUT_DURATION_MS)) {
                    return new AttemptRecord();
                }
                v.count++;
                v.lastAttemptTime = now;
                if (v.count >= MAX_FAILED_ATTEMPTS) {
                    v.lockedUntil = now + LOCKOUT_DURATION_MS;
                }
                return v;
            });
        }

        if (username != null) {
            USER_ATTEMPTS.compute(username.toLowerCase(), (k, v) -> {
                if (v == null || (now - v.lastAttemptTime > LOCKOUT_DURATION_MS)) {
                    return new AttemptRecord();
                }
                v.count++;
                v.lastAttemptTime = now;
                if (v.count >= MAX_FAILED_ATTEMPTS) {
                    v.lockedUntil = now + LOCKOUT_DURATION_MS;
                }
                return v;
            });
        }
    }

    public static void recordSuccessfulLogin(String ipAddress, String username) {
        if (ipAddress != null) IP_ATTEMPTS.remove(ipAddress);
        if (username != null) USER_ATTEMPTS.remove(username.toLowerCase());
    }
}
