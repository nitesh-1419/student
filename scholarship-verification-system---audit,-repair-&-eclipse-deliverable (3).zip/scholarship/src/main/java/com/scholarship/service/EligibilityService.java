package com.scholarship.service;

import com.scholarship.model.Scholarship;
import com.scholarship.model.Student;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Service that calculates student scholarship eligibility score and criteria compliance.
 */
public class EligibilityService {

    public static class EligibilityResult {
        private boolean eligible;
        private BigDecimal score; // 0 - 100
        private List<String> passedCriteria = new ArrayList<>();
        private List<String> failedCriteria = new ArrayList<>();
        private String summary;

        public boolean isEligible() { return eligible; }
        public void setEligible(boolean eligible) { this.eligible = eligible; }

        public BigDecimal getScore() { return score; }
        public void setScore(BigDecimal score) { this.score = score; }

        public List<String> getPassedCriteria() { return passedCriteria; }
        public List<String> getFailedCriteria() { return failedCriteria; }

        public String getSummary() { return summary; }
        public void setSummary(String summary) { this.summary = summary; }
    }

    /**
     * Evaluates whether a student meets the criteria for a specified scholarship.
     */
    public EligibilityResult evaluate(Student student, Scholarship scholarship) {
        EligibilityResult res = new EligibilityResult();
        if (student == null || scholarship == null) {
            res.setEligible(false);
            res.setScore(BigDecimal.ZERO);
            res.setSummary("Student profile or scholarship data missing.");
            return res;
        }

        boolean gpaPassed = false;
        boolean incomePassed = false;
        boolean categoryPassed = false;
        boolean deadlinePassed = false;

        // 1. GPA Evaluation
        if (student.getCurrentGpa() != null && scholarship.getMinGpa() != null) {
            if (student.getCurrentGpa().compareTo(scholarship.getMinGpa()) >= 0) {
                gpaPassed = true;
                res.getPassedCriteria().add("GPA " + student.getCurrentGpa() + " meets minimum required " + scholarship.getMinGpa());
            } else {
                res.getFailedCriteria().add("GPA " + student.getCurrentGpa() + " is below minimum required " + scholarship.getMinGpa());
            }
        }

        // 2. Family Income Evaluation
        if (student.getAnnualFamilyIncome() != null && scholarship.getMaxAnnualIncome() != null) {
            if (student.getAnnualFamilyIncome().compareTo(scholarship.getMaxAnnualIncome()) <= 0) {
                incomePassed = true;
                res.getPassedCriteria().add("Family income INR " + student.getAnnualFamilyIncome() + " within limit INR " + scholarship.getMaxAnnualIncome());
            } else {
                res.getFailedCriteria().add("Family income INR " + student.getAnnualFamilyIncome() + " exceeds ceiling INR " + scholarship.getMaxAnnualIncome());
            }
        }

        // 3. Category / Reservation Evaluation
        String allowed = scholarship.getEligibleCategories() != null ? scholarship.getEligibleCategories().toUpperCase() : "ALL";
        if (allowed.contains("ALL") || (student.getCategory() != null && allowed.contains(student.getCategory().toUpperCase()))) {
            categoryPassed = true;
            res.getPassedCriteria().add("Social category (" + student.getCategory() + ") is eligible under " + allowed);
        } else {
            res.getFailedCriteria().add("Social category (" + student.getCategory() + ") is not eligible under " + allowed);
        }

        // 4. Deadline Evaluation
        Date deadline = scholarship.getDeadline();
        if (deadline != null) {
            LocalDate deadlineDate = deadline.toLocalDate();
            LocalDate today = LocalDate.now();
            if (!today.isAfter(deadlineDate)) {
                deadlinePassed = true;
                res.getPassedCriteria().add("Application submitted before deadline " + deadline);
            } else {
                res.getFailedCriteria().add("Scholarship deadline " + deadline + " has expired");
            }
        } else {
            deadlinePassed = true;
        }

        boolean overallEligible = gpaPassed && incomePassed && categoryPassed && deadlinePassed;
        res.setEligible(overallEligible);

        // Calculate weighted score: 60% Merit (GPA) + 40% Financial Need (Inverse Income)
        double gpaWeight = 60.0;
        double incomeWeight = 40.0;

        double gpaComponent = 0.0;
        if (student.getCurrentGpa() != null) {
            double gpaVal = student.getCurrentGpa().doubleValue();
            gpaComponent = Math.min(100.0, (gpaVal / 4.0) * 100.0) * (gpaWeight / 100.0);
        }

        double incomeComponent = 0.0;
        if (student.getAnnualFamilyIncome() != null && scholarship.getMaxAnnualIncome() != null) {
            double income = student.getAnnualFamilyIncome().doubleValue();
            double maxInc = scholarship.getMaxAnnualIncome().doubleValue();
            if (maxInc > 0) {
                double needRatio = Math.max(0.0, 1.0 - (income / maxInc));
                incomeComponent = (needRatio * 100.0) * (incomeWeight / 100.0);
            }
        }

        double totalScore = gpaComponent + incomeComponent;
        if (!overallEligible) {
            totalScore = Math.min(totalScore, 49.0); // Cap at 49% if hard criteria failed
        }

        res.setScore(BigDecimal.valueOf(totalScore).setScale(2, RoundingMode.HALF_UP));
        res.setSummary(overallEligible ?
            "Candidate qualifies with eligibility score " + res.getScore() + "%." :
            "Candidate does not meet eligibility threshold: " + String.join("; ", res.getFailedCriteria()));

        return res;
    }
}
