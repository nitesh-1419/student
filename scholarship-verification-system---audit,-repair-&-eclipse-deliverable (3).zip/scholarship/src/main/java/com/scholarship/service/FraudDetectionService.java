package com.scholarship.service;

import com.scholarship.dao.FraudFlagDAO;
import com.scholarship.model.Application;
import com.scholarship.model.Document;
import com.scholarship.model.FraudFlag;
import com.scholarship.model.Scholarship;
import com.scholarship.model.Student;
import com.scholarship.util.DBConnection;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Enterprise Fraud Detection and Risk Assistance Service.
 * Evaluates duplicate document hashes across students, banking anomalies,
 * income inconsistencies, and saves explainable risk factors to fraud_flags table.
 */
public class FraudDetectionService {

    private static final Logger LOGGER = Logger.getLogger(FraudDetectionService.class.getName());
    private final FraudFlagDAO fraudFlagDAO = new FraudFlagDAO();

    public static class FraudResult {
        private BigDecimal riskScore; // 0 - 100
        private String riskLevel; // 'LOW', 'MEDIUM', 'HIGH'
        private List<String> flaggedFactors = new ArrayList<>();
        private List<FraudFlag> detailedFlags = new ArrayList<>();
        private String summary;

        public BigDecimal getRiskScore() { return riskScore; }
        public void setRiskScore(BigDecimal riskScore) { this.riskScore = riskScore; }

        public String getRiskLevel() { return riskLevel; }
        public void setRiskLevel(String riskLevel) { this.riskLevel = riskLevel; }

        public List<String> getFlaggedFactors() { return flaggedFactors; }
        public List<FraudFlag> getDetailedFlags() { return detailedFlags; }

        public String getSummary() { return summary; }
        public void setSummary(String summary) { this.summary = summary; }
    }

    public FraudResult analyze(Application app, Student student, Scholarship scholarship, List<Document> documents) {
        FraudResult res = new FraudResult();
        double riskAccumulator = 0.0;

        if (student == null) {
            res.setRiskScore(BigDecimal.valueOf(100.0));
            res.setRiskLevel("HIGH");
            res.getFlaggedFactors().add("Student academic profile missing.");
            return res;
        }

        // Rule 1: Mandatory Documents Completion
        if (scholarship != null && scholarship.getRequiredDocs() != null) {
            String[] req = scholarship.getRequiredDocs().split(",");
            for (String r : req) {
                String type = r.trim();
                boolean found = false;
                if (documents != null) {
                    for (Document d : documents) {
                        if (type.equalsIgnoreCase(d.getDocType())) {
                            found = true;
                            break;
                        }
                    }
                }
                if (!found) {
                    riskAccumulator += 15.0;
                    String factor = "Missing Mandatory Document: " + type;
                    res.getFlaggedFactors().add(factor);
                    if (app != null && app.getId() > 0) {
                        res.getDetailedFlags().add(new FraudFlag(app.getId(), "MISSING_DOC", factor, "MEDIUM"));
                    }
                }
            }
        }

        // Rule 2: Duplicate Document Hash Cross-Check (detects file reuse across different students)
        if (documents != null) {
            for (Document d : documents) {
                if (d.getFileHash() != null && !d.getFileHash().isEmpty()) {
                    boolean duplicateFound = checkDuplicateHashAcrossStudents(d.getFileHash(), student.getId());
                    if (duplicateFound) {
                        riskAccumulator += 40.0;
                        String factor = "Duplicate File Hash: " + d.getFileName() + " matches a document previously submitted by another student.";
                        res.getFlaggedFactors().add(factor);
                        if (app != null && app.getId() > 0) {
                            res.getDetailedFlags().add(new FraudFlag(app.getId(), "DUPLICATE_FILE_HASH", factor, "HIGH"));
                        }
                    }
                }

                // Check previously flagged / rejected documents
                if ("REJECTED".equalsIgnoreCase(d.getVerificationStatus())) {
                    riskAccumulator += 20.0;
                    String factor = "Document Flagged by Officer: " + d.getFileName() + " (" + (d.getRejectionReason() != null ? d.getRejectionReason() : "Discrepancy") + ")";
                    res.getFlaggedFactors().add(factor);
                    if (app != null && app.getId() > 0) {
                        res.getDetailedFlags().add(new FraudFlag(app.getId(), "OFFICER_REJECTED_DOC", factor, "MEDIUM"));
                    }
                }
            }
        }

        // Rule 3: Banking & Identity Details Validation
        if (student.getBankAccountNo() == null || student.getBankAccountNo().trim().length() < 9) {
            riskAccumulator += 15.0;
            String factor = "Bank Account Discrepancy: Account number invalid or too short.";
            res.getFlaggedFactors().add(factor);
            if (app != null && app.getId() > 0) {
                res.getDetailedFlags().add(new FraudFlag(app.getId(), "INVALID_BANK_ACC", factor, "MEDIUM"));
            }
        }

        if (student.getIfscCode() == null || !student.getIfscCode().matches("^[A-Z]{4}0[A-Z0-9]{6}$")) {
            riskAccumulator += 10.0;
            String factor = "IFSC Code Validation Failed: Must follow standard 11-character format (4 letters, 0, 6 alphanumeric).";
            res.getFlaggedFactors().add(factor);
            if (app != null && app.getId() > 0) {
                res.getDetailedFlags().add(new FraudFlag(app.getId(), "INVALID_IFSC", factor, "LOW"));
            }
        }

        // Rule 4: Income anomaly (zero income declared)
        if (student.getAnnualFamilyIncome() != null && student.getAnnualFamilyIncome().compareTo(BigDecimal.ZERO) <= 0) {
            riskAccumulator += 20.0;
            String factor = "Economic Anomaly: Declared family income is 0; requires manual revenue inspection.";
            res.getFlaggedFactors().add(factor);
            if (app != null && app.getId() > 0) {
                res.getDetailedFlags().add(new FraudFlag(app.getId(), "ZERO_INCOME_ANOMALY", factor, "MEDIUM"));
            }
        }

        double finalScore = Math.min(100.0, Math.max(0.0, riskAccumulator));
        res.setRiskScore(BigDecimal.valueOf(finalScore).setScale(2, RoundingMode.HALF_UP));

        if (finalScore >= 50.0) {
            res.setRiskLevel("HIGH");
            res.setSummary("High Risk: Application displays critical risk flags that require thorough officer verification.");
        } else if (finalScore >= 20.0) {
            res.setRiskLevel("MEDIUM");
            res.setSummary("Medium Risk: Some non-compliance flags detected. Manual document inspection recommended.");
        } else {
            res.setRiskLevel("LOW");
            res.setSummary("Low Risk: Standard application with consistent documentation.");
        }

        // Persist detailed flags to database if application exists
        if (app != null && app.getId() > 0 && !res.getDetailedFlags().isEmpty()) {
            for (FraudFlag flag : res.getDetailedFlags()) {
                fraudFlagDAO.recordFlag(flag);
            }
        }

        return res;
    }

    private boolean checkDuplicateHashAcrossStudents(String fileHash, int currentStudentId) {
        String sql = "SELECT 1 FROM documents WHERE file_hash = ? AND student_id != ? LIMIT 1";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, fileHash);
            ps.setInt(2, currentStudentId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, "Error checking duplicate hash across students", e);
        }
        return false;
    }
}
