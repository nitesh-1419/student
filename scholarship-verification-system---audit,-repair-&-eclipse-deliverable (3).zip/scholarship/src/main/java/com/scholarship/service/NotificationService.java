package com.scholarship.service;

import com.scholarship.dao.NotificationDAO;
import com.scholarship.dao.UserDAO;
import com.scholarship.model.Notification;
import com.scholarship.model.User;

import java.util.logging.Logger;

/**
 * Service managing in-app notifications and email dispatch triggers.
 */
public class NotificationService {

    private static final Logger LOGGER = Logger.getLogger(NotificationService.class.getName());

    private final NotificationDAO notificationDAO = new NotificationDAO();
    private final UserDAO userDAO = new UserDAO();
    private final EmailService emailService = new EmailService();

    public void notifyStatusChange(int userId, String applicationNo, String newStatus, String remarks) {
        String title;
        String message;
        String type;

        switch (newStatus.toUpperCase()) {
            case "APPROVED":
                title = "🎉 Scholarship Application Approved!";
                message = "Congratulations! Your application (" + applicationNo + ") has been approved. Remarks: " + remarks;
                type = "SUCCESS";
                break;
            case "REJECTED":
                title = "Application Update: Rejected";
                message = "Your scholarship application (" + applicationNo + ") was not approved. Reason: " + remarks;
                type = "DANGER";
                break;
            case "RESUBMISSION_REQUESTED":
                title = "⚠️ Action Required: Document Correction";
                message = "The verification officer has requested changes for application " + applicationNo + ". Remarks: " + remarks;
                type = "WARNING";
                break;
            case "UNDER_REVIEW":
                title = "Application Under Active Review";
                message = "Your application (" + applicationNo + ") is currently being reviewed by our verification officer.";
                type = "INFO";
                break;
            default:
                title = "Application Status: " + newStatus;
                message = "Your application (" + applicationNo + ") status is now " + newStatus + ".";
                type = "INFO";
        }

        Notification notification = new Notification(userId, title, message, type, "student/tracking");
        notificationDAO.createNotification(notification);

        // Trigger email notification safely
        User user = userDAO.findById(userId);
        if (user != null && user.getEmail() != null) {
            emailService.sendAsync(user.getEmail(), title, message);
        }
    }

    public void notifyOfficerNewSubmission(int officerUserId, String applicationNo, String studentName) {
        String title = "New Scholarship Submission";
        String message = "Candidate " + studentName + " submitted application " + applicationNo + " for review.";
        Notification notification = new Notification(officerUserId, title, message, "INFO", "officer/dashboard");
        notificationDAO.createNotification(notification);
    }
}
