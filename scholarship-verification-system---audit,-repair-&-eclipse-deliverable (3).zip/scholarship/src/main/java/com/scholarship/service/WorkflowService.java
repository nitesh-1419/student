package com.scholarship.service;

import com.scholarship.dao.ApplicationDAO;
import com.scholarship.dao.StatusHistoryDAO;
import com.scholarship.dao.StudentDAO;
import com.scholarship.dao.VerificationDAO;
import com.scholarship.model.Application;
import com.scholarship.model.AuditLog;
import com.scholarship.model.Student;
import com.scholarship.model.User;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Logger;

/**
 * Enterprise Application Workflow Service governing state transitions,
 * status history logs, and automatic student notifications.
 */
public class WorkflowService {

    private static final Logger LOGGER = Logger.getLogger(WorkflowService.class.getName());

    private final ApplicationDAO applicationDAO = new ApplicationDAO();
    private final VerificationDAO verificationDAO = new VerificationDAO();
    private final StatusHistoryDAO statusHistoryDAO = new StatusHistoryDAO();
    private final StudentDAO studentDAO = new StudentDAO();
    private final NotificationService notificationService = new NotificationService();

    private static final Set<String> ALLOWED_TRANSITIONS = new HashSet<>(Arrays.asList(
        "DRAFT->SUBMITTED",
        "SUBMITTED->UNDER_REVIEW",
        "UNDER_REVIEW->APPROVED",
        "UNDER_REVIEW->REJECTED",
        "UNDER_REVIEW->RESUBMISSION_REQUESTED",
        "RESUBMISSION_REQUESTED->SUBMITTED",
        "SUBMITTED->RESUBMISSION_REQUESTED"
    ));

    public boolean canTransition(String currentStatus, String targetStatus) {
        if (currentStatus == null || targetStatus == null) return false;
        if (currentStatus.equalsIgnoreCase(targetStatus)) return true;
        return ALLOWED_TRANSITIONS.contains(currentStatus.toUpperCase() + "->" + targetStatus.toUpperCase());
    }

    public boolean transition(int applicationId, String targetStatus, String remarks, User operator, String ipAddress) throws SQLException {
        Application app = applicationDAO.findById(applicationId);
        if (app == null) {
            throw new IllegalArgumentException("Application not found with ID: " + applicationId);
        }

        String currentStatus = app.getStatus();
        if (!canTransition(currentStatus, targetStatus)) {
            throw new IllegalStateException("Illegal workflow transition from " + currentStatus + " to " + targetStatus);
        }

        // Authorization checks
        if (("APPROVED".equalsIgnoreCase(targetStatus) || "REJECTED".equalsIgnoreCase(targetStatus) || "RESUBMISSION_REQUESTED".equalsIgnoreCase(targetStatus))
                && (operator == null || operator.isStudent())) {
            throw new SecurityException("Students are unauthorized to approve, reject, or request resubmission on applications.");
        }

        Integer verifiedBy = operator != null ? operator.getId() : null;
        boolean updated = applicationDAO.updateStatus(applicationId, targetStatus, remarks, verifiedBy);

        if (updated) {
            // 1. Record transition in Status History table
            statusHistoryDAO.recordTransition(applicationId, currentStatus, targetStatus, verifiedBy, remarks);

            // 2. Record immutable security Audit Log
            AuditLog audit = new AuditLog();
            audit.setUserId(verifiedBy);
            audit.setAction("STATUS_CHANGE_" + targetStatus);
            audit.setEntityType("APPLICATION");
            audit.setEntityId(applicationId);
            audit.setDetails("Transitioned application " + app.getApplicationNo() + " from " + currentStatus + " to " + targetStatus + ". Remarks: " + remarks);
            audit.setIpAddress(ipAddress != null ? ipAddress : "127.0.0.1");
            verificationDAO.recordAudit(audit);

            // 3. Send in-app notification to the applicant
            Student student = studentDAO.findById(app.getStudentId());
            if (student != null) {
                notificationService.notifyStatusChange(student.getUserId(), app.getApplicationNo(), targetStatus, remarks);
            }

            LOGGER.info("Application " + applicationId + " (" + app.getApplicationNo() + ") moved to " + targetStatus);
        }

        return updated;
    }
}
