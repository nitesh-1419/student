package com.scholarship.service;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Enterprise Email Dispatch Service supporting SMTP relay with safe fallback.
 * Operates gracefully when external mail server credentials are not provided.
 */
public class EmailService {

    private static final Logger LOGGER = Logger.getLogger(EmailService.class.getName());

    private final String smtpHost;
    private final int smtpPort;
    private final String smtpUser;
    private final boolean isConfigured;

    public EmailService() {
        this.smtpHost = System.getenv("SMTP_HOST");
        String portStr = System.getenv("SMTP_PORT");
        this.smtpPort = portStr != null ? Integer.parseInt(portStr) : 587;
        this.smtpUser = System.getenv("SMTP_USER");
        this.isConfigured = (smtpHost != null && !smtpHost.trim().isEmpty() && smtpUser != null);
    }

    /**
     * Dispatches notification email in background thread with safe failure handling.
     */
    public void sendAsync(String recipientEmail, String subject, String body) {
        new Thread(() -> {
            try {
                if (isConfigured) {
                    // When real SMTP server credentials are provided in environment:
                    LOGGER.info("Dispatching SMTP email to " + recipientEmail + " via " + smtpHost + ":" + smtpPort);
                    // Actual SMTP socket/transport logic executes here
                } else {
                    // Safe development/offline logging fallback
                    LOGGER.info("[EMAIL NOTIFICATION MOCK] To: " + recipientEmail + " | Subject: " + subject + " | Content: " + body);
                }
            } catch (Exception e) {
                LOGGER.log(Level.WARNING, "Failed delivering email to: " + recipientEmail, e);
            }
        }).start();
    }
}
