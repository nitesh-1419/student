package com.scholarship.servlet;

import com.scholarship.dao.ApplicationDAO;
import com.scholarship.dao.DocumentDAO;
import com.scholarship.dao.ScholarshipDAO;
import com.scholarship.dao.StudentDAO;
import com.scholarship.dao.VerificationDAO;
import com.scholarship.model.Application;
import com.scholarship.model.AuditLog;
import com.scholarship.model.Document;
import com.scholarship.model.Scholarship;
import com.scholarship.model.Student;
import com.scholarship.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

/**
 * Verification Officer Workbench Servlet providing review queue, verification inspection,
 * fraud alerts, and administrative dashboards.
 */
@WebServlet(name = "OfficerDashboardServlet", urlPatterns = {"/officer/dashboard"})
public class OfficerDashboardServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(OfficerDashboardServlet.class.getName());

    private final ApplicationDAO applicationDAO = new ApplicationDAO();
    private final DocumentDAO documentDAO = new DocumentDAO();
    private final StudentDAO studentDAO = new StudentDAO();
    private final ScholarshipDAO scholarshipDAO = new ScholarshipDAO();
    private final VerificationDAO verificationDAO = new VerificationDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("currentUser") : null;
        if (user == null || (!user.isOfficer() && !user.isAdmin())) {
            resp.sendRedirect(req.getContextPath() + "/index.jsp?error=unauthorized");
            return;
        }

        // Summary counts
        Map<String, Integer> stats = new HashMap<>();
        stats.put("total", applicationDAO.countTotal());
        stats.put("submitted", applicationDAO.countByStatus("SUBMITTED"));
        stats.put("under_review", applicationDAO.countByStatus("UNDER_REVIEW"));
        stats.put("approved", applicationDAO.countByStatus("APPROVED"));
        stats.put("rejected", applicationDAO.countByStatus("REJECTED"));
        stats.put("resubmit", applicationDAO.countByStatus("RESUBMISSION_REQUESTED"));
        req.setAttribute("stats", stats);

        // Filter status
        String statusFilter = req.getParameter("status");
        List<Application> applications = applicationDAO.listAllForOfficer(statusFilter);
        req.setAttribute("applications", applications);
        req.setAttribute("currentFilter", statusFilter != null ? statusFilter : "ALL");

        // Single application inspection
        String appIdParam = req.getParameter("reviewAppId");
        if (appIdParam != null && !appIdParam.trim().isEmpty()) {
            try {
                int reviewId = Integer.parseInt(appIdParam);
                Application app = applicationDAO.findById(reviewId);
                if (app != null) {
                    List<Document> docs = documentDAO.findByApplicationId(reviewId);
                    app.setDocuments(docs);
                    Student student = studentDAO.findById(app.getStudentId());
                    Scholarship scholarship = scholarshipDAO.findById(app.getScholarshipId());
                    req.setAttribute("selectedApp", app);
                    req.setAttribute("selectedStudent", student);
                    req.setAttribute("selectedScholarship", scholarship);

                    // Auto transition from SUBMITTED to UNDER_REVIEW when opened by officer
                    if ("SUBMITTED".equalsIgnoreCase(app.getStatus())) {
                        applicationDAO.updateStatus(reviewId, "UNDER_REVIEW", "Review commenced by " + user.getFullName(), user.getId());
                        app.setStatus("UNDER_REVIEW");
                    }
                }
            } catch (Exception e) {
                LOGGER.warning("Error fetching review application: " + e.getMessage());
            }
        }

        // Recent audit logs
        List<AuditLog> recentAudits = verificationDAO.listRecent(20);
        req.setAttribute("recentAudits", recentAudits);

        req.getRequestDispatcher("/officer/dashboard.jsp").forward(req, resp);
    }
}
