package com.scholarship.servlet;

import com.scholarship.dao.NotificationDAO;
import com.scholarship.model.Notification;
import com.scholarship.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

/**
 * Servlet providing in-app notification querying and read status updates.
 */
@WebServlet(name = "NotificationServlet", urlPatterns = {"/notifications", "/notifications/read"})
public class NotificationServlet extends HttpServlet {

    private final NotificationDAO notificationDAO = new NotificationDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("currentUser") : null;
        if (user == null) {
            resp.sendError(HttpServletResponse.SC_UNAUTHORIZED);
            return;
        }

        List<Notification> list = notificationDAO.findByUserId(user.getId(), 30);
        req.setAttribute("notifications", list);
        req.getRequestDispatcher("/student/notifications.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("currentUser") : null;
        if (user == null) {
            resp.sendError(HttpServletResponse.SC_UNAUTHORIZED);
            return;
        }

        String notifIdStr = req.getParameter("id");
        if (notifIdStr != null && !notifIdStr.trim().isEmpty()) {
            try {
                int id = Integer.parseInt(notifIdStr);
                notificationDAO.markAsRead(id, user.getId());
            } catch (NumberFormatException ignored) {}
        } else {
            notificationDAO.markAllAsRead(user.getId());
        }

        String referer = req.getHeader("Referer");
        resp.sendRedirect(referer != null ? referer : req.getContextPath() + "/student/dashboard");
    }
}
