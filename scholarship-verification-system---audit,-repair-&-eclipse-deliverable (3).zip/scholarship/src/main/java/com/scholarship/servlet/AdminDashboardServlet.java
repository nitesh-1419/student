package com.scholarship.servlet;

import com.scholarship.dao.ReportDAO;
import com.scholarship.dao.ScholarshipDAO;
import com.scholarship.dao.UserDAO;
import com.scholarship.dao.VerificationDAO;
import com.scholarship.model.ReportSummary;
import com.scholarship.model.Scholarship;
import com.scholarship.model.User;
import com.scholarship.util.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Administrative Controller providing system metrics, user governance,
 * scholarship scheme authoring, and runtime diagnostics.
 */
@WebServlet(name = "AdminDashboardServlet", urlPatterns = {"/admin/dashboard", "/admin/scholarships", "/admin/users", "/admin/diagnostics"})
public class AdminDashboardServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(AdminDashboardServlet.class.getName());

    private final ReportDAO reportDAO = new ReportDAO();
    private final ScholarshipDAO scholarshipDAO = new ScholarshipDAO();
    private final UserDAO userDAO = new UserDAO();
    private final VerificationDAO verificationDAO = new VerificationDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("currentUser") : null;
        if (user == null || !user.isAdmin()) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN, "Access Denied: Administrator privileges required.");
            return;
        }

        String path = req.getServletPath();

        if ("/admin/diagnostics".equals(path)) {
            handleDiagnostics(req, resp);
            return;
        }

        if ("/admin/users".equals(path)) {
            List<User> users = userDAO.listAll();
            req.setAttribute("usersList", users);
            req.getRequestDispatcher("/admin/dashboard.jsp?view=users").forward(req, resp);
            return;
        }

        if ("/admin/scholarships".equals(path)) {
            List<Scholarship> scholarships = scholarshipDAO.listAll();
            req.setAttribute("scholarshipsList", scholarships);
            req.getRequestDispatcher("/admin/dashboard.jsp?view=scholarships").forward(req, resp);
            return;
        }

        // Default: /admin/dashboard overview
        ReportSummary summary = reportDAO.getSummary();
        req.setAttribute("summary", summary);
        req.setAttribute("scholarshipsList", scholarshipDAO.listAll());
        req.setAttribute("usersList", userDAO.listAll());
        req.setAttribute("recentAudits", verificationDAO.listRecent(25));

        req.getRequestDispatcher("/admin/dashboard.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("currentUser") : null;
        if (user == null || !user.isAdmin()) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN, "Unauthorized.");
            return;
        }

        String action = req.getParameter("action");

        try {
            if ("create_scholarship".equalsIgnoreCase(action)) {
                Scholarship s = new Scholarship();
                s.setCode(req.getParameter("code"));
                s.setTitle(req.getParameter("title"));
                s.setDescription(req.getParameter("description"));
                s.setSponsor(req.getParameter("sponsor"));
                s.setAmount(new BigDecimal(req.getParameter("amount")));
                s.setMinGpa(new BigDecimal(req.getParameter("minGpa")));
                s.setMaxAnnualIncome(new BigDecimal(req.getParameter("maxIncome")));
                s.setEligibleCategories(req.getParameter("categories"));
                s.setDeadline(Date.valueOf(req.getParameter("deadline")));
                s.setTotalSlots(Integer.parseInt(req.getParameter("slots")));
                s.setStatus("ACTIVE");
                s.setRequiredDocs(req.getParameter("requiredDocs"));

                scholarshipDAO.createScholarship(s);
                resp.sendRedirect(req.getContextPath() + "/admin/dashboard?view=scholarships&created=true");
                return;
            }
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error handling admin action: " + action, e);
            resp.sendRedirect(req.getContextPath() + "/admin/dashboard?error=" + e.getMessage());
        }
    }

    private void handleDiagnostics(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Runtime rt = Runtime.getRuntime();
        long totalMem = rt.totalMemory() / (1024 * 1024);
        long freeMem = rt.freeMemory() / (1024 * 1024);
        long maxMem = rt.maxMemory() / (1024 * 1024);

        req.setAttribute("jvmVersion", System.getProperty("java.version"));
        req.setAttribute("jvmVendor", System.getProperty("java.vendor"));
        req.setAttribute("osName", System.getProperty("os.name"));
        req.setAttribute("totalMemoryMb", totalMem);
        req.setAttribute("freeMemoryMb", freeMem);
        req.setAttribute("maxMemoryMb", maxMem);
        req.setAttribute("dbConnected", DBConnection.isDatabaseReachable());
        req.setAttribute("dbUrl", DBConnection.getDbUrl());
        req.setAttribute("dbUser", DBConnection.getDbUser());

        req.getRequestDispatcher("/admin/dashboard.jsp?view=diagnostics").forward(req, resp);
    }
}
