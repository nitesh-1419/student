package com.scholarship.servlet;

import com.scholarship.dao.ApplicationDAO;
import com.scholarship.dao.DocumentDAO;
import com.scholarship.dao.ScholarshipDAO;
import com.scholarship.dao.StudentDAO;
import com.scholarship.dao.VerificationDAO;
import com.scholarship.model.Application;
import com.scholarship.model.AuditLog;
import com.scholarship.model.Document;
import com.scholarship.model.Scholarship;
import com.scholarship.model.Student;
import com.scholarship.model.User;
import com.scholarship.service.FraudDetectionService;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Servlet handling secure multipart document uploads, checksum generation, and risk re-evaluation.
 */
@WebServlet(name = "DocumentUploadServlet", urlPatterns = {"/student/uploadDocument"})
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 1, // 1 MB buffer
    maxFileSize = 1024 * 1024 * 10,      // 10 MB maximum file size
    maxRequestSize = 1024 * 1024 * 25    // 25 MB max request size
)
public class DocumentUploadServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(DocumentUploadServlet.class.getName());

    private static final Set<String> ALLOWED_EXTENSIONS = new HashSet<>(Arrays.asList("pdf", "jpg", "jpeg", "png"));
    private static final Set<String> ALLOWED_MIME_TYPES = new HashSet<>(Arrays.asList(
        "application/pdf", "image/jpeg", "image/png"
    ));

    private final DocumentDAO documentDAO = new DocumentDAO();
    private final ApplicationDAO applicationDAO = new ApplicationDAO();
    private final StudentDAO studentDAO = new StudentDAO();
    private final ScholarshipDAO scholarshipDAO = new ScholarshipDAO();
    private final VerificationDAO verificationDAO = new VerificationDAO();
    private final FraudDetectionService fraudDetectionService = new FraudDetectionService();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("currentUser") : null;
        if (user == null) {
            resp.sendRedirect(req.getContextPath() + "/index.jsp");
            return;
        }

        Student student = studentDAO.findByUserId(user.getId());
        if (student == null) {
            resp.sendRedirect(req.getContextPath() + "/student/dashboard?error=profile_required");
            return;
        }

        String appIdStr = req.getParameter("applicationId");
        String docType = req.getParameter("docType");

        if (appIdStr == null || docType == null) {
            resp.sendRedirect(req.getContextPath() + "/student/dashboard?error=missing_params");
            return;
        }

        int applicationId;
        try {
            applicationId = Integer.parseInt(appIdStr);
        } catch (NumberFormatException e) {
            resp.sendRedirect(req.getContextPath() + "/student/dashboard?error=invalid_id");
            return;
        }

        Application app = applicationDAO.findById(applicationId);
        if (app == null || app.getStudentId() != student.getId()) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN, "Unauthorized: Application does not belong to you.");
            return;
        }

        Part filePart = req.getPart("documentFile");
        if (filePart == null || filePart.getSize() <= 0) {
            resp.sendRedirect(req.getContextPath() + "/student/tracking?appId=" + applicationId + "&error=empty_file");
            return;
        }

        String submittedFileName = getFileName(filePart);
        String extension = getFileExtension(submittedFileName).toLowerCase();

        if (!ALLOWED_EXTENSIONS.contains(extension)) {
            resp.sendRedirect(req.getContextPath() + "/student/tracking?appId=" + applicationId + "&error=invalid_extension");
            return;
        }

        String mimeType = filePart.getContentType();
        if (mimeType == null || !ALLOWED_MIME_TYPES.contains(mimeType.toLowerCase())) {
            // Also allow standard octet stream if extension is pdf
            if (!("pdf".equals(extension) && "application/octet-stream".equals(mimeType))) {
                resp.sendRedirect(req.getContextPath() + "/student/tracking?appId=" + applicationId + "&error=invalid_mime");
                return;
            }
        }

        try {
            // Read stream and compute SHA-256 hash
            byte[] fileBytes;
            try (InputStream is = filePart.getInputStream()) {
                fileBytes = is.readAllBytes();
            }

            String fileHash = computeHash(fileBytes);

            // Safe storage directory
            String uploadDir = req.getServletContext().getRealPath("/uploads/docs");
            if (uploadDir == null) {
                uploadDir = System.getProperty("java.io.tmpdir") + File.separator + "scholarship_uploads";
            }
            File dir = new File(uploadDir);
            if (!dir.exists()) {
                dir.mkdirs();
            }

            String sanitizedSafeName = "doc_" + applicationId + "_" + docType + "_" + UUID.randomUUID().toString().substring(0, 8) + "." + extension;
            File targetFile = new File(dir, sanitizedSafeName);

            Files.write(targetFile.toPath(), fileBytes);

            Document doc = new Document();
            doc.setApplicationId(applicationId);
            doc.setStudentId(student.getId());
            doc.setDocType(docType);
            doc.setFileName(submittedFileName);
            doc.setFilePath("uploads/docs/" + sanitizedSafeName);
            doc.setFileSize(fileBytes.length);
            doc.setMimeType(mimeType != null ? mimeType : "application/octet-stream");
            doc.setFileHash(fileHash);
            doc.setVerificationStatus("PENDING");

            documentDAO.saveDocument(doc);

            // Re-evaluate fraud risk score with updated documents
            List<Document> allDocs = documentDAO.findByApplicationId(applicationId);
            Scholarship scholarship = scholarshipDAO.findById(app.getScholarshipId());
            FraudDetectionService.FraudResult fraud = fraudDetectionService.analyze(app, student, scholarship, allDocs);

            applicationDAO.updateEligibilityAndFraud(applicationId, app.getEligibilityScore(),
                fraud.getRiskScore(), fraud.getRiskLevel(), String.join("; ", fraud.getFlaggedFactors()));

            // Audit
            AuditLog audit = new AuditLog();
            audit.setUserId(user.getId());
            audit.setAction("UPLOAD_DOCUMENT");
            audit.setEntityType("DOCUMENT");
            audit.setEntityId(doc.getId());
            audit.setDetails("Uploaded document " + submittedFileName + " (" + docType + ") for application " + app.getApplicationNo());
            audit.setIpAddress(req.getRemoteAddr());
            verificationDAO.recordAudit(audit);

            resp.sendRedirect(req.getContextPath() + "/student/tracking?appId=" + applicationId + "&upload_success=true");

        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Database error saving document", e);
            resp.sendRedirect(req.getContextPath() + "/student/tracking?appId=" + applicationId + "&error=db_error");
        }
    }

    private String getFileName(Part part) {
        String contentDisp = part.getHeader("content-disposition");
        if (contentDisp != null) {
            for (String token : contentDisp.split(";")) {
                if (token.trim().startsWith("filename")) {
                    String fn = token.substring(token.indexOf('=') + 1).trim().replace("\"", "");
                    // Handle full path sent by IE/Edge
                    return new File(fn).getName();
                }
            }
        }
        return "document.pdf";
    }

    private String getFileExtension(String name) {
        if (name == null || !name.contains(".")) return "";
        return name.substring(name.lastIndexOf('.') + 1);
    }

    private String computeHash(byte[] bytes) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(bytes);
            StringBuilder sb = new StringBuilder();
            for (byte b : digest) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            return "hash_" + System.currentTimeMillis();
        }
    }
}
