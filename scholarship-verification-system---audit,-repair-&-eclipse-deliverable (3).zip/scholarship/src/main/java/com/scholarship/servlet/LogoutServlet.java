package com.scholarship.servlet;

import com.scholarship.dao.VerificationDAO;
import com.scholarship.model.AuditLog;
import com.scholarship.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Logout Servlet invalidating authenticated sessions and redirecting safely.
 */
@WebServlet(name = "LogoutServlet", urlPatterns = {"/logout"})
public class LogoutServlet extends HttpServlet {

    private final VerificationDAO verificationDAO = new VerificationDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        if (session != null) {
            User user = (User) session.getAttribute("currentUser");
            if (user != null) {
                AuditLog audit = new AuditLog();
                audit.setUserId(user.getId());
                audit.setAction("LOGOUT");
                audit.setEntityType("USER");
                audit.setEntityId(user.getId());
                audit.setDetails("User logged out");
                audit.setIpAddress(req.getRemoteAddr());
                verificationDAO.recordAudit(audit);
            }
            session.invalidate();
        }
        resp.sendRedirect(req.getContextPath() + "/index.jsp?logged_out=true");
    }
}
