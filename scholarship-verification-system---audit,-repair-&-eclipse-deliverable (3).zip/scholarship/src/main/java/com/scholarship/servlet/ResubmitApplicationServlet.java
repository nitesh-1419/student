package com.scholarship.servlet;

import com.scholarship.dao.ApplicationDAO;
import com.scholarship.dao.DocumentDAO;
import com.scholarship.dao.ScholarshipDAO;
import com.scholarship.dao.StudentDAO;
import com.scholarship.model.Application;
import com.scholarship.model.Document;
import com.scholarship.model.Scholarship;
import com.scholarship.model.Student;
import com.scholarship.model.User;
import com.scholarship.service.FraudDetectionService;
import com.scholarship.service.WorkflowService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Servlet allowing students to resubmit their application after addressing officer feedback.
 */
@WebServlet(name = "ResubmitApplicationServlet", urlPatterns = {"/student/resubmit"})
public class ResubmitApplicationServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(ResubmitApplicationServlet.class.getName());

    private final ApplicationDAO applicationDAO = new ApplicationDAO();
    private final StudentDAO studentDAO = new StudentDAO();
    private final DocumentDAO documentDAO = new DocumentDAO();
    private final ScholarshipDAO scholarshipDAO = new ScholarshipDAO();
    private final WorkflowService workflowService = new WorkflowService();
    private final FraudDetectionService fraudDetectionService = new FraudDetectionService();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("currentUser") : null;
        if (user == null) {
            resp.sendRedirect(req.getContextPath() + "/index.jsp");
            return;
        }

        Student student = studentDAO.findByUserId(user.getId());
        String appIdStr = req.getParameter("applicationId");

        if (student == null || appIdStr == null) {
            resp.sendRedirect(req.getContextPath() + "/student/dashboard?error=invalid_request");
            return;
        }

        try {
            int appId = Integer.parseInt(appIdStr);
            Application app = applicationDAO.findById(appId);
            if (app == null || app.getStudentId() != student.getId()) {
                resp.sendError(HttpServletResponse.SC_FORBIDDEN, "Unauthorized application access.");
                return;
            }

            if (!"RESUBMISSION_REQUESTED".equalsIgnoreCase(app.getStatus())) {
                resp.sendRedirect(req.getContextPath() + "/student/tracking?appId=" + appId + "&error=not_in_resubmit_state");
                return;
            }

            // Recalculate fraud risk
            List<Document> docs = documentDAO.findByApplicationId(appId);
            Scholarship scholarship = scholarshipDAO.findById(app.getScholarshipId());
            FraudDetectionService.FraudResult fraud = fraudDetectionService.analyze(app, student, scholarship, docs);
            applicationDAO.updateEligibilityAndFraud(appId, app.getEligibilityScore(),
                fraud.getRiskScore(), fraud.getRiskLevel(), String.join("; ", fraud.getFlaggedFactors()));

            String studentNotes = req.getParameter("studentNotes");
            String remarks = "Student resubmitted application with updated documentation. Notes: " +
                             (studentNotes != null ? studentNotes : "None");

            workflowService.transition(appId, "SUBMITTED", remarks, user, req.getRemoteAddr());

            resp.sendRedirect(req.getContextPath() + "/student/tracking?appId=" + appId + "&resubmitted=true");

        } catch (SQLException | NumberFormatException e) {
            LOGGER.log(Level.SEVERE, "Error resubmitting application", e);
            resp.sendRedirect(req.getContextPath() + "/student/dashboard?error=resubmit_failed");
        }
    }
}
