package com.scholarship.servlet;

import com.scholarship.dao.StudentDAO;
import com.scholarship.dao.UserDAO;
import com.scholarship.dao.VerificationDAO;
import com.scholarship.model.AuditLog;
import com.scholarship.model.Student;
import com.scholarship.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Authentication Servlet for user login and student registration.
 */
@WebServlet(name = "LoginServlet", urlPatterns = {"/login", "/register"})
public class LoginServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(LoginServlet.class.getName());

    private final UserDAO userDAO = new UserDAO();
    private final StudentDAO studentDAO = new StudentDAO();
    private final VerificationDAO verificationDAO = new VerificationDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        if (session != null && session.getAttribute("currentUser") != null) {
            User user = (User) session.getAttribute("currentUser");
            redirectToDashboard(user, req, resp);
            return;
        }
        req.getRequestDispatcher("/index.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String servletPath = req.getServletPath();

        if ("/register".equals(servletPath) || "register".equalsIgnoreCase(req.getParameter("action"))) {
            handleRegistration(req, resp);
        } else {
            handleLogin(req, resp);
        }
    }

    private void handleLogin(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username = req.getParameter("username");
        String password = req.getParameter("password");

        if (username == null || username.trim().isEmpty() || password == null || password.trim().isEmpty()) {
            req.setAttribute("errorMessage", "Username and password are required.");
            req.getRequestDispatcher("/index.jsp").forward(req, resp);
            return;
        }

        User user = userDAO.authenticate(username.trim(), password);
        if (user == null) {
            req.setAttribute("errorMessage", "Invalid credentials or account is suspended.");
            req.getRequestDispatcher("/index.jsp").forward(req, resp);
            return;
        }

        // Establish secure authenticated session
        HttpSession oldSession = req.getSession(false);
        if (oldSession != null) {
            oldSession.invalidate(); // Prevent session fixation
        }
        HttpSession newSession = req.getSession(true);
        newSession.setAttribute("currentUser", user);

        // Record audit
        AuditLog audit = new AuditLog();
        audit.setUserId(user.getId());
        audit.setAction("LOGIN_SUCCESS");
        audit.setEntityType("USER");
        audit.setEntityId(user.getId());
        audit.setDetails("User logged in with role: " + user.getRole());
        audit.setIpAddress(req.getRemoteAddr());
        verificationDAO.recordAudit(audit);

        // Check if redirectUrl exists
        String redirect = (String) newSession.getAttribute("redirectUrl");
        if (redirect != null && !redirect.trim().isEmpty()) {
            newSession.removeAttribute("redirectUrl");
            resp.sendRedirect(redirect);
        } else {
            redirectToDashboard(user, req, resp);
        }
    }

    private void handleRegistration(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String email = req.getParameter("email");
        String fullName = req.getParameter("fullName");
        String phone = req.getParameter("phone");
        String rollNumber = req.getParameter("rollNumber");
        String department = req.getParameter("department");
        String course = req.getParameter("course");
        String yearStr = req.getParameter("yearOfStudy");
        String gpaStr = req.getParameter("currentGpa");
        String incomeStr = req.getParameter("annualFamilyIncome");
        String category = req.getParameter("category");

        if (username == null || password == null || email == null || fullName == null ||
            username.trim().isEmpty() || password.length() < 6 || email.trim().isEmpty()) {
            req.setAttribute("regErrorMessage", "Please complete all required fields. Password must be at least 6 characters.");
            req.getRequestDispatcher("/index.jsp").forward(req, resp);
            return;
        }

        if (userDAO.isUsernameTaken(username.trim())) {
            req.setAttribute("regErrorMessage", "Username '" + username + "' is already registered.");
            req.getRequestDispatcher("/index.jsp").forward(req, resp);
            return;
        }

        if (userDAO.isEmailTaken(email.trim())) {
            req.setAttribute("regErrorMessage", "Email address '" + email + "' is already associated with an account.");
            req.getRequestDispatcher("/index.jsp").forward(req, resp);
            return;
        }

        try {
            User newUser = new User();
            newUser.setUsername(username.trim());
            newUser.setEmail(email.trim());
            newUser.setFullName(fullName.trim());
            newUser.setPhone(phone);
            newUser.setRole("STUDENT");

            int userId = userDAO.createUser(newUser, password);
            if (userId > 0) {
                // Create Student Profile
                Student student = new Student();
                student.setUserId(userId);
                student.setRollNumber(rollNumber != null && !rollNumber.trim().isEmpty() ? rollNumber.trim() : "STU-" + userId);
                student.setDepartment(department != null ? department.trim() : "General Studies");
                student.setCourse(course != null ? course.trim() : "Undergraduate");
                student.setYearOfStudy(yearStr != null ? Integer.parseInt(yearStr) : 1);
                student.setCurrentGpa(gpaStr != null ? new BigDecimal(gpaStr) : new BigDecimal("3.50"));
                student.setAnnualFamilyIncome(incomeStr != null ? new BigDecimal(incomeStr) : new BigDecimal("250000.00"));
                student.setCategory(category != null ? category : "GENERAL");
                studentDAO.createOrUpdate(student);

                // Auto login after registration
                HttpSession session = req.getSession(true);
                session.setAttribute("currentUser", newUser);

                AuditLog log = new AuditLog();
                log.setUserId(userId);
                log.setAction("STUDENT_REGISTERED");
                log.setEntityType("STUDENT");
                log.setEntityId(userId);
                log.setDetails("New student registered: " + username);
                log.setIpAddress(req.getRemoteAddr());
                verificationDAO.recordAudit(log);

                resp.sendRedirect(req.getContextPath() + "/student/dashboard?registered=true");
                return;
            } else {
                req.setAttribute("regErrorMessage", "Registration could not be completed. Please try again.");
                req.getRequestDispatcher("/index.jsp").forward(req, resp);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Database error during registration", e);
            req.setAttribute("regErrorMessage", "Database registration error: " + e.getMessage());
            req.getRequestDispatcher("/index.jsp").forward(req, resp);
        }
    }

    private void redirectToDashboard(User user, HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String ctx = req.getContextPath();
        if ("OFFICER".equalsIgnoreCase(user.getRole())) {
            resp.sendRedirect(ctx + "/officer/dashboard");
        } else if ("ADMIN".equalsIgnoreCase(user.getRole())) {
            resp.sendRedirect(ctx + "/officer/dashboard?view=admin");
        } else {
            resp.sendRedirect(ctx + "/student/dashboard");
        }
    }
}
