package com.scholarship.servlet;

import com.scholarship.dao.ApplicationDAO;
import com.scholarship.dao.DocumentDAO;
import com.scholarship.dao.ScholarshipDAO;
import com.scholarship.dao.StudentDAO;
import com.scholarship.dao.VerificationDAO;
import com.scholarship.model.Application;
import com.scholarship.model.AuditLog;
import com.scholarship.model.Document;
import com.scholarship.model.Scholarship;
import com.scholarship.model.Student;
import com.scholarship.model.User;
import com.scholarship.service.EligibilityService;
import com.scholarship.service.FraudDetectionService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.time.Year;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Servlet managing student dashboard, scholarship application submission, and status tracking.
 */
@WebServlet(name = "ApplicationServlet", urlPatterns = {"/student/dashboard", "/student/apply", "/student/tracking"})
public class ApplicationServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(ApplicationServlet.class.getName());

    private final ApplicationDAO applicationDAO = new ApplicationDAO();
    private final ScholarshipDAO scholarshipDAO = new ScholarshipDAO();
    private final StudentDAO studentDAO = new StudentDAO();
    private final DocumentDAO documentDAO = new DocumentDAO();
    private final VerificationDAO verificationDAO = new VerificationDAO();

    private final EligibilityService eligibilityService = new EligibilityService();
    private final FraudDetectionService fraudDetectionService = new FraudDetectionService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("currentUser") : null;
        if (user == null) {
            resp.sendRedirect(req.getContextPath() + "/index.jsp");
            return;
        }

        Student student = studentDAO.findByUserId(user.getId());
        req.setAttribute("studentProfile", student);

        String path = req.getServletPath();

        if ("/student/apply".equals(path)) {
            String scholarshipIdStr = req.getParameter("id");
            if (scholarshipIdStr != null && !scholarshipIdStr.trim().isEmpty()) {
                try {
                    int schId = Integer.parseInt(scholarshipIdStr);
                    Scholarship scholarship = scholarshipDAO.findById(schId);
                    req.setAttribute("scholarship", scholarship);

                    if (student != null && scholarship != null) {
                        EligibilityService.EligibilityResult elig = eligibilityService.evaluate(student, scholarship);
                        req.setAttribute("eligibilityResult", elig);
                    }
                } catch (NumberFormatException e) {
                    LOGGER.warning("Invalid scholarship id in apply: " + scholarshipIdStr);
                }
            }
            req.setAttribute("scholarshipsList", scholarshipDAO.listActive());
            req.getRequestDispatcher("/student/apply.jsp").forward(req, resp);

        } else if ("/student/tracking".equals(path)) {
            String appIdStr = req.getParameter("appId");
            if (appIdStr != null && !appIdStr.trim().isEmpty()) {
                try {
                    int appId = Integer.parseInt(appIdStr);
                    Application app = applicationDAO.findById(appId);
                    if (app != null && (student != null && app.getStudentId() == student.getId())) {
                        List<Document> docs = documentDAO.findByApplicationId(appId);
                        app.setDocuments(docs);
                        req.setAttribute("application", app);
                    }
                } catch (NumberFormatException e) {
                    LOGGER.warning("Invalid application id in tracking: " + appIdStr);
                }
            }
            if (student != null) {
                req.setAttribute("studentApplications", applicationDAO.findByStudentId(student.getId()));
            }
            req.getRequestDispatcher("/student/tracking.jsp").forward(req, resp);

        } else {
            // Default: /student/dashboard
            if (student != null) {
                List<Application> apps = applicationDAO.findByStudentId(student.getId());
                req.setAttribute("myApplications", apps);
            } else {
                req.setAttribute("myApplications", Collections.emptyList());
            }
            req.setAttribute("activeScholarships", scholarshipDAO.listActive());
            req.getRequestDispatcher("/student/dashboard.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("currentUser") : null;
        if (user == null) {
            resp.sendRedirect(req.getContextPath() + "/index.jsp");
            return;
        }

        Student student = studentDAO.findByUserId(user.getId());
        if (student == null) {
            req.setAttribute("errorMessage", "Please complete your student profile before submitting applications.");
            doGet(req, resp);
            return;
        }

        String scholarshipIdStr = req.getParameter("scholarshipId");
        if (scholarshipIdStr == null || scholarshipIdStr.trim().isEmpty()) {
            req.setAttribute("errorMessage", "No scholarship selected.");
            doGet(req, resp);
            return;
        }

        try {
            int schId = Integer.parseInt(scholarshipIdStr);
            Scholarship scholarship = scholarshipDAO.findById(schId);
            if (scholarship == null || !scholarship.isActive()) {
                req.setAttribute("errorMessage", "Selected scholarship is not currently accepting applications.");
                doGet(req, resp);
                return;
            }

            if (applicationDAO.hasStudentApplied(student.getId(), schId)) {
                req.setAttribute("errorMessage", "You have already applied for this scholarship.");
                doGet(req, resp);
                return;
            }

            // Run automated eligibility engine
            EligibilityService.EligibilityResult elig = eligibilityService.evaluate(student, scholarship);

            // Generate official application number
            String appNo = "APP-" + Year.now().getValue() + "-" + (1000 + (int)(Math.random() * 9000));

            Application newApp = new Application();
            newApp.setApplicationNo(appNo);
            newApp.setStudentId(student.getId());
            newApp.setScholarshipId(schId);
            newApp.setStatus("SUBMITTED");
            newApp.setEligibilityScore(elig.getScore());

            // Run initial fraud risk engine
            FraudDetectionService.FraudResult fraud = fraudDetectionService.analyze(newApp, student, scholarship, Collections.emptyList());
            newApp.setFraudRiskScore(fraud.getRiskScore());
            newApp.setFraudRiskLevel(fraud.getRiskLevel());
            newApp.setFlaggedReasons(String.join("; ", fraud.getFlaggedFactors()));

            int createdId = applicationDAO.createApplication(newApp);
            if (createdId > 0) {
                // Record audit log
                AuditLog log = new AuditLog();
                log.setUserId(user.getId());
                log.setAction("SUBMIT_APPLICATION");
                log.setEntityType("APPLICATION");
                log.setEntityId(createdId);
                log.setDetails("Submitted scholarship application " + appNo + " for " + scholarship.getTitle());
                log.setIpAddress(req.getRemoteAddr());
                verificationDAO.recordAudit(log);

                resp.sendRedirect(req.getContextPath() + "/student/tracking?appId=" + createdId + "&submitted=true");
            } else {
                req.setAttribute("errorMessage", "Application could not be created. Please try again.");
                doGet(req, resp);
            }

        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Database error during application submission", e);
            req.setAttribute("errorMessage", "Database error: " + e.getMessage());
            doGet(req, resp);
        }
    }
}
