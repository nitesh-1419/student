package com.scholarship.servlet;

import com.scholarship.dao.ReportDAO;
import com.scholarship.dao.ScholarshipDAO;
import com.scholarship.model.ReportSummary;
import com.scholarship.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.List;

/**
 * Reporting and CSV Export Controller for Administrative intelligence.
 */
@WebServlet(name = "ReportServlet", urlPatterns = {"/admin/reports", "/admin/reports/export-csv"})
public class ReportServlet extends HttpServlet {

    private final ReportDAO reportDAO = new ReportDAO();
    private final ScholarshipDAO scholarshipDAO = new ScholarshipDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("currentUser") : null;
        if (user == null || (!user.isAdmin() && !user.isOfficer())) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN, "Access Denied.");
            return;
        }

        String path = req.getServletPath();

        if ("/admin/reports/export-csv".equals(path)) {
            exportCsv(req, resp);
            return;
        }

        ReportSummary summary = reportDAO.getSummary();
        req.setAttribute("summary", summary);
        req.setAttribute("scholarshipsList", scholarshipDAO.listAll());
        req.getRequestDispatcher("/admin/reports.jsp").forward(req, resp);
    }

    private void exportCsv(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String scholarship = req.getParameter("scholarship");
        String status = req.getParameter("status");
        String department = req.getParameter("department");

        List<String[]> data = reportDAO.getExportData(scholarship, status, department);

        String filename = "scholarship_applications_report_" + LocalDate.now() + ".csv";
        resp.setContentType("text/csv; charset=UTF-8");
        resp.setHeader("Content-Disposition", "attachment; filename=\"" + filename + "\"");

        try (PrintWriter writer = resp.getWriter()) {
            for (String[] row : data) {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < row.length; i++) {
                    String val = row[i] != null ? row[i].replace("\"", "\"\"") : "";
                    sb.append("\"").append(val).append("\"");
                    if (i < row.length - 1) sb.append(",");
                }
                writer.println(sb.toString());
            }
        }
    }
}
