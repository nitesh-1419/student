package com.scholarship.servlet;

import com.scholarship.dao.ApplicationDAO;
import com.scholarship.dao.DocumentDAO;
import com.scholarship.model.User;
import com.scholarship.service.WorkflowService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Servlet executing Officer verification decisions: document approval/rejection,
 * application approval, rejection, or request for resubmission.
 */
@WebServlet(name = "VerifyServlet", urlPatterns = {"/officer/verify"})
public class VerifyServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(VerifyServlet.class.getName());

    private final DocumentDAO documentDAO = new DocumentDAO();
    private final WorkflowService workflowService = new WorkflowService();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("currentUser") : null;
        if (user == null || (!user.isOfficer() && !user.isAdmin())) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN, "Unauthorized: Officer credentials required.");
            return;
        }

        String action = req.getParameter("action");
        String appIdStr = req.getParameter("applicationId");

        if (appIdStr == null || action == null) {
            resp.sendRedirect(req.getContextPath() + "/officer/dashboard?error=missing_params");
            return;
        }

        int applicationId;
        try {
            applicationId = Integer.parseInt(appIdStr);
        } catch (NumberFormatException e) {
            resp.sendRedirect(req.getContextPath() + "/officer/dashboard?error=invalid_id");
            return;
        }

        try {
            if ("verify_doc".equalsIgnoreCase(action)) {
                String docIdStr = req.getParameter("documentId");
                String docStatus = req.getParameter("docStatus"); // 'VERIFIED' or 'REJECTED'
                String reason = req.getParameter("rejectionReason");

                if (docIdStr != null && docStatus != null) {
                    int docId = Integer.parseInt(docIdStr);
                    documentDAO.updateStatus(docId, docStatus, reason);
                }
                resp.sendRedirect(req.getContextPath() + "/officer/dashboard?reviewAppId=" + applicationId + "&doc_updated=true");
                return;

            } else if ("approve".equalsIgnoreCase(action)) {
                String remarks = req.getParameter("officerRemarks");
                if (remarks == null || remarks.trim().isEmpty()) {
                    remarks = "Approved by Verification Officer " + user.getFullName();
                }
                workflowService.transition(applicationId, "APPROVED", remarks, user, req.getRemoteAddr());
                resp.sendRedirect(req.getContextPath() + "/officer/dashboard?reviewAppId=" + applicationId + "&status_msg=approved");
                return;

            } else if ("reject".equalsIgnoreCase(action)) {
                String remarks = req.getParameter("officerRemarks");
                if (remarks == null || remarks.trim().isEmpty()) {
                    remarks = "Application rejected due to criteria non-compliance.";
                }
                workflowService.transition(applicationId, "REJECTED", remarks, user, req.getRemoteAddr());
                resp.sendRedirect(req.getContextPath() + "/officer/dashboard?reviewAppId=" + applicationId + "&status_msg=rejected");
                return;

            } else if ("request_resubmit".equalsIgnoreCase(action)) {
                String remarks = req.getParameter("officerRemarks");
                if (remarks == null || remarks.trim().isEmpty()) {
                    remarks = "Discrepancy detected in submitted documents. Please re-upload verified proofs.";
                }
                workflowService.transition(applicationId, "RESUBMISSION_REQUESTED", remarks, user, req.getRemoteAddr());
                resp.sendRedirect(req.getContextPath() + "/officer/dashboard?reviewAppId=" + applicationId + "&status_msg=resubmit_requested");
                return;

            } else if ("dismiss_flag".equalsIgnoreCase(action)) {
                String flagIdStr = req.getParameter("flagId");
                String reason = req.getParameter("dismissalReason");
                if (flagIdStr != null) {
                    int flagId = Integer.parseInt(flagIdStr);
                    com.scholarship.dao.FraudFlagDAO flagDAO = new com.scholarship.dao.FraudFlagDAO();
                    flagDAO.dismissFlag(flagId, user.getId(), reason != null ? reason : "Verified manually by officer.");
                }
                resp.sendRedirect(req.getContextPath() + "/officer/dashboard?reviewAppId=" + applicationId + "&flag_dismissed=true");
                return;
            }

        } catch (SQLException | IllegalStateException | SecurityException e) {
            LOGGER.log(Level.SEVERE, "Error executing verification action: " + action, e);
            resp.sendRedirect(req.getContextPath() + "/officer/dashboard?reviewAppId=" + applicationId + "&error=" + e.getMessage());
            return;
        }

        resp.sendRedirect(req.getContextPath() + "/officer/dashboard?reviewAppId=" + applicationId);
    }
}
