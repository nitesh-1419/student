package com.scholarship.dao;

import com.scholarship.model.Document;
import com.scholarship.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Data Access Object for uploaded student verification documents.
 */
public class DocumentDAO {

    private static final Logger LOGGER = Logger.getLogger(DocumentDAO.class.getName());

    public List<Document> findByApplicationId(int applicationId) {
        List<Document> list = new ArrayList<>();
        String sql = "SELECT id, application_id, student_id, doc_type, file_name, file_path, " +
                     "file_size, mime_type, file_hash, verification_status, rejection_reason, uploaded_at " +
                     "FROM documents WHERE application_id = ? ORDER BY id ASC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, applicationId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRow(rs));
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding documents for application: " + applicationId, e);
        }
        return list;
    }

    public Document findById(int id) {
        String sql = "SELECT id, application_id, student_id, doc_type, file_name, file_path, " +
                     "file_size, mime_type, file_hash, verification_status, rejection_reason, uploaded_at " +
                     "FROM documents WHERE id = ? LIMIT 1";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding document by id: " + id, e);
        }
        return null;
    }

    public int saveDocument(Document doc) throws SQLException {
        String sql = "INSERT INTO documents (application_id, student_id, doc_type, file_name, file_path, " +
                     "file_size, mime_type, file_hash, verification_status, rejection_reason) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, doc.getApplicationId());
            ps.setInt(2, doc.getStudentId());
            ps.setString(3, doc.getDocType());
            ps.setString(4, doc.getFileName());
            ps.setString(5, doc.getFilePath());
            ps.setLong(6, doc.getFileSize());
            ps.setString(7, doc.getMimeType());
            ps.setString(8, doc.getFileHash());
            ps.setString(9, doc.getVerificationStatus() != null ? doc.getVerificationStatus() : "PENDING");
            ps.setString(10, doc.getRejectionReason());

            int affected = ps.executeUpdate();
            if (affected > 0) {
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        int id = rs.getInt(1);
                        doc.setId(id);
                        return id;
                    }
                }
            }
        }
        return -1;
    }

    public boolean updateStatus(int docId, String status, String rejectionReason) throws SQLException {
        String sql = "UPDATE documents SET verification_status = ?, rejection_reason = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setString(2, rejectionReason);
            ps.setInt(3, docId);
            return ps.executeUpdate() > 0;
        }
    }

    public boolean deleteDocument(int docId) throws SQLException {
        String sql = "DELETE FROM documents WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, docId);
            return ps.executeUpdate() > 0;
        }
    }

    private Document mapRow(ResultSet rs) throws SQLException {
        Document d = new Document();
        d.setId(rs.getInt("id"));
        d.setApplicationId(rs.getInt("application_id"));
        d.setStudentId(rs.getInt("student_id"));
        d.setDocType(rs.getString("doc_type"));
        d.setFileName(rs.getString("file_name"));
        d.setFilePath(rs.getString("file_path"));
        d.setFileSize(rs.getLong("file_size"));
        d.setMimeType(rs.getString("mime_type"));
        d.setFileHash(rs.getString("file_hash"));
        d.setVerificationStatus(rs.getString("verification_status"));
        d.setRejectionReason(rs.getString("rejection_reason"));
        d.setUploadedAt(rs.getTimestamp("uploaded_at"));
        return d;
    }
}
