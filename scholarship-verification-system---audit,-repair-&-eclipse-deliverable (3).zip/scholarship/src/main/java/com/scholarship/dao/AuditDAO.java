package com.scholarship.dao;

import com.scholarship.model.AuditLog;
import java.util.List;

/**
 * AuditDAO interface alias delegating to VerificationDAO for consistent audit logging.
 */
public class AuditDAO {
    private final VerificationDAO verificationDAO = new VerificationDAO();

    public int log(AuditLog log) {
        return verificationDAO.recordAudit(log);
    }

    public List<AuditLog> getRecentLogs(int limit) {
        return verificationDAO.listRecent(limit);
    }
}
