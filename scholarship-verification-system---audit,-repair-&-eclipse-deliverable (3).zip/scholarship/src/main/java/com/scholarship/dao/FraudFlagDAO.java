package com.scholarship.dao;

import com.scholarship.model.FraudFlag;
import com.scholarship.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Data Access Object for individual fraud detection risk factors and officer dismissals.
 */
public class FraudFlagDAO {

    private static final Logger LOGGER = Logger.getLogger(FraudFlagDAO.class.getName());

    public List<FraudFlag> findByApplicationId(int applicationId) {
        List<FraudFlag> list = new ArrayList<>();
        String sql = "SELECT f.id, f.application_id, f.risk_factor, f.explanation, f.severity, " +
                     "f.is_dismissed, f.dismissed_by, f.dismissal_reason, f.created_at, " +
                     "u.full_name AS dismisser_name " +
                     "FROM fraud_flags f " +
                     "LEFT JOIN users u ON f.dismissed_by = u.id " +
                     "WHERE f.application_id = ? ORDER BY f.id ASC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, applicationId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    FraudFlag flag = new FraudFlag();
                    flag.setId(rs.getInt("id"));
                    flag.setApplicationId(rs.getInt("application_id"));
                    flag.setRiskFactor(rs.getString("risk_factor"));
                    flag.setExplanation(rs.getString("explanation"));
                    flag.setSeverity(rs.getString("severity"));
                    flag.setDismissed(rs.getBoolean("is_dismissed"));
                    int dBy = rs.getInt("dismissed_by");
                    if (!rs.wasNull()) flag.setDismissedBy(dBy);
                    flag.setDismissalReason(rs.getString("dismissal_reason"));
                    flag.setCreatedAt(rs.getTimestamp("created_at"));
                    flag.setDismisserName(rs.getString("dismisser_name"));
                    list.add(flag);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error fetching fraud flags for app: " + applicationId, e);
        }
        return list;
    }

    public int recordFlag(FraudFlag flag) {
        String sql = "INSERT INTO fraud_flags (application_id, risk_factor, explanation, severity, is_dismissed, created_at) " +
                     "VALUES (?, ?, ?, ?, FALSE, NOW())";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, flag.getApplicationId());
            ps.setString(2, flag.getRiskFactor());
            ps.setString(3, flag.getExplanation());
            ps.setString(4, flag.getSeverity() != null ? flag.getSeverity() : "LOW");
            return ps.executeUpdate();
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error recording fraud flag", e);
        }
        return -1;
    }

    public boolean dismissFlag(int flagId, int officerId, String justification) {
        String sql = "UPDATE fraud_flags SET is_dismissed = TRUE, dismissed_by = ?, dismissal_reason = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, officerId);
            ps.setString(2, justification);
            ps.setInt(3, flagId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error dismissing fraud flag: " + flagId, e);
        }
        return false;
    }
}
