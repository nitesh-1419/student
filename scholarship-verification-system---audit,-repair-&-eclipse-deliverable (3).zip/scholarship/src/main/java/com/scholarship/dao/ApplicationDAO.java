package com.scholarship.dao;

import com.scholarship.model.Application;
import com.scholarship.model.Scholarship;
import com.scholarship.model.Student;
import com.scholarship.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Data Access Object for Scholarship Applications.
 */
public class ApplicationDAO {

    private static final Logger LOGGER = Logger.getLogger(ApplicationDAO.class.getName());

    public Application findById(int id) {
        String sql = "SELECT a.id, a.application_no, a.student_id, a.scholarship_id, a.applied_date, " +
                     "a.status, a.eligibility_score, a.fraud_risk_score, a.fraud_risk_level, a.flagged_reasons, " +
                     "a.officer_remarks, a.verified_by, a.verified_date, a.updated_at, " +
                     "u.full_name AS student_name, s.roll_number, sch.title AS scholarship_title, sch.amount AS scholarship_amount, " +
                     "ou.full_name AS officer_name " +
                     "FROM applications a " +
                     "JOIN students s ON a.student_id = s.id " +
                     "JOIN users u ON s.user_id = u.id " +
                     "JOIN scholarships sch ON a.scholarship_id = sch.id " +
                     "LEFT JOIN users ou ON a.verified_by = ou.id " +
                     "WHERE a.id = ? LIMIT 1";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding application by ID: " + id, e);
        }
        return null;
    }

    public Application findByApplicationNo(String appNo) {
        String sql = "SELECT a.id, a.application_no, a.student_id, a.scholarship_id, a.applied_date, " +
                     "a.status, a.eligibility_score, a.fraud_risk_score, a.fraud_risk_level, a.flagged_reasons, " +
                     "a.officer_remarks, a.verified_by, a.verified_date, a.updated_at, " +
                     "u.full_name AS student_name, s.roll_number, sch.title AS scholarship_title, sch.amount AS scholarship_amount, " +
                     "ou.full_name AS officer_name " +
                     "FROM applications a " +
                     "JOIN students s ON a.student_id = s.id " +
                     "JOIN users u ON s.user_id = u.id " +
                     "JOIN scholarships sch ON a.scholarship_id = sch.id " +
                     "LEFT JOIN users ou ON a.verified_by = ou.id " +
                     "WHERE a.application_no = ? LIMIT 1";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, appNo);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding application by application_no: " + appNo, e);
        }
        return null;
    }

    public List<Application> findByStudentId(int studentId) {
        List<Application> list = new ArrayList<>();
        String sql = "SELECT a.id, a.application_no, a.student_id, a.scholarship_id, a.applied_date, " +
                     "a.status, a.eligibility_score, a.fraud_risk_score, a.fraud_risk_level, a.flagged_reasons, " +
                     "a.officer_remarks, a.verified_by, a.verified_date, a.updated_at, " +
                     "u.full_name AS student_name, s.roll_number, sch.title AS scholarship_title, sch.amount AS scholarship_amount, " +
                     "ou.full_name AS officer_name " +
                     "FROM applications a " +
                     "JOIN students s ON a.student_id = s.id " +
                     "JOIN users u ON s.user_id = u.id " +
                     "JOIN scholarships sch ON a.scholarship_id = sch.id " +
                     "LEFT JOIN users ou ON a.verified_by = ou.id " +
                     "WHERE a.student_id = ? ORDER BY a.applied_date DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRow(rs));
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error listing applications for student: " + studentId, e);
        }
        return list;
    }

    public boolean hasStudentApplied(int studentId, int scholarshipId) {
        String sql = "SELECT 1 FROM applications WHERE student_id = ? AND scholarship_id = ? LIMIT 1";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ps.setInt(2, scholarshipId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error checking duplicate application", e);
        }
        return false;
    }

    public int createApplication(Application app) throws SQLException {
        String sql = "INSERT INTO applications (application_no, student_id, scholarship_id, applied_date, status, " +
                     "eligibility_score, fraud_risk_score, fraud_risk_level, flagged_reasons) " +
                     "VALUES (?, ?, ?, NOW(), ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, app.getApplicationNo());
            ps.setInt(2, app.getStudentId());
            ps.setInt(3, app.getScholarshipId());
            ps.setString(4, app.getStatus() != null ? app.getStatus() : "SUBMITTED");
            ps.setBigDecimal(5, app.getEligibilityScore());
            ps.setBigDecimal(6, app.getFraudRiskScore());
            ps.setString(7, app.getFraudRiskLevel() != null ? app.getFraudRiskLevel() : "LOW");
            ps.setString(8, app.getFlaggedReasons());

            int affected = ps.executeUpdate();
            if (affected > 0) {
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        int id = rs.getInt(1);
                        app.setId(id);
                        return id;
                    }
                }
            }
        }
        return -1;
    }

    public boolean updateStatus(int applicationId, String status, String remarks, Integer verifiedBy) throws SQLException {
        String sql = "UPDATE applications SET status = ?, officer_remarks = ?, verified_by = ?, verified_date = NOW() " +
                     "WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setString(2, remarks);
            if (verifiedBy != null) {
                ps.setInt(3, verifiedBy);
            } else {
                ps.setNull(3, java.sql.Types.INTEGER);
            }
            ps.setInt(4, applicationId);
            return ps.executeUpdate() > 0;
        }
    }

    public boolean updateEligibilityAndFraud(int applicationId, java.math.BigDecimal eligibilityScore,
                                            java.math.BigDecimal fraudScore, String level, String flaggedReasons) {
        String sql = "UPDATE applications SET eligibility_score = ?, fraud_risk_score = ?, fraud_risk_level = ?, flagged_reasons = ? " +
                     "WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setBigDecimal(1, eligibilityScore);
            ps.setBigDecimal(2, fraudScore);
            ps.setString(3, level);
            ps.setString(4, flaggedReasons);
            ps.setInt(5, applicationId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error updating eligibility/fraud scores", e);
        }
        return false;
    }

    public List<Application> listAllForOfficer(String statusFilter) {
        List<Application> list = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
            "SELECT a.id, a.application_no, a.student_id, a.scholarship_id, a.applied_date, " +
            "a.status, a.eligibility_score, a.fraud_risk_score, a.fraud_risk_level, a.flagged_reasons, " +
            "a.officer_remarks, a.verified_by, a.verified_date, a.updated_at, " +
            "u.full_name AS student_name, s.roll_number, sch.title AS scholarship_title, sch.amount AS scholarship_amount, " +
            "ou.full_name AS officer_name " +
            "FROM applications a " +
            "JOIN students s ON a.student_id = s.id " +
            "JOIN users u ON s.user_id = u.id " +
            "JOIN scholarships sch ON a.scholarship_id = sch.id " +
            "LEFT JOIN users ou ON a.verified_by = ou.id "
        );

        if (statusFilter != null && !statusFilter.trim().isEmpty() && !"ALL".equalsIgnoreCase(statusFilter)) {
            sql.append("WHERE a.status = ? ");
        }
        sql.append("ORDER BY a.applied_date DESC");

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            if (statusFilter != null && !statusFilter.trim().isEmpty() && !"ALL".equalsIgnoreCase(statusFilter)) {
                ps.setString(1, statusFilter);
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRow(rs));
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error listing applications for officer", e);
        }
        return list;
    }

    public int countByStatus(String status) {
        String sql = "SELECT COUNT(*) FROM applications WHERE status = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error counting applications by status", e);
        }
        return 0;
    }

    public int countTotal() {
        String sql = "SELECT COUNT(*) FROM applications";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error counting total applications", e);
        }
        return 0;
    }

    private Application mapRow(ResultSet rs) throws SQLException {
        Application a = new Application();
        a.setId(rs.getInt("id"));
        a.setApplicationNo(rs.getString("application_no"));
        a.setStudentId(rs.getInt("student_id"));
        a.setScholarshipId(rs.getInt("scholarship_id"));
        a.setAppliedDate(rs.getTimestamp("applied_date"));
        a.setStatus(rs.getString("status"));
        a.setEligibilityScore(rs.getBigDecimal("eligibility_score"));
        a.setFraudRiskScore(rs.getBigDecimal("fraud_risk_score"));
        a.setFraudRiskLevel(rs.getString("fraud_risk_level"));
        a.setFlaggedReasons(rs.getString("flagged_reasons"));
        a.setOfficerRemarks(rs.getString("officer_remarks"));
        int verifiedBy = rs.getInt("verified_by");
        if (!rs.wasNull()) {
            a.setVerifiedBy(verifiedBy);
        }
        a.setVerifiedDate(rs.getTimestamp("verified_date"));
        a.setUpdatedAt(rs.getTimestamp("updated_at"));
        a.setStudentName(rs.getString("student_name"));
        a.setStudentRollNo(rs.getString("roll_number"));
        a.setScholarshipTitle(rs.getString("scholarship_title"));
        a.setScholarshipAmount(rs.getBigDecimal("scholarship_amount"));
        a.setOfficerName(rs.getString("officer_name"));
        return a;
    }
}
