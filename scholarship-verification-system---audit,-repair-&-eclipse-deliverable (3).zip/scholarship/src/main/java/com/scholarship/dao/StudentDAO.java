package com.scholarship.dao;

import com.scholarship.model.Student;
import com.scholarship.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Data Access Object for Student profiles.
 */
public class StudentDAO {

    private static final Logger LOGGER = Logger.getLogger(StudentDAO.class.getName());

    public Student findByUserId(int userId) {
        String sql = "SELECT s.id, s.user_id, s.roll_number, s.department, s.course, s.year_of_study, " +
                     "s.current_gpa, s.annual_family_income, s.category, s.bank_account_no, s.ifsc_code, " +
                     "s.bank_name, s.aadhar_hash, s.address, s.created_at, s.updated_at, " +
                     "u.full_name, u.email, u.phone AS mobile " +
                     "FROM students s " +
                     "JOIN users u ON s.user_id = u.id " +
                     "WHERE s.user_id = ? LIMIT 1";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding student by user ID: " + userId, e);
        }
        return null;
    }

    public Student findById(int id) {
        String sql = "SELECT s.id, s.user_id, s.roll_number, s.department, s.course, s.year_of_study, " +
                     "s.current_gpa, s.annual_family_income, s.category, s.bank_account_no, s.ifsc_code, " +
                     "s.bank_name, s.aadhar_hash, s.address, s.created_at, s.updated_at, " +
                     "u.full_name, u.email, u.phone AS mobile " +
                     "FROM students s " +
                     "JOIN users u ON s.user_id = u.id " +
                     "WHERE s.id = ? LIMIT 1";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding student by ID: " + id, e);
        }
        return null;
    }

    public boolean createOrUpdate(Student student) throws SQLException {
        Student existing = findByUserId(student.getUserId());
        if (existing == null) {
            String sql = "INSERT INTO students (user_id, roll_number, department, course, year_of_study, " +
                         "current_gpa, annual_family_income, category, bank_account_no, ifsc_code, bank_name, aadhar_hash, address) " +
                         "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                ps.setInt(1, student.getUserId());
                ps.setString(2, student.getRollNumber());
                ps.setString(3, student.getDepartment());
                ps.setString(4, student.getCourse());
                ps.setInt(5, student.getYearOfStudy());
                ps.setBigDecimal(6, student.getCurrentGpa());
                ps.setBigDecimal(7, student.getAnnualFamilyIncome());
                ps.setString(8, student.getCategory());
                ps.setString(9, student.getBankAccountNo());
                ps.setString(10, student.getIfscCode());
                ps.setString(11, student.getBankName());
                ps.setString(12, student.getAadharHash());
                ps.setString(13, student.getAddress());
                int res = ps.executeUpdate();
                if (res > 0) {
                    try (ResultSet rs = ps.getGeneratedKeys()) {
                        if (rs.next()) {
                            student.setId(rs.getInt(1));
                        }
                    }
                    return true;
                }
            }
        } else {
            String sql = "UPDATE students SET roll_number=?, department=?, course=?, year_of_study=?, " +
                         "current_gpa=?, annual_family_income=?, category=?, bank_account_no=?, ifsc_code=?, bank_name=?, address=? " +
                         "WHERE user_id=?";
            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, student.getRollNumber());
                ps.setString(2, student.getDepartment());
                ps.setString(3, student.getCourse());
                ps.setInt(4, student.getYearOfStudy());
                ps.setBigDecimal(5, student.getCurrentGpa());
                ps.setBigDecimal(6, student.getAnnualFamilyIncome());
                ps.setString(7, student.getCategory());
                ps.setString(8, student.getBankAccountNo());
                ps.setString(9, student.getIfscCode());
                ps.setString(10, student.getBankName());
                ps.setString(11, student.getAddress());
                ps.setInt(12, student.getUserId());
                return ps.executeUpdate() > 0;
            }
        }
        return false;
    }

    public List<Student> listAll() {
        List<Student> list = new ArrayList<>();
        String sql = "SELECT s.id, s.user_id, s.roll_number, s.department, s.course, s.year_of_study, " +
                     "s.current_gpa, s.annual_family_income, s.category, s.bank_account_no, s.ifsc_code, " +
                     "s.bank_name, s.aadhar_hash, s.address, s.created_at, s.updated_at, " +
                     "u.full_name, u.email, u.phone AS mobile " +
                     "FROM students s JOIN users u ON s.user_id = u.id ORDER BY s.id DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error listing students", e);
        }
        return list;
    }

    private Student mapRow(ResultSet rs) throws SQLException {
        Student s = new Student();
        s.setId(rs.getInt("id"));
        s.setUserId(rs.getInt("user_id"));
        s.setRollNumber(rs.getString("roll_number"));
        s.setDepartment(rs.getString("department"));
        s.setCourse(rs.getString("course"));
        s.setYearOfStudy(rs.getInt("year_of_study"));
        s.setCurrentGpa(rs.getBigDecimal("current_gpa"));
        s.setAnnualFamilyIncome(rs.getBigDecimal("annual_family_income"));
        s.setCategory(rs.getString("category"));
        s.setBankAccountNo(rs.getString("bank_account_no"));
        s.setIfscCode(rs.getString("ifsc_code"));
        s.setBankName(rs.getString("bank_name"));
        s.setAadharHash(rs.getString("aadhar_hash"));
        s.setAddress(rs.getString("address"));
        s.setCreatedAt(rs.getTimestamp("created_at"));
        s.setUpdatedAt(rs.getTimestamp("updated_at"));
        s.setFullName(rs.getString("full_name"));
        s.setEmail(rs.getString("email"));
        s.setMobile(rs.getString("mobile"));
        return s;
    }
}
