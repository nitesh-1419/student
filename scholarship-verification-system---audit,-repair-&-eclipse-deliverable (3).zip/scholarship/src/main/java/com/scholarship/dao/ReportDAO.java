package com.scholarship.dao;

import com.scholarship.model.Application;
import com.scholarship.model.ReportSummary;
import com.scholarship.util.DBConnection;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Data Access Object for Admin analytics, aggregates, and CSV export reporting.
 */
public class ReportDAO {

    private static final Logger LOGGER = Logger.getLogger(ReportDAO.class.getName());

    public ReportSummary getSummary() {
        ReportSummary summary = new ReportSummary();
        try (Connection conn = DBConnection.getConnection()) {

            // Overall counts
            String sqlCounts = "SELECT status, COUNT(*) AS cnt FROM applications GROUP BY status";
            try (Statement st = conn.createStatement();
                 ResultSet rs = st.executeQuery(sqlCounts)) {
                int total = 0;
                while (rs.next()) {
                    String stName = rs.getString("status");
                    int count = rs.getInt("cnt");
                    total += count;
                    if ("APPROVED".equalsIgnoreCase(stName)) summary.setApprovedApplications(count);
                    else if ("REJECTED".equalsIgnoreCase(stName)) summary.setRejectedApplications(count);
                    else if ("SUBMITTED".equalsIgnoreCase(stName) || "UNDER_REVIEW".equalsIgnoreCase(stName)) {
                        summary.setPendingApplications(summary.getPendingApplications() + count);
                    } else if ("RESUBMISSION_REQUESTED".equalsIgnoreCase(stName)) {
                        summary.setResubmissionApplications(count);
                    }
                }
                summary.setTotalApplications(total);
            }

            // Funds calculation
            String sqlFunds = "SELECT " +
                              "SUM(sch.amount) AS total_applied, " +
                              "SUM(CASE WHEN a.status = 'APPROVED' THEN sch.amount ELSE 0 END) AS total_approved " +
                              "FROM applications a " +
                              "JOIN scholarships sch ON a.scholarship_id = sch.id";
            try (Statement st = conn.createStatement();
                 ResultSet rs = st.executeQuery(sqlFunds)) {
                if (rs.next()) {
                    BigDecimal applied = rs.getBigDecimal("total_applied");
                    BigDecimal approved = rs.getBigDecimal("total_approved");
                    summary.setTotalAllocatedFunds(applied != null ? applied : BigDecimal.ZERO);
                    summary.setTotalDisbursedFunds(approved != null ? approved : BigDecimal.ZERO);
                }
            }

            // Department distribution
            String sqlDept = "SELECT s.department, COUNT(a.id) AS cnt " +
                             "FROM applications a " +
                             "JOIN students s ON a.student_id = s.id " +
                             "GROUP BY s.department";
            try (Statement st = conn.createStatement();
                 ResultSet rs = st.executeQuery(sqlDept)) {
                while (rs.next()) {
                    summary.getDepartmentDistribution().put(rs.getString("department"), rs.getInt("cnt"));
                }
            }

            // Category distribution
            String sqlCat = "SELECT s.category, COUNT(a.id) AS cnt " +
                            "FROM applications a " +
                            "JOIN students s ON a.student_id = s.id " +
                            "GROUP BY s.category";
            try (Statement st = conn.createStatement();
                 ResultSet rs = st.executeQuery(sqlCat)) {
                while (rs.next()) {
                    summary.getCategoryDistribution().put(rs.getString("category"), rs.getInt("cnt"));
                }
            }

            // Risk Level distribution
            String sqlRisk = "SELECT fraud_risk_level, COUNT(*) AS cnt FROM applications GROUP BY fraud_risk_level";
            try (Statement st = conn.createStatement();
                 ResultSet rs = st.executeQuery(sqlRisk)) {
                while (rs.next()) {
                    String level = rs.getString("fraud_risk_level");
                    summary.getRiskDistribution().put(level != null ? level : "LOW", rs.getInt("cnt"));
                }
            }

        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error building report summary", e);
        }
        return summary;
    }

    public List<String[]> getExportData(String scholarshipCode, String status, String department) {
        List<String[]> rows = new ArrayList<>();
        // Add CSV Header
        rows.add(new String[]{
            "Application No", "Student Name", "Roll Number", "Department",
            "Category", "GPA", "Family Income", "Scholarship", "Grant Amount",
            "Submission Date", "Status", "Eligibility %", "Fraud Risk", "Reviewer"
        });

        StringBuilder sql = new StringBuilder(
            "SELECT a.application_no, u.full_name AS student_name, s.roll_number, s.department, " +
            "s.category, s.current_gpa, s.annual_family_income, sch.title AS scholarship_title, sch.amount, " +
            "a.applied_date, a.status, a.eligibility_score, a.fraud_risk_level, ou.full_name AS reviewer " +
            "FROM applications a " +
            "JOIN students s ON a.student_id = s.id " +
            "JOIN users u ON s.user_id = u.id " +
            "JOIN scholarships sch ON a.scholarship_id = sch.id " +
            "LEFT JOIN users ou ON a.verified_by = ou.id " +
            "WHERE 1=1 "
        );

        List<Object> params = new ArrayList<>();
        if (scholarshipCode != null && !scholarshipCode.trim().isEmpty() && !"ALL".equalsIgnoreCase(scholarshipCode)) {
            sql.append("AND sch.code = ? ");
            params.add(scholarshipCode);
        }
        if (status != null && !status.trim().isEmpty() && !"ALL".equalsIgnoreCase(status)) {
            sql.append("AND a.status = ? ");
            params.add(status);
        }
        if (department != null && !department.trim().isEmpty() && !"ALL".equalsIgnoreCase(department)) {
            sql.append("AND s.department = ? ");
            params.add(department);
        }
        sql.append("ORDER BY a.applied_date DESC");

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) {
                ps.setObject(i + 1, params.get(i));
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    rows.add(new String[]{
                        rs.getString("application_no"),
                        rs.getString("student_name"),
                        rs.getString("roll_number"),
                        rs.getString("department"),
                        rs.getString("category"),
                        String.valueOf(rs.getBigDecimal("current_gpa")),
                        String.valueOf(rs.getBigDecimal("annual_family_income")),
                        rs.getString("scholarship_title"),
                        String.valueOf(rs.getBigDecimal("amount")),
                        String.valueOf(rs.getTimestamp("applied_date")),
                        rs.getString("status"),
                        String.valueOf(rs.getBigDecimal("eligibility_score")),
                        rs.getString("fraud_risk_level"),
                        rs.getString("reviewer") != null ? rs.getString("reviewer") : "Unassigned"
                    });
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error exporting report data", e);
        }
        return rows;
    }
}
