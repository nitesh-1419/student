package com.scholarship.dao;

import com.scholarship.model.Scholarship;
import com.scholarship.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Data Access Object for Scholarship schemes and quotas.
 */
public class ScholarshipDAO {

    private static final Logger LOGGER = Logger.getLogger(ScholarshipDAO.class.getName());

    public List<Scholarship> listActive() {
        List<Scholarship> list = new ArrayList<>();
        String sql = "SELECT id, code, title, description, sponsor, amount, min_gpa, " +
                     "max_annual_income, eligible_categories, deadline, total_slots, status, required_docs, created_at " +
                     "FROM scholarships WHERE status = 'ACTIVE' AND deadline >= CURDATE() " +
                     "ORDER BY deadline ASC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error listing active scholarships", e);
        }
        return list;
    }

    public List<Scholarship> listAll() {
        List<Scholarship> list = new ArrayList<>();
        String sql = "SELECT id, code, title, description, sponsor, amount, min_gpa, " +
                     "max_annual_income, eligible_categories, deadline, total_slots, status, required_docs, created_at " +
                     "FROM scholarships ORDER BY id DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error listing all scholarships", e);
        }
        return list;
    }

    public Scholarship findById(int id) {
        String sql = "SELECT id, code, title, description, sponsor, amount, min_gpa, " +
                     "max_annual_income, eligible_categories, deadline, total_slots, status, required_docs, created_at " +
                     "FROM scholarships WHERE id = ? LIMIT 1";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding scholarship by id: " + id, e);
        }
        return null;
    }

    public Scholarship findByCode(String code) {
        String sql = "SELECT id, code, title, description, sponsor, amount, min_gpa, " +
                     "max_annual_income, eligible_categories, deadline, total_slots, status, required_docs, created_at " +
                     "FROM scholarships WHERE code = ? LIMIT 1";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, code);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding scholarship by code: " + code, e);
        }
        return null;
    }

    public int createScholarship(Scholarship s) throws SQLException {
        String sql = "INSERT INTO scholarships (code, title, description, sponsor, amount, min_gpa, " +
                     "max_annual_income, eligible_categories, deadline, total_slots, status, required_docs) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, s.getCode());
            ps.setString(2, s.getTitle());
            ps.setString(3, s.getDescription());
            ps.setString(4, s.getSponsor());
            ps.setBigDecimal(5, s.getAmount());
            ps.setBigDecimal(6, s.getMinGpa());
            ps.setBigDecimal(7, s.getMaxAnnualIncome());
            ps.setString(8, s.getEligibleCategories());
            ps.setDate(9, s.getDeadline());
            ps.setInt(10, s.getTotalSlots());
            ps.setString(11, s.getStatus());
            ps.setString(12, s.getRequiredDocs());

            int affected = ps.executeUpdate();
            if (affected > 0) {
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        int id = rs.getInt(1);
                        s.setId(id);
                        return id;
                    }
                }
            }
        }
        return -1;
    }

    private Scholarship mapRow(ResultSet rs) throws SQLException {
        Scholarship s = new Scholarship();
        s.setId(rs.getInt("id"));
        s.setCode(rs.getString("code"));
        s.setTitle(rs.getString("title"));
        s.setDescription(rs.getString("description"));
        s.setSponsor(rs.getString("sponsor"));
        s.setAmount(rs.getBigDecimal("amount"));
        s.setMinGpa(rs.getBigDecimal("min_gpa"));
        s.setMaxAnnualIncome(rs.getBigDecimal("max_annual_income"));
        s.setEligibleCategories(rs.getString("eligible_categories"));
        s.setDeadline(rs.getDate("deadline"));
        s.setTotalSlots(rs.getInt("total_slots"));
        s.setStatus(rs.getString("status"));
        s.setRequiredDocs(rs.getString("required_docs"));
        s.setCreatedAt(rs.getTimestamp("created_at"));
        return s;
    }
}
