package com.scholarship.dao;

import com.scholarship.model.StatusHistory;
import com.scholarship.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Data Access Object for recording and retrieving application status change history.
 */
public class StatusHistoryDAO {

    private static final Logger LOGGER = Logger.getLogger(StatusHistoryDAO.class.getName());

    public int recordTransition(int applicationId, String previousStatus, String newStatus, Integer changedBy, String remarks) {
        String sql = "INSERT INTO application_status_history (application_id, previous_status, new_status, changed_by, remarks, created_at) " +
                     "VALUES (?, ?, ?, ?, ?, NOW())";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, applicationId);
            ps.setString(2, previousStatus);
            ps.setString(3, newStatus);
            if (changedBy != null) {
                ps.setInt(4, changedBy);
            } else {
                ps.setNull(4, java.sql.Types.INTEGER);
            }
            ps.setString(5, remarks);
            return ps.executeUpdate();
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error recording status transition for app: " + applicationId, e);
        }
        return -1;
    }

    public List<StatusHistory> findByApplicationId(int applicationId) {
        List<StatusHistory> list = new ArrayList<>();
        String sql = "SELECT h.id, h.application_id, h.previous_status, h.new_status, h.changed_by, h.remarks, h.created_at, " +
                     "u.full_name AS changer_name " +
                     "FROM application_status_history h " +
                     "LEFT JOIN users u ON h.changed_by = u.id " +
                     "WHERE h.application_id = ? ORDER BY h.created_at ASC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, applicationId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    StatusHistory h = new StatusHistory();
                    h.setId(rs.getInt("id"));
                    h.setApplicationId(rs.getInt("application_id"));
                    h.setPreviousStatus(rs.getString("previous_status"));
                    h.setNewStatus(rs.getString("new_status"));
                    int uid = rs.getInt("changed_by");
                    if (!rs.wasNull()) h.setChangedBy(uid);
                    h.setRemarks(rs.getString("remarks"));
                    h.setCreatedAt(rs.getTimestamp("created_at"));
                    h.setChangerName(rs.getString("changer_name"));
                    list.add(h);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error fetching status history for app: " + applicationId, e);
        }
        return list;
    }
}
