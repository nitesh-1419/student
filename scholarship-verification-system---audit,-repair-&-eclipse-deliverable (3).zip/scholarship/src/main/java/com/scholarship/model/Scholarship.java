package com.scholarship.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;

/**
 * Scholarship Entity representing grant schemes and eligibility criteria.
 */
public class Scholarship implements Serializable {
    private static final long serialVersionUID = 1L;

    private int id;
    private String code;
    private String title;
    private String description;
    private String sponsor;
    private BigDecimal amount;
    private BigDecimal minGpa;
    private BigDecimal maxAnnualIncome;
    private String eligibleCategories; // 'ALL' or comma-separated e.g. 'SC,ST,EWS'
    private Date deadline;
    private int totalSlots;
    private String status; // 'ACTIVE', 'CLOSED'
    private String requiredDocs; // Comma separated: 'INCOME_CERTIFICATE,MARKSHEET,IDENTITY_PROOF'
    private Timestamp createdAt;

    public Scholarship() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getSponsor() { return sponsor; }
    public void setSponsor(String sponsor) { this.sponsor = sponsor; }

    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }

    public BigDecimal getMinGpa() { return minGpa; }
    public void setMinGpa(BigDecimal minGpa) { this.minGpa = minGpa; }

    public BigDecimal getMaxAnnualIncome() { return maxAnnualIncome; }
    public void setMaxAnnualIncome(BigDecimal maxAnnualIncome) { this.maxAnnualIncome = maxAnnualIncome; }

    public String getEligibleCategories() { return eligibleCategories; }
    public void setEligibleCategories(String eligibleCategories) { this.eligibleCategories = eligibleCategories; }

    public Date getDeadline() { return deadline; }
    public void setDeadline(Date deadline) { this.deadline = deadline; }

    public int getTotalSlots() { return totalSlots; }
    public void setTotalSlots(int totalSlots) { this.totalSlots = totalSlots; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getRequiredDocs() { return requiredDocs; }
    public void setRequiredDocs(String requiredDocs) { this.requiredDocs = requiredDocs; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }

    public boolean isActive() {
        return "ACTIVE".equalsIgnoreCase(this.status);
    }
}
