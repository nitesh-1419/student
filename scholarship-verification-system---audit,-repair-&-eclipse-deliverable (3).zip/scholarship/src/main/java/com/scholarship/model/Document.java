package com.scholarship.model;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Document Entity representing uploaded proofs (marksheet, income, identity, caste, passbook).
 */
public class Document implements Serializable {
    private static final long serialVersionUID = 1L;

    private int id;
    private int applicationId;
    private int studentId;
    private String docType; // 'INCOME_CERTIFICATE', 'MARKSHEET', 'IDENTITY_PROOF', 'BANK_PASSBOOK', 'CASTE_CERTIFICATE'
    private String fileName;
    private String filePath;
    private long fileSize;
    private String mimeType;
    private String fileHash;
    private String verificationStatus; // 'PENDING', 'VERIFIED', 'REJECTED'
    private String rejectionReason;
    private Timestamp uploadedAt;

    public Document() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getApplicationId() { return applicationId; }
    public void setApplicationId(int applicationId) { this.applicationId = applicationId; }

    public int getStudentId() { return studentId; }
    public void setStudentId(int studentId) { this.studentId = studentId; }

    public String getDocType() { return docType; }
    public void setDocType(String docType) { this.docType = docType; }

    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }

    public String getFilePath() { return filePath; }
    public void setFilePath(String filePath) { this.filePath = filePath; }

    public long getFileSize() { return fileSize; }
    public void setFileSize(long fileSize) { this.fileSize = fileSize; }

    public String getMimeType() { return mimeType; }
    public void setMimeType(String mimeType) { this.mimeType = mimeType; }

    public String getFileHash() { return fileHash; }
    public void setFileHash(String fileHash) { this.fileHash = fileHash; }

    public String getVerificationStatus() { return verificationStatus; }
    public void setVerificationStatus(String verificationStatus) { this.verificationStatus = verificationStatus; }

    public String getRejectionReason() { return rejectionReason; }
    public void setRejectionReason(String rejectionReason) { this.rejectionReason = rejectionReason; }

    public Timestamp getUploadedAt() { return uploadedAt; }
    public void setUploadedAt(Timestamp uploadedAt) { this.uploadedAt = uploadedAt; }
}
