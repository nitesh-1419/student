package com.scholarship.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * ReportSummary Model containing aggregated analytics for Admin Dashboard and Reports.
 */
public class ReportSummary implements Serializable {
    private static final long serialVersionUID = 1L;

    private int totalApplications;
    private int approvedApplications;
    private int rejectedApplications;
    private int pendingApplications;
    private int resubmissionApplications;
    private BigDecimal totalAllocatedFunds = BigDecimal.ZERO;
    private BigDecimal totalDisbursedFunds = BigDecimal.ZERO;
    private Map<String, Integer> departmentDistribution = new HashMap<>();
    private Map<String, Integer> categoryDistribution = new HashMap<>();
    private Map<String, Integer> riskDistribution = new HashMap<>();

    public int getTotalApplications() { return totalApplications; }
    public void setTotalApplications(int totalApplications) { this.totalApplications = totalApplications; }

    public int getApprovedApplications() { return approvedApplications; }
    public void setApprovedApplications(int approvedApplications) { this.approvedApplications = approvedApplications; }

    public int getRejectedApplications() { return rejectedApplications; }
    public void setRejectedApplications(int rejectedApplications) { this.rejectedApplications = rejectedApplications; }

    public int getPendingApplications() { return pendingApplications; }
    public void setPendingApplications(int pendingApplications) { this.pendingApplications = pendingApplications; }

    public int getResubmissionApplications() { return resubmissionApplications; }
    public void setResubmissionApplications(int resubmissionApplications) { this.resubmissionApplications = resubmissionApplications; }

    public BigDecimal getTotalAllocatedFunds() { return totalAllocatedFunds; }
    public void setTotalAllocatedFunds(BigDecimal totalAllocatedFunds) { this.totalAllocatedFunds = totalAllocatedFunds; }

    public BigDecimal getTotalDisbursedFunds() { return totalDisbursedFunds; }
    public void setTotalDisbursedFunds(BigDecimal totalDisbursedFunds) { this.totalDisbursedFunds = totalDisbursedFunds; }

    public Map<String, Integer> getDepartmentDistribution() { return departmentDistribution; }
    public void setDepartmentDistribution(Map<String, Integer> departmentDistribution) { this.departmentDistribution = departmentDistribution; }

    public Map<String, Integer> getCategoryDistribution() { return categoryDistribution; }
    public void setCategoryDistribution(Map<String, Integer> categoryDistribution) { this.categoryDistribution = categoryDistribution; }

    public Map<String, Integer> getRiskDistribution() { return riskDistribution; }
    public void setRiskDistribution(Map<String, Integer> riskDistribution) { this.riskDistribution = riskDistribution; }
}
