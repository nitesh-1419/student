package com.scholarship.model;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Entity tracking application lifecycle state history.
 */
public class StatusHistory implements Serializable {
    private static final long serialVersionUID = 1L;

    private int id;
    private int applicationId;
    private String previousStatus;
    private String newStatus;
    private Integer changedBy;
    private String changerName;
    private String remarks;
    private Timestamp createdAt;

    public StatusHistory() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getApplicationId() { return applicationId; }
    public void setApplicationId(int applicationId) { this.applicationId = applicationId; }

    public String getPreviousStatus() { return previousStatus; }
    public void setPreviousStatus(String previousStatus) { this.previousStatus = previousStatus; }

    public String getNewStatus() { return newStatus; }
    public void setNewStatus(String newStatus) { this.newStatus = newStatus; }

    public Integer getChangedBy() { return changedBy; }
    public void setChangedBy(Integer changedBy) { this.changedBy = changedBy; }

    public String getChangerName() { return changerName; }
    public void setChangerName(String changerName) { this.changerName = changerName; }

    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }
}
