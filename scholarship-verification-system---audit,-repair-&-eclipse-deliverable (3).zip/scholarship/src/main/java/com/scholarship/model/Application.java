package com.scholarship.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 * Application Entity representing a student's scholarship submission.
 */
public class Application implements Serializable {
    private static final long serialVersionUID = 1L;

    private int id;
    private String applicationNo;
    private int studentId;
    private int scholarshipId;
    private Timestamp appliedDate;
    private String status; // 'SUBMITTED', 'UNDER_REVIEW', 'RESUBMISSION_REQUESTED', 'APPROVED', 'REJECTED'
    private BigDecimal eligibilityScore;
    private BigDecimal fraudRiskScore;
    private String fraudRiskLevel; // 'LOW', 'MEDIUM', 'HIGH'
    private String flaggedReasons;
    private String officerRemarks;
    private Integer verifiedBy;
    private Timestamp verifiedDate;
    private int draftStep = 1;
    private Timestamp updatedAt;

    // Associated student, scholarship & document metadata for presentation
    private Student student;
    private Scholarship scholarship;
    private String studentName;
    private String studentRollNo;
    private String scholarshipTitle;
    private BigDecimal scholarshipAmount;
    private String officerName;
    private List<Document> documents = new ArrayList<>();

    public Application() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getApplicationNo() { return applicationNo; }
    public void setApplicationNo(String applicationNo) { this.applicationNo = applicationNo; }

    public int getStudentId() { return studentId; }
    public void setStudentId(int studentId) { this.studentId = studentId; }

    public int getScholarshipId() { return scholarshipId; }
    public void setScholarshipId(int scholarshipId) { this.scholarshipId = scholarshipId; }

    public Timestamp getAppliedDate() { return appliedDate; }
    public void setAppliedDate(Timestamp appliedDate) { this.appliedDate = appliedDate; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public BigDecimal getEligibilityScore() { return eligibilityScore; }
    public void setEligibilityScore(BigDecimal eligibilityScore) { this.eligibilityScore = eligibilityScore; }

    public BigDecimal getFraudRiskScore() { return fraudRiskScore; }
    public void setFraudRiskScore(BigDecimal fraudRiskScore) { this.fraudRiskScore = fraudRiskScore; }

    public String getFraudRiskLevel() { return fraudRiskLevel; }
    public void setFraudRiskLevel(String fraudRiskLevel) { this.fraudRiskLevel = fraudRiskLevel; }

    public String getFlaggedReasons() { return flaggedReasons; }
    public void setFlaggedReasons(String flaggedReasons) { this.flaggedReasons = flaggedReasons; }

    public String getOfficerRemarks() { return officerRemarks; }
    public void setOfficerRemarks(String officerRemarks) { this.officerRemarks = officerRemarks; }

    public Integer getVerifiedBy() { return verifiedBy; }
    public void setVerifiedBy(Integer verifiedBy) { this.verifiedBy = verifiedBy; }

    public Timestamp getVerifiedDate() { return verifiedDate; }
    public void setVerifiedDate(Timestamp verifiedDate) { this.verifiedDate = verifiedDate; }

    public int getDraftStep() { return draftStep; }
    public void setDraftStep(int draftStep) { this.draftStep = draftStep; }

    public Timestamp getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(Timestamp updatedAt) { this.updatedAt = updatedAt; }

    public Student getStudent() { return student; }
    public void setStudent(Student student) { this.student = student; }

    public Scholarship getScholarship() { return scholarship; }
    public void setScholarship(Scholarship scholarship) { this.scholarship = scholarship; }

    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }

    public String getStudentRollNo() { return studentRollNo; }
    public void setStudentRollNo(String studentRollNo) { this.studentRollNo = studentRollNo; }

    public String getScholarshipTitle() { return scholarshipTitle; }
    public void setScholarshipTitle(String scholarshipTitle) { this.scholarshipTitle = scholarshipTitle; }

    public BigDecimal getScholarshipAmount() { return scholarshipAmount; }
    public void setScholarshipAmount(BigDecimal scholarshipAmount) { this.scholarshipAmount = scholarshipAmount; }

    public String getOfficerName() { return officerName; }
    public void setOfficerName(String officerName) { this.officerName = officerName; }

    public List<Document> getDocuments() { return documents; }
    public void setDocuments(List<Document> documents) { this.documents = documents; }
}
