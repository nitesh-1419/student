package com.scholarship.model;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Entity tracking individual explainable risk factors, severity, and officer dismissals.
 */
public class FraudFlag implements Serializable {
    private static final long serialVersionUID = 1L;

    private int id;
    private int applicationId;
    private String riskFactor;
    private String explanation;
    private String severity; // 'LOW', 'MEDIUM', 'HIGH'
    private boolean dismissed;
    private Integer dismissedBy;
    private String dismisserName;
    private String dismissalReason;
    private Timestamp createdAt;

    public FraudFlag() {}

    public FraudFlag(int applicationId, String riskFactor, String explanation, String severity) {
        this.applicationId = applicationId;
        this.riskFactor = riskFactor;
        this.explanation = explanation;
        this.severity = severity;
        this.dismissed = false;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getApplicationId() { return applicationId; }
    public void setApplicationId(int applicationId) { this.applicationId = applicationId; }

    public String getRiskFactor() { return riskFactor; }
    public void setRiskFactor(String riskFactor) { this.riskFactor = riskFactor; }

    public String getExplanation() { return explanation; }
    public void setExplanation(String explanation) { this.explanation = explanation; }

    public String getSeverity() { return severity; }
    public void setSeverity(String severity) { this.severity = severity; }

    public boolean isDismissed() { return dismissed; }
    public void setDismissed(boolean dismissed) { this.dismissed = dismissed; }

    public Integer getDismissedBy() { return dismissedBy; }
    public void setDismissedBy(Integer dismissedBy) { this.dismissedBy = dismissedBy; }

    public String getDismisserName() { return dismisserName; }
    public void setDismisserName(String dismisserName) { this.dismisserName = dismisserName; }

    public String getDismissalReason() { return dismissalReason; }
    public void setDismissalReason(String dismissalReason) { this.dismissalReason = dismissalReason; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }
}
