package com.scholarship.filter;

import com.scholarship.model.User;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Enforces authentication and role-based access control across all restricted paths.
 */
@WebFilter(filterName = "AuthFilter", urlPatterns = {"/student/*", "/officer/*", "/admin/*"})
public class AuthFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {}

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;

        HttpSession session = req.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("currentUser") : null;

        String contextPath = req.getContextPath();
        String uri = req.getRequestURI();

        if (user == null) {
            // Store target URI to redirect back after successful login
            if (session != null) {
                session.setAttribute("redirectUrl", uri);
            }
            resp.sendRedirect(contextPath + "/login?error=session_expired");
            return;
        }

        // Check Role-Based Access Control
        String role = user.getRole();
        if (uri.startsWith(contextPath + "/officer") && !"OFFICER".equalsIgnoreCase(role) && !"ADMIN".equalsIgnoreCase(role)) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN, "Access Denied: Officer privileges required.");
            return;
        }

        if (uri.startsWith(contextPath + "/student") && !"STUDENT".equalsIgnoreCase(role)) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN, "Access Denied: Student account required.");
            return;
        }

        if (uri.startsWith(contextPath + "/admin") && !"ADMIN".equalsIgnoreCase(role)) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN, "Access Denied: Administrator privileges required.");
            return;
        }

        chain.doFilter(request, response);
    }

    @Override
    public void destroy() {}
}
