<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrator Dashboard - Scholarship System</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/app.css">
</head>
<body>

    <!-- Animated Ambient Glowing Orbs Background -->
    <div class="ambient-background">
        <div class="ambient-orb ambient-orb-1"></div>
        <div class="ambient-orb ambient-orb-2"></div>
        <div class="ambient-orb ambient-orb-3"></div>
    </div>

    <nav class="glass-nav">
        <a href="${pageContext.request.contextPath}/admin/dashboard" class="navbar-brand">
            <span>⚙️ Administrator Control Center</span>
            <span style="font-size: 0.7rem; padding: 0.2rem 0.5rem; background: var(--glass-bg-subtle); border-radius: 9999px; border: 1px solid var(--glass-border);">Admin Portal</span>
        </a>
        <div class="nav-links">
            <a href="${pageContext.request.contextPath}/admin/dashboard" class="nav-link active">Overview</a>
            <a href="${pageContext.request.contextPath}/admin/reports" class="nav-link">Reports & CSV</a>
            <!-- Audio Sound Toggle Button -->
            <button type="button" class="btn btn-glass sound-toggle-btn" title="Toggle Sound Feedback">
                <span class="icon">🔊</span> Sound On
            </button>
            <!-- Dark / Light Theme Toggle Button -->
            <button type="button" class="btn btn-glass theme-toggle-btn" title="Switch Theme">
                <span class="icon">☀️</span> Light Mode
            </button>
            <div class="nav-user">
                <span>👤 ${sessionScope.currentUser.fullName} (Admin)</span>
            </div>
            <form action="${pageContext.request.contextPath}/logout" method="POST" style="margin: 0;">
                <input type="hidden" name="csrfToken" value="${sessionScope.csrfToken}">
                <button type="submit" class="btn btn-glass btn-sm">Sign Out</button>
            </form>
        </div>
    </nav>

    <div class="container">
        <!-- Overview KPI Summary Cards -->
        <div class="stats-grid">
            <div class="stat-card" style="border-left: 4px solid var(--primary);">
                <span class="stat-label">Total Applications</span>
                <span class="stat-value">${summary.totalApplications}</span>
                <span class="stat-desc">Across all academic departments</span>
            </div>
            <div class="stat-card" style="border-left: 4px solid var(--success);">
                <span class="stat-label">Approved Beneficiaries</span>
                <span class="stat-value" style="color: var(--success);">${summary.approvedApplications}</span>
                <span class="stat-desc">Disbursement approved</span>
            </div>
            <div class="stat-card" style="border-left: 4px solid var(--warning);">
                <span class="stat-label">Pending / In Review</span>
                <span class="stat-value" style="color: var(--warning);">${summary.pendingApplications}</span>
                <span class="stat-desc">Assigned to verification officers</span>
            </div>
            <div class="stat-card" style="border-left: 4px solid var(--danger);">
                <span class="stat-label">Disqualified / Rejected</span>
                <span class="stat-value" style="color: var(--danger);">${summary.rejectedApplications}</span>
                <span class="stat-desc">Failed criteria or fraud flags</span>
            </div>
            <div class="stat-card" style="border-left: 4px solid var(--info);">
                <span class="stat-label">Disbursed Funds</span>
                <span class="stat-value" style="color: var(--info); font-size: 1.5rem;">
                    INR <fmt:formatNumber value="${summary.totalDisbursedFunds}" pattern="#,##,###"/>
                </span>
                <span class="stat-desc">Allocated: INR <fmt:formatNumber value="${summary.totalAllocatedFunds}" pattern="#,##,###"/></span>
            </div>
        </div>

        <c:choose>
            <c:when test="${param.view == 'diagnostics'}">
                <!-- System Health & Diagnostics Station -->
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">System Runtime & Database Health Diagnostics</h2>
                        <a href="${pageContext.request.contextPath}/admin/dashboard" class="btn btn-secondary btn-sm">← Back</a>
                    </div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; font-size: 0.85rem;">
                        <div class="card" style="background: #f8fafc; border: 1px solid var(--border);">
                            <h3 style="font-weight: 700; margin-bottom: 0.75rem; color: var(--primary);">Java Runtime (JVM)</h3>
                            <div style="space-y: 0.5rem;">
                                <div>Java Specification: <strong>Java 11 (LTS)</strong></div>
                                <div>Runtime Version: <strong>${jvmVersion} (${jvmVendor})</strong></div>
                                <div>Operating System: <strong>${osName}</strong></div>
                                <div>Max Allocated Memory: <strong>${maxMemoryMb} MB</strong></div>
                                <div>Total JVM Heap: <strong>${totalMemoryMb} MB</strong></div>
                                <div>Free JVM Memory: <strong>${freeMemoryMb} MB</strong></div>
                            </div>
                        </div>

                        <div class="card" style="background: #f8fafc; border: 1px solid var(--border);">
                            <h3 style="font-weight: 700; margin-bottom: 0.75rem; color: var(--secondary);">MySQL 8 Database Connection</h3>
                            <div>
                                <div>Status: 
                                    <c:choose>
                                        <c:when test="${dbConnected}">
                                            <span class="badge-status badge-approved">CONNECTED & OPERATIONAL ✓</span>
                                        </c:when>
                                        <c:otherwise>
                                            <span class="badge-status badge-rejected">DISCONNECTED / CONFIG PENDING</span>
                                        </c:otherwise>
                                    </c:choose>
                                </div>
                                <div style="margin-top: 0.5rem;">JDBC URL: <code style="font-size: 0.75rem;">${dbUrl}</code></div>
                                <div>Database User: <strong>${dbUser}</strong></div>
                                <div>Driver: <code>com.mysql.cj.jdbc.Driver</code></div>
                                <div>Connection Pool: <strong>Active (Max Total: 20)</strong></div>
                            </div>
                        </div>
                    </div>
                </div>
            </c:when>

            <c:when test="${param.view == 'scholarships'}">
                <!-- Scholarship Management -->
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">Scholarship Schemes Administration</h2>
                        <button type="button" class="btn btn-primary btn-sm" onclick="document.getElementById('newSchModal').style.display='block'">
                            + Create New Scholarship Scheme
                        </button>
                    </div>

                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Code</th>
                                    <th>Scheme Title</th>
                                    <th>Sponsor</th>
                                    <th>Amount</th>
                                    <th>Min GPA</th>
                                    <th>Income Limit</th>
                                    <th>Deadline</th>
                                    <th>Slots</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <c:forEach var="s" items="${scholarshipsList}">
                                    <tr>
                                        <td><strong>${s.code}</strong></td>
                                        <td>${s.title}</td>
                                        <td>${s.sponsor}</td>
                                        <td>INR <fmt:formatNumber value="${s.amount}" pattern="#,##,###"/></td>
                                        <td>${s.minGpa}</td>
                                        <td>INR <fmt:formatNumber value="${s.maxAnnualIncome}" pattern="#,##,###"/></td>
                                        <td><fmt:formatDate value="${s.deadline}" pattern="dd MMM yyyy"/></td>
                                        <td>${s.totalSlots}</td>
                                        <td><span class="badge-status badge-approved">${s.status}</span></td>
                                    </tr>
                                </c:forEach>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Create Scholarship Modal -->
                <div id="newSchModal" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.5); z-index:99; align-items:center; justify-content:center; padding:1rem;">
                    <div class="card" style="max-width:600px; margin:2rem auto; background:#fff;">
                        <div class="card-header">
                            <h3 class="card-title">Add New Scholarship Scheme</h3>
                            <button type="button" onclick="document.getElementById('newSchModal').style.display='none'" style="border:none;background:none;font-weight:bold;cursor:pointer;">✕</button>
                        </div>
                        <form action="${pageContext.request.contextPath}/admin/dashboard" method="POST">
                            <input type="hidden" name="action" value="create_scholarship">
                            <div class="form-row">
                                <div class="form-group">
                                    <label class="form-label">Code *</label>
                                    <input type="text" name="code" class="form-control" placeholder="SCH-AI-2026" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Award Amount (INR) *</label>
                                    <input type="number" name="amount" class="form-control" placeholder="50000" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Title *</label>
                                <input type="text" name="title" class="form-control" placeholder="National Artificial Intelligence Fellowship" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Description *</label>
                                <textarea name="description" class="form-control" rows="2" required></textarea>
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label class="form-label">Min GPA *</label>
                                    <input type="number" step="0.01" name="minGpa" class="form-control" value="3.50" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Max Family Income (INR) *</label>
                                    <input type="number" name="maxIncome" class="form-control" value="500000" required>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label class="form-label">Deadline *</label>
                                    <input type="date" name="deadline" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Total Slots *</label>
                                    <input type="number" name="slots" class="form-control" value="50" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Sponsoring Organization *</label>
                                <input type="text" name="sponsor" class="form-control" placeholder="Ministry of Science and Tech" required>
                            </div>
                            <input type="hidden" name="categories" value="ALL">
                            <input type="hidden" name="requiredDocs" value="INCOME_CERTIFICATE,MARKSHEET,IDENTITY_PROOF,BANK_PASSBOOK">
                            <button type="submit" class="btn btn-primary" style="width:100%;">Create & Publish Scheme →</button>
                        </form>
                    </div>
                </div>
            </c:when>

            <c:otherwise>
                <!-- Default Overview: Department Distribution & Audit Logs -->
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-bottom: 2rem;">
                    <div class="card">
                        <h3 class="card-title" style="margin-bottom: 1rem;">Applications by Department</h3>
                        <table class="table" style="font-size: 0.85rem;">
                            <thead>
                                <tr>
                                    <th>Department</th>
                                    <th>Applications</th>
                                </tr>
                            </thead>
                            <tbody>
                                <c:forEach var="entry" items="${summary.departmentDistribution}">
                                    <tr>
                                        <td><strong>${entry.key}</strong></td>
                                        <td>${entry.value}</td>
                                    </tr>
                                </c:forEach>
                            </tbody>
                        </table>
                    </div>

                    <div class="card">
                        <h3 class="card-title" style="margin-bottom: 1rem;">Fraud Risk Severity Distribution</h3>
                        <table class="table" style="font-size: 0.85rem;">
                            <thead>
                                <tr>
                                    <th>Risk Level</th>
                                    <th>Cases</th>
                                    <th>Action Required</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><span class="badge-status badge-risk-low">LOW RISK</span></td>
                                    <td>${summary.riskDistribution['LOW'] != null ? summary.riskDistribution['LOW'] : 0}</td>
                                    <td>Fast-track approval</td>
                                </tr>
                                <tr>
                                    <td><span class="badge-status badge-risk-medium">MEDIUM RISK</span></td>
                                    <td>${summary.riskDistribution['MEDIUM'] != null ? summary.riskDistribution['MEDIUM'] : 0}</td>
                                    <td>Manual review & resubmission check</td>
                                </tr>
                                <tr>
                                    <td><span class="badge-status badge-risk-high">HIGH RISK</span></td>
                                    <td>${summary.riskDistribution['HIGH'] != null ? summary.riskDistribution['HIGH'] : 0}</td>
                                    <td>Revenue authority confirmation required</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Global Audit Log -->
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">Live System Security Audit Trail</h2>
                        <a href="${pageContext.request.contextPath}/admin/reports" class="btn btn-secondary btn-sm">Export Detailed Log</a>
                    </div>
                    <div class="table-responsive">
                        <table class="table" style="font-size: 0.8rem;">
                            <thead>
                                <tr>
                                    <th>Timestamp</th>
                                    <th>Actor</th>
                                    <th>Action</th>
                                    <th>Entity</th>
                                    <th>Details</th>
                                    <th>IP Address</th>
                                </tr>
                            </thead>
                            <tbody>
                                <c:forEach var="log" items="${recentAudits}">
                                    <tr>
                                        <td><fmt:formatDate value="${log.createdAt}" pattern="yyyy-MM-dd HH:mm:ss"/></td>
                                        <td><strong><c:out value="${log.userFullName}" default="SYSTEM"/></strong> (<c:out value="${log.username}" default="sys"/>)</td>
                                        <td><code>${log.action}</code></td>
                                        <td>${log.entityType} #${log.entityId}</td>
                                        <td>${log.details}</td>
                                        <td><code>${log.ipAddress}</code></td>
                                    </tr>
                                </c:forEach>
                            </tbody>
                        </table>
                    </div>
                </div>
            </c:otherwise>
        </c:choose>
    </div>

    <footer class="footer">
        <div>National Scholarship Verification System &copy; 2026. Java 11 / Tomcat 9 Architecture.</div>
    </footer>
    <script src="${pageContext.request.contextPath}/assets/app.js"></script>
</body>
</html>
