<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports & Analytics - Scholarship Verification System</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/app.css">
</head>
<body>

    <nav class="navbar" style="background: linear-gradient(135deg, #1e1b4b 0%, #312e81 100%);">
        <a href="${pageContext.request.contextPath}/admin/dashboard" class="navbar-brand">
            <span>📊 Intelligence & Reports Portal</span>
        </a>
        <div class="nav-links">
            <a href="${pageContext.request.contextPath}/admin/dashboard" class="nav-link">Dashboard</a>
            <a href="${pageContext.request.contextPath}/admin/reports" class="nav-link active">Reports & CSV</a>
            <form action="${pageContext.request.contextPath}/logout" method="POST" style="margin: 0;">
                <button type="submit" class="btn btn-secondary btn-sm">Sign Out</button>
            </form>
        </div>
    </nav>

    <div class="container">
        <div class="page-header">
            <div>
                <h1 class="page-title">Analytics & Exportable Reports</h1>
                <div class="page-subtitle">Generate filterable CSV audits and inspect real-time MySQL database aggregates.</div>
            </div>
            <div>
                <a href="${pageContext.request.contextPath}/admin/reports/export-csv" class="btn btn-primary">
                    Download Full CSV Report ⤓
                </a>
            </div>
        </div>

        <!-- Filter Card -->
        <div class="card">
            <h3 class="card-title" style="margin-bottom: 1rem;">Filter Report Dataset</h3>
            <form action="${pageContext.request.contextPath}/admin/reports/export-csv" method="GET" class="form-row">
                <div class="form-group">
                    <label class="form-label">Scholarship Scheme</label>
                    <select name="scholarship" class="form-control">
                        <option value="ALL">All Schemes</option>
                        <c:forEach var="s" items="${scholarshipsList}">
                            <option value="${s.code}">${s.code} - ${s.title}</option>
                        </c:forEach>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Application Status</label>
                    <select name="status" class="form-control">
                        <option value="ALL">All Statuses</option>
                        <option value="SUBMITTED">Submitted</option>
                        <option value="UNDER_REVIEW">Under Review</option>
                        <option value="APPROVED">Approved</option>
                        <option value="REJECTED">Rejected</option>
                        <option value="RESUBMISSION_REQUESTED">Resubmission Requested</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Department</label>
                    <input type="text" name="department" class="form-control" placeholder="e.g. Computer Science">
                </div>
                <div class="form-group" style="display: flex; align-items: flex-end;">
                    <button type="submit" class="btn btn-success" style="width: 100%;">
                        Export Filtered CSV →
                    </button>
                </div>
            </form>
        </div>

        <!-- Key Financial Summary Table -->
        <div class="card">
            <h3 class="card-title" style="margin-bottom: 1rem;">Fund Allocation & Disbursement Summary</h3>
            <table class="table">
                <thead>
                    <tr>
                        <th>Metric</th>
                        <th>Amount (INR)</th>
                        <th>Details</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><strong>Total Applied Funding</strong></td>
                        <td><span style="font-size: 1.15rem; font-weight: bold;">INR <fmt:formatNumber value="${summary.totalAllocatedFunds}" pattern="#,##,###"/></span></td>
                        <td>Sum of grant values for all submitted applications</td>
                    </tr>
                    <tr>
                        <td><strong>Total Disbursed / Cleared Funds</strong></td>
                        <td><span style="font-size: 1.15rem; font-weight: bold; color: var(--success);">INR <fmt:formatNumber value="${summary.totalDisbursedFunds}" pattern="#,##,###"/></span></td>
                        <td>Direct benefit transfer authorized for approved candidates</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <footer class="footer">
        <div>National Scholarship Verification System &copy; 2026. Java 11 / Tomcat 9 Architecture.</div>
    </footer>
</body>
</html>
