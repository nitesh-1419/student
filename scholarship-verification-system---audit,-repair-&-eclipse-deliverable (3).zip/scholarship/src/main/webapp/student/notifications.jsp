<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notification Center - Scholarship Verification System</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/app.css">
</head>
<body>

    <nav class="navbar">
        <a href="${pageContext.request.contextPath}/student/dashboard" class="navbar-brand">
            <span>🎓 Student Portal</span>
        </a>
        <div class="nav-links">
            <a href="${pageContext.request.contextPath}/student/dashboard" class="nav-link">Dashboard</a>
            <a href="${pageContext.request.contextPath}/notifications" class="nav-link active">Notifications</a>
            <div class="nav-user">
                <span>👤 ${sessionScope.currentUser.fullName}</span>
            </div>
            <form action="${pageContext.request.contextPath}/logout" method="POST" style="margin: 0;">
                <button type="submit" class="btn btn-secondary btn-sm">Sign Out</button>
            </form>
        </div>
    </nav>

    <div class="container" style="max-width: 800px;">
        <div class="page-header">
            <div>
                <h1 class="page-title">Notification Center</h1>
                <div class="page-subtitle">Real-time alerts regarding application review milestones and document updates.</div>
            </div>
            <div>
                <form action="${pageContext.request.contextPath}/notifications/read" method="POST">
                    <button type="submit" class="btn btn-secondary btn-sm">Mark All as Read ✓</button>
                </form>
            </div>
        </div>

        <div class="card">
            <c:choose>
                <c:when test="${empty notifications}">
                    <div style="text-align: center; padding: 3rem; color: var(--text-muted);">
                        <p style="font-size: 1.1rem;">You have no notifications at this time.</p>
                    </div>
                </c:when>
                <c:otherwise>
                    <div style="display: flex; flex-direction: column; gap: 0.75rem;">
                        <c:forEach var="n" items="${notifications}">
                            <div class="alert ${n.type == 'SUCCESS' ? 'alert-success' : (n.type == 'WARNING' ? 'alert-warning' : (n.type == 'DANGER' ? 'alert-danger' : 'alert-info'))}" style="margin: 0; display: flex; justify-content: space-between; align-items: flex-start;">
                                <div>
                                    <div style="font-weight: 700; font-size: 0.95rem; margin-bottom: 0.25rem;">${n.title}</div>
                                    <div style="font-size: 0.85rem;">${n.message}</div>
                                    <div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 0.4rem;">
                                        <fmt:formatDate value="${n.createdAt}" pattern="dd MMM yyyy, hh:mm a"/>
                                    </div>
                                </div>
                                <c:if test="${not empty n.linkUrl}">
                                    <div>
                                        <a href="${pageContext.request.contextPath}/${n.linkUrl}" class="btn btn-sm btn-secondary" style="font-size: 0.75rem;">
                                            View Details →
                                        </a>
                                    </div>
                                </c:if>
                            </div>
                        </c:forEach>
                    </div>
                </c:otherwise>
            </c:choose>
        </div>
    </div>

    <footer class="footer">
        <div>National Scholarship Verification System &copy; 2026. Java 11 / Tomcat 9 Architecture.</div>
    </footer>
</body>
</html>
