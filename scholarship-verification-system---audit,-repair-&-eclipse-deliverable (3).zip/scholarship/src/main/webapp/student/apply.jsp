<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apply for Scholarship - Scholarship Verification System</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/app.css">
</head>
<body>

    <nav class="navbar">
        <a href="${pageContext.request.contextPath}/student/dashboard" class="navbar-brand">
            <span>🎓 Student Portal</span>
        </a>
        <div class="nav-links">
            <a href="${pageContext.request.contextPath}/student/dashboard" class="nav-link">Dashboard</a>
            <a href="${pageContext.request.contextPath}/student/apply" class="nav-link active">Apply for Scholarship</a>
            <div class="nav-user">
                <span>👤 ${sessionScope.currentUser.fullName}</span>
            </div>
            <form action="${pageContext.request.contextPath}/logout" method="POST" style="margin: 0;">
                <button type="submit" class="btn btn-secondary btn-sm">Sign Out</button>
            </form>
        </div>
    </nav>

    <div class="container">
        <div class="page-header">
            <div>
                <h1 class="page-title">Scholarship Application</h1>
                <div class="page-subtitle">Select a scheme, verify your eligibility criteria, and submit your application.</div>
            </div>
            <div>
                <a href="${pageContext.request.contextPath}/student/dashboard" class="btn btn-secondary btn-sm">← Back to Dashboard</a>
            </div>
        </div>

        <c:if test="${not empty errorMessage}">
            <div class="alert alert-danger">
                <span>⚠️</span>
                <span>${errorMessage}</span>
            </div>
        </c:if>

        <c:choose>
            <c:when test="${not empty scholarship}">
                <!-- Scholarship Detailed Eligibility Assessment -->
                <div class="card" style="border-left: 4px solid var(--primary);">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1rem;">
                        <div>
                            <span class="badge-status badge-submitted">${scholarship.code}</span>
                            <h2 style="font-size: 1.35rem; font-weight: 700; margin-top: 0.35rem;">${scholarship.title}</h2>
                            <p style="font-size: 0.9rem; color: var(--text-secondary);">${scholarship.description}</p>
                            <div style="font-size: 0.85rem; color: var(--text-muted); margin-top: 0.35rem;">
                                Sponsored by: <strong>${scholarship.sponsor}</strong>
                            </div>
                        </div>
                        <div style="text-align: right;">
                            <div style="font-size: 0.8rem; color: var(--text-muted);">Financial Grant</div>
                            <div style="font-size: 1.75rem; font-weight: 800; color: var(--success);">
                                INR <fmt:formatNumber value="${scholarship.amount}" pattern="#,##,###"/>
                            </div>
                        </div>
                    </div>

                    <!-- Eligibility Matrix Comparison -->
                    <div class="card" style="background: #f8fafc; border: 1px solid var(--border); margin-top: 1rem;">
                        <h3 style="font-size: 1rem; font-weight: 600; margin-bottom: 0.75rem; display: flex; align-items: center; justify-content: space-between;">
                            <span>Criteria Evaluation Breakdown</span>
                            <span class="badge-status ${eligibilityResult.eligible ? 'badge-approved' : 'badge-rejected'}">
                                ${eligibilityResult.eligible ? 'QUALIFIED (' : 'NOT QUALIFIED ('}${eligibilityResult.score}%)
                            </span>
                        </h3>

                        <table class="table" style="background: #ffffff; border-radius: var(--radius-sm);">
                            <thead>
                                <tr>
                                    <th>Criteria</th>
                                    <th>Scheme Requirement</th>
                                    <th>Your Profile Data</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Academic Performance (GPA)</td>
                                    <td>Minimum <strong>${scholarship.minGpa}</strong> / 4.0</td>
                                    <td><strong>${studentProfile.currentGpa}</strong> / 4.0</td>
                                    <td>
                                        <c:choose>
                                            <c:when test="${studentProfile.currentGpa >= scholarship.minGpa}">
                                                <span style="color: var(--success); font-weight: 600;">✓ PASSED</span>
                                            </c:when>
                                            <c:otherwise>
                                                <span style="color: var(--danger); font-weight: 600;">✗ FAILED</span>
                                            </c:otherwise>
                                        </c:choose>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Family Annual Income</td>
                                    <td>Max <strong>INR <fmt:formatNumber value="${scholarship.maxAnnualIncome}" pattern="#,##,###"/></strong></td>
                                    <td><strong>INR <fmt:formatNumber value="${studentProfile.annualFamilyIncome}" pattern="#,##,###"/></strong></td>
                                    <td>
                                        <c:choose>
                                            <c:when test="${studentProfile.annualFamilyIncome <= scholarship.maxAnnualIncome}">
                                                <span style="color: var(--success); font-weight: 600;">✓ PASSED</span>
                                            </c:when>
                                            <c:otherwise>
                                                <span style="color: var(--danger); font-weight: 600;">✗ FAILED</span>
                                            </c:otherwise>
                                        </c:choose>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Category / Reservation</td>
                                    <td><strong>${scholarship.eligibleCategories}</strong></td>
                                    <td><strong>${studentProfile.category}</strong></td>
                                    <td><span style="color: var(--success); font-weight: 600;">✓ PASSED</span></td>
                                </tr>
                                <tr>
                                    <td>Application Deadline</td>
                                    <td>Valid until <strong><fmt:formatDate value="${scholarship.deadline}" pattern="dd MMM yyyy"/></strong></td>
                                    <td>Current Date: Active</td>
                                    <td><span style="color: var(--success); font-weight: 600;">✓ ACTIVE</span></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <!-- Application Submission Form -->
                    <form action="${pageContext.request.contextPath}/student/apply" method="POST" style="margin-top: 1.5rem;">
                        <input type="hidden" name="scholarshipId" value="${scholarship.id}">

                        <div class="card" style="background: #ffffff; border: 1px solid var(--border);">
                            <h4 style="font-size: 0.95rem; font-weight: 600; margin-bottom: 0.75rem;">Mandatory Supporting Documents Required for this Scheme</h4>
                            <p style="font-size: 0.85rem; color: var(--text-secondary); margin-bottom: 0.5rem;">
                                Note: Upon submitting this application, you will be directed to upload scanned copies of:
                            </p>
                            <ul style="font-size: 0.85rem; color: var(--text-secondary); margin-left: 1.5rem; margin-bottom: 1rem;">
                                <li>Income Certificate issued by Revenue Authority / Tehsildar</li>
                                <li>Previous semester grade card / Marksheet</li>
                                <li>Government-issued Identity Proof (Aadhar / PAN / Passport)</li>
                                <li>Bank Account Passbook showing IFSC and Account Holder Name</li>
                            </ul>

                            <div style="border-top: 1px solid var(--border); padding-top: 0.75rem;">
                                <label style="display: flex; align-items: flex-start; gap: 0.5rem; font-size: 0.85rem; cursor: pointer;">
                                    <input type="checkbox" required style="margin-top: 0.2rem;">
                                    <span>I hereby declare that all academic credentials, annual income details, and demographic declarations provided above are true and complete. I acknowledge that falsified submissions are subject to fraud penal action.</span>
                                </label>
                            </div>
                        </div>

                        <div style="display: flex; gap: 1rem; justify-content: flex-end; margin-top: 1rem;">
                            <a href="${pageContext.request.contextPath}/student/apply" class="btn btn-secondary">Select Different Scheme</a>
                            <button type="submit" class="btn btn-primary" ${!eligibilityResult.eligible ? 'disabled' : ''}>
                                Submit Official Application →
                            </button>
                        </div>
                    </form>
                </div>
            </c:when>

            <c:otherwise>
                <!-- Scheme Selection Grid -->
                <div class="card">
                    <h2 class="card-title" style="margin-bottom: 1rem;">Choose a Scholarship Scheme to Apply</h2>
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 1.25rem;">
                        <c:forEach var="sch" items="${scholarshipsList}">
                            <div style="border: 1px solid var(--border); border-radius: var(--radius-md); padding: 1.25rem; display: flex; flex-direction: column; justify-content: space-between;">
                                <div>
                                    <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 0.5rem;">
                                        <span class="badge-status badge-submitted">${sch.code}</span>
                                        <span style="font-weight: 700; color: var(--success); font-size: 1.15rem;">
                                            INR <fmt:formatNumber value="${sch.amount}" pattern="#,##,###"/>
                                        </span>
                                    </div>
                                    <h3 style="font-size: 1.1rem; font-weight: 600; margin-bottom: 0.4rem;">${sch.title}</h3>
                                    <p style="font-size: 0.85rem; color: var(--text-secondary); margin-bottom: 0.75rem;">${sch.description}</p>
                                </div>
                                <div style="margin-top: 1rem;">
                                    <a href="${pageContext.request.contextPath}/student/apply?id=${sch.id}" class="btn btn-primary btn-sm" style="width: 100%;">
                                        Evaluate & Apply →
                                    </a>
                                </div>
                            </div>
                        </c:forEach>
                    </div>
                </div>
            </c:otherwise>
        </c:choose>
    </div>

    <footer class="footer">
        <div>National Scholarship Verification System &copy; 2026. Java 11 / Tomcat 9 Architecture.</div>
    </footer>
</body>
</html>
