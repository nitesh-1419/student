<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Application Tracking & Document Upload - Scholarship Verification System</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/app.css">
    <style>
        .timeline {
            display: flex;
            justify-content: space-between;
            position: relative;
            margin: 2rem 0;
        }
        .timeline::before {
            content: '';
            position: absolute;
            top: 20px;
            left: 20px;
            right: 20px;
            height: 4px;
            background: #e2e8f0;
            z-index: 1;
        }
        .timeline-step {
            position: relative;
            z-index: 2;
            text-align: center;
            flex: 1;
        }
        .step-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #ffffff;
            border: 3px solid #cbd5e1;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 0.5rem;
            font-weight: 700;
            font-size: 0.9rem;
            color: var(--text-muted);
        }
        .timeline-step.completed .step-icon {
            background: var(--success);
            border-color: var(--success);
            color: #ffffff;
        }
        .timeline-step.active .step-icon {
            background: var(--primary);
            border-color: var(--primary);
            color: #ffffff;
            box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.2);
        }
        .step-title {
            font-size: 0.8rem;
            font-weight: 600;
            color: var(--text-secondary);
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <a href="${pageContext.request.contextPath}/student/dashboard" class="navbar-brand">
            <span>🎓 Student Portal</span>
        </a>
        <div class="nav-links">
            <a href="${pageContext.request.contextPath}/student/dashboard" class="nav-link">Dashboard</a>
            <a href="${pageContext.request.contextPath}/student/apply" class="nav-link">Apply</a>
            <a href="${pageContext.request.contextPath}/student/tracking" class="nav-link active">Tracking</a>
            <div class="nav-user">
                <span>👤 ${sessionScope.currentUser.fullName}</span>
            </div>
            <form action="${pageContext.request.contextPath}/logout" method="POST" style="margin: 0;">
                <button type="submit" class="btn btn-secondary btn-sm">Sign Out</button>
            </form>
        </div>
    </nav>

    <div class="container">
        <div class="page-header">
            <div>
                <h1 class="page-title">Application Status Tracking</h1>
                <div class="page-subtitle">Track verification progress, review officer remarks, and manage supporting documents.</div>
            </div>
            <div>
                <a href="${pageContext.request.contextPath}/student/dashboard" class="btn btn-secondary btn-sm">← Back to Dashboard</a>
            </div>
        </div>

        <c:if test="${not empty param.upload_success}">
            <div class="alert alert-success">
                <span>✓</span>
                <span>Document successfully uploaded! Verification status is now updated.</span>
            </div>
        </c:if>

        <c:if test="${not empty param.resubmitted}">
            <div class="alert alert-success">
                <span>✓</span>
                <span>Your application has been resubmitted with updated documents. The verification officer has been notified.</span>
            </div>
        </c:if>

        <c:choose>
            <c:when test="${not empty application}">
                <!-- Application Overview Card -->
                <div class="card">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 1rem;">
                        <div>
                            <div style="display: flex; align-items: center; gap: 0.75rem;">
                                <h2 style="font-size: 1.4rem; font-weight: 700;">${application.applicationNo}</h2>
                                <c:choose>
                                    <c:when test="${application.status == 'SUBMITTED'}"><span class="badge-status badge-submitted">Submitted</span></c:when>
                                    <c:when test="${application.status == 'UNDER_REVIEW'}"><span class="badge-status badge-under-review">Under Review</span></c:when>
                                    <c:when test="${application.status == 'APPROVED'}"><span class="badge-status badge-approved">Approved</span></c:when>
                                    <c:when test="${application.status == 'REJECTED'}"><span class="badge-status badge-rejected">Rejected</span></c:when>
                                    <c:when test="${application.status == 'RESUBMISSION_REQUESTED'}"><span class="badge-status badge-resubmit">Resubmission Requested</span></c:when>
                                </c:choose>
                            </div>
                            <div style="font-size: 1rem; color: var(--text-secondary); margin-top: 0.35rem;">
                                Scholarship: <strong>${application.scholarshipTitle}</strong> | 
                                Grant Amount: <strong>INR <fmt:formatNumber value="${application.scholarshipAmount}" pattern="#,##,###"/></strong>
                            </div>
                        </div>
                        <div style="text-align: right;">
                            <div style="font-size: 0.8rem; color: var(--text-muted);">Eligibility Score: <strong>${application.eligibilityScore}%</strong></div>
                            <div style="font-size: 0.8rem; color: var(--text-muted); margin-top: 0.25rem;">
                                Applied on: <fmt:formatDate value="${application.appliedDate}" pattern="dd MMM yyyy, hh:mm a"/>
                            </div>
                        </div>
                    </div>

                    <!-- Workflow Step Progress Timeline -->
                    <div class="timeline">
                        <div class="timeline-step completed">
                            <div class="step-icon">1</div>
                            <div class="step-title">Submitted</div>
                        </div>
                        <div class="timeline-step ${application.status != 'SUBMITTED' ? 'completed' : 'active'}">
                            <div class="step-icon">2</div>
                            <div class="step-title">Under Review</div>
                        </div>
                        <div class="timeline-step ${application.status == 'APPROVED' ? 'completed' : (application.status == 'UNDER_REVIEW' || application.status == 'RESUBMISSION_REQUESTED' ? 'active' : '')}">
                            <div class="step-icon">3</div>
                            <div class="step-title">Document Verification</div>
                        </div>
                        <div class="timeline-step ${application.status == 'APPROVED' ? 'completed' : (application.status == 'REJECTED' ? 'active' : '')}">
                            <div class="step-icon">${application.status == 'APPROVED' ? '✓' : (application.status == 'REJECTED' ? '✗' : '4')}</div>
                            <div class="step-title">${application.status == 'REJECTED' ? 'Rejected' : 'Disbursement'}</div>
                        </div>
                    </div>

                    <!-- Officer Feedback / Resubmission Request Banner -->
                    <c:if test="${application.status == 'RESUBMISSION_REQUESTED'}">
                        <div class="alert alert-warning" style="display: block;">
                            <div style="font-weight: 700; font-size: 1rem; margin-bottom: 0.35rem;">⚠️ Officer Requested Changes:</div>
                            <p style="margin-bottom: 0.5rem;">${application.officerRemarks}</p>
                            <p style="font-size: 0.85rem; color: var(--text-secondary);">
                                Please review your rejected documents below, upload valid clear replacements, and click the <strong>Resubmit Application</strong> button.
                            </p>
                        </div>
                    </c:if>

                    <c:if test="${not empty application.officerRemarks && application.status != 'RESUBMISSION_REQUESTED'}">
                        <div class="card" style="background: #f8fafc; border: 1px solid var(--border); margin-top: 1rem;">
                            <div style="font-weight: 600; font-size: 0.9rem; margin-bottom: 0.25rem;">Officer Review Remarks:</div>
                            <p style="font-size: 0.9rem; color: var(--text-secondary);">${application.officerRemarks}</p>
                        </div>
                    </c:if>
                </div>

                <!-- Upload Documents Section -->
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">Upload Supporting Verification Documents</h2>
                        <span style="font-size: 0.8rem; color: var(--text-muted);">PDF, JPG, PNG (Max 10MB)</span>
                    </div>

                    <form action="${pageContext.request.contextPath}/student/uploadDocument" method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="applicationId" value="${application.id}">

                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label" for="docTypeSelect">Document Category *</label>
                                <select id="docTypeSelect" name="docType" class="form-control" required>
                                    <option value="INCOME_CERTIFICATE">Income Certificate (Tehsildar / SDO)</option>
                                    <option value="MARKSHEET">Academic Marksheet / Transcript</option>
                                    <option value="IDENTITY_PROOF">Identity Proof (Aadhar / PAN / Passport)</option>
                                    <option value="BANK_PASSBOOK">Bank Passbook / Cancelled Cheque</option>
                                    <option value="CASTE_CERTIFICATE">Caste / EWS Certificate (If applicable)</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label class="form-label" for="docFileInput">Select File *</label>
                                <input type="file" id="docFileInput" name="documentFile" class="form-control" accept=".pdf,.jpg,.jpeg,.png" required>
                            </div>

                            <div class="form-group" style="display: flex; align-items: flex-end;">
                                <button type="submit" class="btn btn-primary" style="width: 100%;">
                                    Upload Document ⤒
                                </button>
                            </div>
                        </div>
                    </form>

                    <!-- Document Table -->
                    <div class="table-responsive" style="margin-top: 1.5rem;">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Document Type</th>
                                    <th>File Name</th>
                                    <th>File Size</th>
                                    <th>Uploaded At</th>
                                    <th>Verification Status</th>
                                    <th>Remarks / Reason</th>
                                </tr>
                            </thead>
                            <tbody>
                                <c:choose>
                                    <c:when test="${empty application.documents}">
                                        <tr>
                                            <td colspan="6" style="text-align: center; color: var(--text-muted); padding: 1.5rem;">
                                                No documents uploaded yet. Please upload required certificates above.
                                            </td>
                                        </tr>
                                    </c:when>
                                    <c:otherwise>
                                        <c:forEach var="doc" items="${application.documents}">
                                            <tr>
                                                <td><strong>${doc.docType}</strong></td>
                                                <td>📄 ${doc.fileName}</td>
                                                <td><fmt:formatNumber value="${doc.fileSize / 1024}" pattern="#,##0"/> KB</td>
                                                <td><fmt:formatDate value="${doc.uploadedAt}" pattern="dd MMM yyyy, hh:mm a"/></td>
                                                <td>
                                                    <c:choose>
                                                        <c:when test="${doc.verificationStatus == 'VERIFIED'}">
                                                            <span class="badge-status badge-approved">Verified ✓</span>
                                                        </c:when>
                                                        <c:when test="${doc.verificationStatus == 'REJECTED'}">
                                                            <span class="badge-status badge-rejected">Rejected ✗</span>
                                                        </c:when>
                                                        <c:otherwise>
                                                            <span class="badge-status badge-under-review">Pending Verification</span>
                                                        </c:otherwise>
                                                    </c:choose>
                                                </td>
                                                <td>
                                                    <c:out value="${doc.rejectionReason}" default="—"/>
                                                </td>
                                            </tr>
                                        </c:forEach>
                                    </c:otherwise>
                                </c:choose>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Resubmission Form (if applicable) -->
                <c:if test="${application.status == 'RESUBMISSION_REQUESTED'}">
                    <div class="card" style="border: 2px dashed var(--warning);">
                        <h3 class="card-title" style="color: var(--warning); margin-bottom: 0.75rem;">Resubmit Application with Corrections</h3>
                        <form action="${pageContext.request.contextPath}/student/resubmit" method="POST">
                            <input type="hidden" name="applicationId" value="${application.id}">
                            <div class="form-group">
                                <label class="form-label">Notes for the Verification Officer (Explain fixes made)</label>
                                <textarea name="studentNotes" class="form-control" rows="3" placeholder="I have uploaded the renewed caste certificate and higher resolution scan of the income certificate as requested."></textarea>
                            </div>
                            <button type="submit" class="btn btn-warning">
                                Confirm & Resubmit Application for Review →
                            </button>
                        </form>
                    </div>
                </c:if>

            </c:when>
            <c:otherwise>
                <!-- Application Selection List -->
                <div class="card">
                    <h2 class="card-title">Select an Application to Track</h2>
                    <div class="table-responsive" style="margin-top: 1rem;">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Application No</th>
                                    <th>Scheme</th>
                                    <th>Applied Date</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <c:forEach var="app" items="${studentApplications}">
                                    <tr>
                                        <td><strong>${app.applicationNo}</strong></td>
                                        <td>${app.scholarshipTitle}</td>
                                        <td><fmt:formatDate value="${app.appliedDate}" pattern="dd MMM yyyy"/></td>
                                        <td><span class="badge-status badge-submitted">${app.status}</span></td>
                                        <td>
                                            <a href="${pageContext.request.contextPath}/student/tracking?appId=${app.id}" class="btn btn-primary btn-sm">
                                                Track Details →
                                            </a>
                                        </td>
                                    </tr>
                                </c:forEach>
                            </tbody>
                        </table>
                    </div>
                </div>
            </c:otherwise>
        </c:choose>
    </div>

    <footer class="footer">
        <div>National Scholarship Verification System &copy; 2026. Java 11 / Tomcat 9 Architecture.</div>
    </footer>
</body>
</html>
