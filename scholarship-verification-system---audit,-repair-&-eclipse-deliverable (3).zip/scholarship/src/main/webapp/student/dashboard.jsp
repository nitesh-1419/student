<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard - Scholarship Verification System</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/app.css">
</head>
<body>

    <!-- Animated Ambient Glowing Orbs Background -->
    <div class="ambient-background">
        <div class="ambient-orb ambient-orb-1"></div>
        <div class="ambient-orb ambient-orb-2"></div>
        <div class="ambient-orb ambient-orb-3"></div>
    </div>

    <nav class="glass-nav">
        <a href="${pageContext.request.contextPath}/student/dashboard" class="navbar-brand">
            <span>🎓 Student Portal</span>
        </a>
        <div class="nav-links">
            <a href="${pageContext.request.contextPath}/student/dashboard" class="nav-link active">Dashboard</a>
            <a href="${pageContext.request.contextPath}/student/apply" class="nav-link">Apply for Scholarship</a>
            <!-- Audio Sound Toggle Button -->
            <button type="button" class="btn btn-glass sound-toggle-btn" title="Toggle Sound Feedback">
                <span class="icon">🔊</span> Sound On
            </button>
            <!-- Dark / Light Theme Toggle Button -->
            <button type="button" class="btn btn-glass theme-toggle-btn" title="Switch Theme">
                <span class="icon">☀️</span> Light Mode
            </button>
            <div class="nav-user">
                <span>👤 ${sessionScope.currentUser.fullName} (Student)</span>
            </div>
            <form action="${pageContext.request.contextPath}/logout" method="POST" style="margin: 0;">
                <input type="hidden" name="csrfToken" value="${sessionScope.csrfToken}">
                <button type="submit" class="btn btn-glass btn-sm">Sign Out</button>
            </form>
        </div>
    </nav>

    <div class="container">
        <!-- Student Academic Banner -->
        <div class="card" style="background: linear-gradient(to right, #ffffff, #f1f5f9);">
            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem;">
                <div>
                    <h1 class="page-title">${sessionScope.currentUser.fullName}</h1>
                    <div class="page-subtitle">
                        Roll No: <strong>${studentProfile.rollNumber}</strong> | 
                        Course: <strong>${studentProfile.course} (${studentProfile.department})</strong> | 
                        Year: <strong>Year ${studentProfile.yearOfStudy}</strong>
                    </div>
                </div>
                <div style="display: flex; gap: 1.5rem; text-align: right;">
                    <div>
                        <div style="font-size: 0.75rem; color: var(--text-muted); text-transform: uppercase;">Cumulative GPA</div>
                        <div style="font-size: 1.5rem; font-weight: 700; color: var(--primary);">${studentProfile.currentGpa} / 4.0</div>
                    </div>
                    <div>
                        <div style="font-size: 0.75rem; color: var(--text-muted); text-transform: uppercase;">Family Income</div>
                        <div style="font-size: 1.5rem; font-weight: 700; color: var(--secondary);">INR <fmt:formatNumber value="${studentProfile.annualFamilyIncome}" pattern="#,##,###"/></div>
                    </div>
                    <div>
                        <div style="font-size: 0.75rem; color: var(--text-muted); text-transform: uppercase;">Category</div>
                        <div style="font-size: 1.5rem; font-weight: 700; color: var(--text-primary);">${studentProfile.category}</div>
                    </div>
                </div>
            </div>
        </div>

        <c:if test="${not empty param.submitted}">
            <div class="alert alert-success">
                <span>✓</span>
                <span>Your scholarship application has been successfully submitted! Upload your verification documents below to initiate officer review.</span>
            </div>
        </c:if>

        <!-- Applications Section -->
        <div class="card">
            <div class="card-header">
                <h2 class="card-title">My Submitted Applications</h2>
                <a href="${pageContext.request.contextPath}/student/apply" class="btn btn-primary btn-sm">+ Apply New Scheme</a>
            </div>

            <c:choose>
                <c:when test="${empty myApplications}">
                    <div style="text-align: center; padding: 2rem; color: var(--text-muted);">
                        <p style="font-size: 1.1rem; margin-bottom: 1rem;">You have not applied for any scholarships yet.</p>
                        <a href="${pageContext.request.contextPath}/student/apply" class="btn btn-primary">Browse Available Schemes</a>
                    </div>
                </c:when>
                <c:otherwise>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Application No</th>
                                    <th>Scholarship Scheme</th>
                                    <th>Amount</th>
                                    <th>Submission Date</th>
                                    <th>Eligibility Score</th>
                                    <th>Current Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <c:forEach var="app" items="${myApplications}">
                                    <tr>
                                        <td><strong>${app.applicationNo}</strong></td>
                                        <td>${app.scholarshipTitle}</td>
                                        <td>INR <fmt:formatNumber value="${app.scholarshipAmount}" pattern="#,##,###"/></td>
                                        <td><fmt:formatDate value="${app.appliedDate}" pattern="dd MMM yyyy, hh:mm a"/></td>
                                        <td>
                                            <span style="font-weight: 600; color: ${app.eligibilityScore >= 75 ? 'var(--success)' : 'var(--warning)'};">
                                                ${app.eligibilityScore}%
                                            </span>
                                        </td>
                                        <td>
                                            <c:choose>
                                                <c:when test="${app.status == 'SUBMITTED'}"><span class="badge-status badge-submitted">Submitted</span></c:when>
                                                <c:when test="${app.status == 'UNDER_REVIEW'}"><span class="badge-status badge-under-review">Under Review</span></c:when>
                                                <c:when test="${app.status == 'APPROVED'}"><span class="badge-status badge-approved">Approved</span></c:when>
                                                <c:when test="${app.status == 'REJECTED'}"><span class="badge-status badge-rejected">Rejected</span></c:when>
                                                <c:when test="${app.status == 'RESUBMISSION_REQUESTED'}"><span class="badge-status badge-resubmit">Action Required</span></c:when>
                                                <c:otherwise><span class="badge-status badge-submitted">${app.status}</span></c:otherwise>
                                            </c:choose>
                                        </td>
                                        <td>
                                            <a href="${pageContext.request.contextPath}/student/tracking?appId=${app.id}" class="btn btn-secondary btn-sm">
                                                Track & Documents →
                                            </a>
                                        </td>
                                    </tr>
                                </c:forEach>
                            </tbody>
                        </table>
                    </div>
                </c:otherwise>
            </c:choose>
        </div>

        <!-- Available Schemes Section -->
        <div class="card">
            <div class="card-header">
                <h2 class="card-title">Available Active Scholarships</h2>
                <span style="font-size: 0.85rem; color: var(--text-muted);">${activeScholarships.size()} active schemes</span>
            </div>

            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 1.25rem;">
                <c:forEach var="sch" items="${activeScholarships}">
                    <div style="border: 1px solid var(--border); border-radius: var(--radius-md); padding: 1.25rem; display: flex; flex-direction: column; justify-content: space-between;">
                        <div>
                            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 0.5rem;">
                                <span class="badge-status badge-submitted">${sch.code}</span>
                                <span style="font-weight: 700; color: var(--success); font-size: 1.15rem;">
                                    INR <fmt:formatNumber value="${sch.amount}" pattern="#,##,###"/>
                                </span>
                            </div>
                            <h3 style="font-size: 1.1rem; font-weight: 600; margin-bottom: 0.4rem;">${sch.title}</h3>
                            <p style="font-size: 0.85rem; color: var(--text-secondary); margin-bottom: 0.75rem;">${sch.description}</p>
                            
                            <div style="font-size: 0.8rem; color: var(--text-muted); display: grid; grid-template-columns: 1fr 1fr; gap: 0.25rem; margin-bottom: 1rem; background: #f8fafc; padding: 0.5rem; border-radius: var(--radius-sm);">
                                <div>Min GPA: <strong>${sch.minGpa}</strong></div>
                                <div>Max Income: <strong>INR <fmt:formatNumber value="${sch.maxAnnualIncome}" pattern="#,##,###"/></strong></div>
                                <div>Categories: <strong>${sch.eligibleCategories}</strong></div>
                                <div>Deadline: <strong><fmt:formatDate value="${sch.deadline}" pattern="dd MMM yyyy"/></strong></div>
                            </div>
                        </div>

                        <div>
                            <a href="${pageContext.request.contextPath}/student/apply?id=${sch.id}" class="btn btn-primary btn-sm" style="width: 100%;">
                                Check Eligibility & Apply Now
                            </a>
                        </div>
                    </div>
                </c:forEach>
            </div>
        </div>
    </div>

    <footer class="footer">
        <div>National Scholarship Verification System &copy; 2026. Java 11 / Tomcat 9 Architecture.</div>
    </footer>
    <script src="${pageContext.request.contextPath}/assets/app.js"></script>
</body>
</html>
