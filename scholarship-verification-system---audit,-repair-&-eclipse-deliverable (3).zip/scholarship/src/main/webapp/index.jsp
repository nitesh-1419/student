<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scholarship Verification System - Official Portal</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/app.css">
    <style>
        .auth-container {
            max-width: 1040px;
            margin: 2.5rem auto;
            display: grid;
            grid-template-columns: 1.1fr 1fr;
            border-radius: var(--radius-lg);
            overflow: hidden;
        }
        .auth-hero {
            background: linear-gradient(135deg, rgba(15, 23, 42, 0.85) 0%, rgba(30, 58, 138, 0.8) 50%, rgba(13, 148, 136, 0.75) 100%);
            padding: 3rem 2.5rem;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            border-right: 1px solid var(--glass-border);
        }
        .auth-form-panel {
            padding: 2.5rem;
            background: var(--glass-bg);
            backdrop-filter: var(--glass-blur);
        }
        .role-pill-group {
            display: flex;
            gap: 0.5rem;
            margin-bottom: 1.5rem;
            background: var(--glass-bg-subtle);
            padding: 0.35rem;
            border-radius: var(--radius-md);
            border: 1px solid var(--glass-border);
        }
        .role-pill {
            flex: 1;
            padding: 0.5rem;
            text-align: center;
            font-size: 0.8rem;
            font-weight: 600;
            border-radius: var(--radius-sm);
            cursor: pointer;
            border: none;
            background: transparent;
            color: var(--text-secondary);
            transition: all 0.15s ease;
        }
        .role-pill.active {
            background: var(--primary);
            color: #ffffff;
            box-shadow: 0 2px 8px var(--primary-glow);
        }
        .demo-cred-box {
            background: var(--glass-bg-subtle);
            border: 1px solid var(--glass-border);
            padding: 1rem;
            border-radius: var(--radius-md);
            font-size: 0.8rem;
            margin-top: 1.5rem;
        }
        .form-group {
            margin-bottom: 1.25rem;
        }
        .form-label {
            display: block;
            font-size: 0.825rem;
            font-weight: 600;
            margin-bottom: 0.4rem;
            color: var(--text-secondary);
        }
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }
        @media (max-width: 860px) {
            .auth-container {
                grid-template-columns: 1fr;
            }
            .form-row {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>

    <!-- Animated Ambient Glowing Orbs Background -->
    <div class="ambient-background">
        <div class="ambient-orb ambient-orb-1"></div>
        <div class="ambient-orb ambient-orb-2"></div>
        <div class="ambient-orb ambient-orb-3"></div>
    </div>

    <!-- Glassmorphic Navbar with Dark/Light & Sound Controls -->
    <nav class="glass-nav">
        <a href="${pageContext.request.contextPath}/" class="navbar-brand">
            <span>🎓 National Scholarship Verification Portal</span>
            <span style="font-size: 0.7rem; padding: 0.2rem 0.5rem; background: var(--glass-bg-subtle); border-radius: 9999px; border: 1px solid var(--glass-border);">Java 11 · Tomcat 9</span>
        </a>
        <div class="nav-actions">
            <!-- Audio Sound Toggle Button -->
            <button type="button" class="btn btn-glass sound-toggle-btn" title="Toggle Sound Feedback">
                <span class="icon">🔊</span> Sound On
            </button>
            <!-- Dark / Light Theme Toggle Button -->
            <button type="button" class="btn btn-glass theme-toggle-btn" title="Switch Theme">
                <span class="icon">☀️</span> Light Mode
            </button>
        </div>
    </nav>

    <div class="container">
        <c:if test="${not empty param.error}">
            <div style="padding: 1rem; margin-bottom: 1.5rem; border-radius: var(--radius-sm); background: rgba(239, 68, 68, 0.15); border: 1px solid var(--danger); color: var(--danger); display: flex; align-items: center; gap: 0.75rem;">
                <span>⚠️</span>
                <span>
                    <c:choose>
                        <c:when test="${param.error == 'session_expired'}">Your session has expired. Please log in again to continue.</c:when>
                        <c:when test="${param.error == 'unauthorized'}">Access denied. You do not possess the required credentials for that resource.</c:when>
                        <c:when test="${param.error == '404_not_found'}">The requested resource could not be found (HTTP 404).</c:when>
                        <c:otherwise>An authentication error occurred. Please verify your credentials.</c:otherwise>
                    </c:choose>
                </span>
            </div>
        </c:if>

        <c:if test="${not empty errorMessage}">
            <div style="padding: 1rem; margin-bottom: 1.5rem; border-radius: var(--radius-sm); background: rgba(239, 68, 68, 0.15); border: 1px solid var(--danger); color: var(--danger);">
                ⚠️ ${errorMessage}
            </div>
        </c:if>

        <c:if test="${not empty successMessage}">
            <div style="padding: 1rem; margin-bottom: 1.5rem; border-radius: var(--radius-sm); background: rgba(16, 185, 129, 0.15); border: 1px solid var(--success); color: var(--success);">
                ✓ ${successMessage}
            </div>
        </c:if>

        <div class="glass-panel auth-container">
            <!-- LEFT HERO SECTION -->
            <div class="auth-hero">
                <div>
                    <h1 style="font-size: 1.75rem; font-weight: 800; margin-bottom: 0.75rem; line-height: 1.2;">
                        Advanced Scholarship Management, Verification & Fraud-Risk Assistance System
                    </h1>
                    <p style="color: rgba(255, 255, 255, 0.85); font-size: 0.925rem; line-height: 1.6; margin-bottom: 2rem;">
                        Automated multi-factor eligibility verification, document integrity screening with SHA-256 duplicate collision checks, and role-governed verification queues for universities and ministries.
                    </p>

                    <div style="display: flex; flex-direction: column; gap: 0.75rem; font-size: 0.85rem; color: rgba(255, 255, 255, 0.9);">
                        <div>✓ Multi-step student application and real-time status tracker</div>
                        <div>✓ Explainable fraud indicators (income tiering & duplicate certificates)</div>
                        <div>✓ PBKDF2WithHmacSHA256 password security with unique cryptographic salts</div>
                        <div>✓ Strict CSRF defense and object-level authorization (IDOR protection)</div>
                    </div>
                </div>

                <div class="demo-cred-box">
                    <div style="font-weight: 700; margin-bottom: 0.5rem; color: #ffffff;">🔑 Verified Demo Accounts (MySQL 8 Seed):</div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.4rem; font-size: 0.75rem; color: rgba(255, 255, 255, 0.8);">
                        <div><strong>Admin:</strong> admin / Password@123</div>
                        <div><strong>Officer:</strong> officer1 / Password@123</div>
                        <div><strong>Student:</strong> rahul_sharma / Password@123</div>
                        <div><strong>Student:</strong> priya_patel / Password@123</div>
                    </div>
                </div>
            </div>

            <!-- RIGHT FORM SECTION -->
            <div class="auth-form-panel">
                <div class="role-pill-group">
                    <button type="button" id="tabLoginBtn" class="role-pill active" onclick="switchTab('login')">
                        Portal Sign In
                    </button>
                    <button type="button" id="tabRegisterBtn" class="role-pill" onclick="switchTab('register')">
                        New Student Registration
                    </button>
                </div>

                <!-- LOGIN FORM -->
                <div id="loginFormSection">
                    <h2 style="font-size: 1.25rem; font-weight: 700; margin-bottom: 1.25rem;">Sign In to Your Account</h2>
                    
                    <form action="${pageContext.request.contextPath}/login" method="POST">
                        <input type="hidden" name="csrfToken" value="${sessionScope.csrfToken}">

                        <div class="form-group">
                            <label class="form-label" for="loginUser">Username or Roll Number</label>
                            <input type="text" id="loginUser" name="username" class="glass-input" placeholder="e.g. rahul_sharma or officer1" required value="${param.username}">
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="loginPass">Password</label>
                            <input type="password" id="loginPass" name="password" class="glass-input" placeholder="••••••••" required>
                        </div>

                        <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 0.75rem;">
                            Sign In to Portal →
                        </button>
                    </form>
                </div>

                <!-- REGISTRATION FORM -->
                <div id="registerFormSection" style="display: none;">
                    <h2 style="font-size: 1.25rem; font-weight: 700; margin-bottom: 1.25rem;">Student Profile Registration</h2>

                    <form action="${pageContext.request.contextPath}/register" method="POST">
                        <input type="hidden" name="action" value="register">
                        <input type="hidden" name="csrfToken" value="${sessionScope.csrfToken}">

                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Full Name *</label>
                                <input type="text" name="fullName" class="glass-input" required placeholder="John Doe">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Username *</label>
                                <input type="text" name="username" class="glass-input" required placeholder="johndoe">
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Email Address *</label>
                                <input type="email" name="email" class="glass-input" required placeholder="john@campus.edu">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Password *</label>
                                <input type="password" name="password" class="glass-input" required minlength="6" placeholder="Min 6 characters">
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">College Roll Number *</label>
                                <input type="text" name="rollNumber" class="glass-input" required placeholder="CS-2026-001">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Current Cumulative GPA *</label>
                                <input type="number" step="0.01" min="0" max="4.0" name="currentGpa" class="glass-input" required placeholder="3.85">
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Annual Family Income (INR) *</label>
                                <input type="number" step="1000" name="annualFamilyIncome" class="glass-input" required placeholder="250000">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Social Category *</label>
                                <select name="category" class="glass-input" required>
                                    <option value="GENERAL">General</option>
                                    <option value="OBC">OBC (Other Backward Class)</option>
                                    <option value="SC">SC (Scheduled Caste)</option>
                                    <option value="ST">ST (Scheduled Tribe)</option>
                                    <option value="EWS">EWS (Economically Weaker Section)</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Department / Branch</label>
                                <input type="text" name="department" class="glass-input" placeholder="Computer Science">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Course</label>
                                <input type="text" name="course" class="glass-input" placeholder="B.Tech / M.Tech">
                            </div>
                        </div>

                        <button type="submit" class="btn btn-success" style="width: 100%; margin-top: 0.75rem;">
                            Complete Registration & Sign In →
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="${pageContext.request.contextPath}/assets/app.js"></script>
    <script>
        function switchTab(tab) {
            const loginSection = document.getElementById('loginFormSection');
            const regSection = document.getElementById('registerFormSection');
            const tabLogin = document.getElementById('tabLoginBtn');
            const tabReg = document.getElementById('tabRegisterBtn');

            if (tab === 'login') {
                loginSection.style.display = 'block';
                regSection.style.display = 'none';
                tabLogin.classList.add('active');
                tabReg.classList.remove('active');
            } else {
                loginSection.style.display = 'none';
                regSection.style.display = 'block';
                tabLogin.classList.remove('active');
                tabReg.classList.add('active');
            }
        }
    </script>
</body>
</html>
