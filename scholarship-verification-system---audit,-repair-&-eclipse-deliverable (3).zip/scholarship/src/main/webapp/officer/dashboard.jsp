<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Officer Workbench - Scholarship Verification System</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/app.css">
    <style>
        .split-workbench {
            display: grid;
            grid-template-columns: 1fr 1.25fr;
            gap: 1.5rem;
        }
        @media (max-width: 900px) {
            .split-workbench { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

    <!-- Animated Ambient Glowing Orbs Background -->
    <div class="ambient-background">
        <div class="ambient-orb ambient-orb-1"></div>
        <div class="ambient-orb ambient-orb-2"></div>
        <div class="ambient-orb ambient-orb-3"></div>
    </div>

    <nav class="glass-nav">
        <a href="${pageContext.request.contextPath}/officer/dashboard" class="navbar-brand">
            <span>🛡️ Verification Officer Workbench</span>
            <span style="font-size: 0.7rem; padding: 0.2rem 0.5rem; background: var(--glass-bg-subtle); border-radius: 9999px; border: 1px solid var(--glass-border);">Officer Portal</span>
        </a>
        <div class="nav-links">
            <a href="${pageContext.request.contextPath}/officer/dashboard" class="nav-link active">Verification Queue</a>
            <!-- Audio Sound Toggle Button -->
            <button type="button" class="btn btn-glass sound-toggle-btn" title="Toggle Sound Feedback">
                <span class="icon">🔊</span> Sound On
            </button>
            <!-- Dark / Light Theme Toggle Button -->
            <button type="button" class="btn btn-glass theme-toggle-btn" title="Switch Theme">
                <span class="icon">☀️</span> Light Mode
            </button>
            <div class="nav-user">
                <span>👤 ${sessionScope.currentUser.fullName} (${sessionScope.currentUser.role})</span>
            </div>
            <form action="${pageContext.request.contextPath}/logout" method="POST" style="margin: 0;">
                <input type="hidden" name="csrfToken" value="${sessionScope.csrfToken}">
                <button type="submit" class="btn btn-glass btn-sm">Sign Out</button>
            </form>
        </div>
    </nav>

    <div class="container">
        <!-- Top Stats Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <span class="stat-label">Total Submissions</span>
                <span class="stat-value">${stats.total}</span>
                <span class="stat-desc">Lifetime submissions</span>
            </div>
            <div class="stat-card" style="border-left: 4px solid var(--info);">
                <span class="stat-label">Pending / Submitted</span>
                <span class="stat-value" style="color: var(--info);">${stats.submitted}</span>
                <span class="stat-desc">Awaiting first review</span>
            </div>
            <div class="stat-card" style="border-left: 4px solid var(--warning);">
                <span class="stat-label">Under Active Review</span>
                <span class="stat-value" style="color: var(--warning);">${stats.under_review}</span>
                <span class="stat-desc">Document verification in progress</span>
            </div>
            <div class="stat-card" style="border-left: 4px solid var(--success);">
                <span class="stat-label">Approved Grants</span>
                <span class="stat-value" style="color: var(--success);">${stats.approved}</span>
                <span class="stat-desc">Cleared for disbursement</span>
            </div>
            <div class="stat-card" style="border-left: 4px solid var(--danger);">
                <span class="stat-label">Action / Resubmit</span>
                <span class="stat-value" style="color: var(--danger);">${stats.resubmit}</span>
                <span class="stat-desc">Flagged for document corrections</span>
            </div>
        </div>

        <c:if test="${not empty param.status_msg}">
            <div class="alert alert-success">
                <span>✓</span>
                <span>Application verification status successfully updated to <strong>${param.status_msg}</strong>. Audit trail recorded.</span>
            </div>
        </c:if>

        <c:if test="${not empty param.doc_updated}">
            <div class="alert alert-info">
                <span>✓</span>
                <span>Document verification flag updated.</span>
            </div>
        </c:if>

        <!-- Main Workbench Layout -->
        <div class="split-workbench">
            <!-- Left: Application Queue List -->
            <div>
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">Verification Queue</h2>
                        <div style="display: flex; gap: 0.35rem; flex-wrap: wrap;">
                            <a href="${pageContext.request.contextPath}/officer/dashboard" class="btn btn-sm ${currentFilter == 'ALL' ? 'btn-primary' : 'btn-secondary'}">All</a>
                            <a href="${pageContext.request.contextPath}/officer/dashboard?status=SUBMITTED" class="btn btn-sm ${currentFilter == 'SUBMITTED' ? 'btn-primary' : 'btn-secondary'}">New</a>
                            <a href="${pageContext.request.contextPath}/officer/dashboard?status=UNDER_REVIEW" class="btn btn-sm ${currentFilter == 'UNDER_REVIEW' ? 'btn-primary' : 'btn-secondary'}">In Review</a>
                            <a href="${pageContext.request.contextPath}/officer/dashboard?status=APPROVED" class="btn btn-sm ${currentFilter == 'APPROVED' ? 'btn-primary' : 'btn-secondary'}">Approved</a>
                            <a href="${pageContext.request.contextPath}/officer/dashboard?status=RESUBMISSION_REQUESTED" class="btn btn-sm ${currentFilter == 'RESUBMISSION_REQUESTED' ? 'btn-primary' : 'btn-secondary'}">Resubmit</a>
                        </div>
                    </div>

                    <div style="display: flex; flex-direction: column; gap: 0.75rem; max-height: 600px; overflow-y: auto;">
                        <c:choose>
                            <c:when test="${empty applications}">
                                <div style="text-align: center; color: var(--text-muted); padding: 2rem;">
                                    No applications match the selected filter.
                                </div>
                            </c:when>
                            <c:otherwise>
                                <c:forEach var="app" items="${applications}">
                                    <a href="${pageContext.request.contextPath}/officer/dashboard?status=${currentFilter}&reviewAppId=${app.id}" 
                                       style="text-decoration: none; color: inherit; display: block; border: 1px solid ${selectedApp.id == app.id ? 'var(--primary)' : 'var(--border)'}; background: ${selectedApp.id == app.id ? '#eff6ff' : '#ffffff'}; border-radius: var(--radius-sm); padding: 0.85rem; transition: border-color 0.15s ease;">
                                        <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                                            <div>
                                                <div style="font-weight: 700; font-size: 0.95rem;">${app.applicationNo}</div>
                                                <div style="font-size: 0.85rem; color: var(--text-secondary);">${app.studentName} (${app.studentRollNo})</div>
                                            </div>
                                            <div>
                                                <c:choose>
                                                    <c:when test="${app.status == 'SUBMITTED'}"><span class="badge-status badge-submitted">New</span></c:when>
                                                    <c:when test="${app.status == 'UNDER_REVIEW'}"><span class="badge-status badge-under-review">In Review</span></c:when>
                                                    <c:when test="${app.status == 'APPROVED'}"><span class="badge-status badge-approved">Approved</span></c:when>
                                                    <c:when test="${app.status == 'REJECTED'}"><span class="badge-status badge-rejected">Rejected</span></c:when>
                                                    <c:when test="${app.status == 'RESUBMISSION_REQUESTED'}"><span class="badge-status badge-resubmit">Resubmit</span></c:when>
                                                </c:choose>
                                            </div>
                                        </div>
                                        <div style="display: flex; justify-content: space-between; font-size: 0.75rem; color: var(--text-muted); margin-top: 0.5rem; border-top: 1px dashed var(--border); padding-top: 0.35rem;">
                                            <span>${app.scholarshipTitle}</span>
                                            <span>Score: <strong>${app.eligibilityScore}%</strong></span>
                                        </div>
                                    </a>
                                </c:forEach>
                            </c:otherwise>
                        </c:choose>
                    </div>
                </div>
            </div>

            <!-- Right: Detailed Review & Verification Station -->
            <div>
                <c:choose>
                    <c:when test="${not empty selectedApp}">
                        <div class="card">
                            <div class="card-header">
                                <div>
                                    <div style="font-size: 0.75rem; color: var(--text-muted); text-transform: uppercase;">Reviewing Application</div>
                                    <h2 class="card-title">${selectedApp.applicationNo}</h2>
                                </div>
                                <div>
                                    <c:choose>
                                        <c:when test="${selectedApp.fraudRiskLevel == 'HIGH'}">
                                            <span class="badge-status badge-risk-high">⚠️ High Risk (${selectedApp.fraudRiskScore}%)</span>
                                        </c:when>
                                        <c:when test="${selectedApp.fraudRiskLevel == 'MEDIUM'}">
                                            <span class="badge-status badge-risk-medium">⚠️ Medium Risk (${selectedApp.fraudRiskScore}%)</span>
                                        </c:when>
                                        <c:otherwise>
                                            <span class="badge-status badge-risk-low">✓ Low Risk (${selectedApp.fraudRiskScore}%)</span>
                                        </c:otherwise>
                                    </c:choose>
                                </div>
                            </div>

                            <!-- Student & Scheme Information -->
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1.25rem; font-size: 0.85rem; background: #f8fafc; padding: 1rem; border-radius: var(--radius-sm);">
                                <div>
                                    <div style="color: var(--text-muted); font-size: 0.75rem;">STUDENT APPLICANT</div>
                                    <div style="font-weight: 700; font-size: 1rem;">${selectedApp.studentName}</div>
                                    <div>Roll: <strong>${selectedStudent.rollNumber}</strong></div>
                                    <div>Course: <strong>${selectedStudent.course} (${selectedStudent.department})</strong></div>
                                    <div>GPA: <strong>${selectedStudent.currentGpa} / 4.0</strong></div>
                                    <div>Annual Income: <strong>INR <fmt:formatNumber value="${selectedStudent.annualFamilyIncome}" pattern="#,##,###"/></strong></div>
                                    <div>Category: <strong>${selectedStudent.category}</strong></div>
                                </div>
                                <div>
                                    <div style="color: var(--text-muted); font-size: 0.75rem;">SCHOLARSHIP & BANKING</div>
                                    <div style="font-weight: 700; font-size: 1rem; color: var(--primary);">${selectedScholarship.title}</div>
                                    <div>Grant: <strong>INR <fmt:formatNumber value="${selectedScholarship.amount}" pattern="#,##,###"/></strong></div>
                                    <div>Bank: <strong>${selectedStudent.bankName}</strong></div>
                                    <div>Account: <strong>${selectedStudent.bankAccountNo}</strong></div>
                                    <div>IFSC: <strong>${selectedStudent.ifscCode}</strong></div>
                                    <div>Eligibility: <strong>${selectedApp.eligibilityScore}%</strong></div>
                                </div>
                            </div>

                            <!-- Fraud Detection Flags -->
                            <c:if test="${not empty selectedApp.flaggedReasons}">
                                <div style="background: #fffbeb; border: 1px solid #fde68a; border-radius: var(--radius-sm); padding: 0.75rem; margin-bottom: 1.25rem; font-size: 0.85rem;">
                                    <strong style="color: #92400e;">Automated Risk Flag Analysis:</strong>
                                    <div style="color: #b45309; margin-top: 0.25rem;">${selectedApp.flaggedReasons}</div>
                                </div>
                            </c:if>

                            <!-- Document Verification Table -->
                            <h3 style="font-size: 1rem; font-weight: 600; margin-bottom: 0.75rem;">Submitted Supporting Proofs</h3>
                            <div class="table-responsive" style="margin-bottom: 1.5rem;">
                                <table class="table" style="font-size: 0.85rem;">
                                    <thead>
                                        <tr>
                                            <th>Type</th>
                                            <th>File</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <c:choose>
                                            <c:when test="${empty selectedApp.documents}">
                                                <tr>
                                                    <td colspan="4" style="text-align: center; color: var(--text-muted); padding: 1rem;">
                                                        No documents uploaded yet by the student.
                                                    </td>
                                                </tr>
                                            </c:when>
                                            <c:otherwise>
                                                <c:forEach var="doc" items="${selectedApp.documents}">
                                                    <tr>
                                                        <td><strong>${doc.docType}</strong></td>
                                                        <td>
                                                            <div>📄 ${doc.fileName}</div>
                                                            <div style="font-size: 0.75rem; color: var(--text-muted);">
                                                                <fmt:formatNumber value="${doc.fileSize / 1024}" pattern="#,##0"/> KB
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <c:choose>
                                                                <c:when test="${doc.verificationStatus == 'VERIFIED'}"><span class="badge-status badge-approved">Verified</span></c:when>
                                                                <c:when test="${doc.verificationStatus == 'REJECTED'}"><span class="badge-status badge-rejected">Rejected</span></c:when>
                                                                <c:otherwise><span class="badge-status badge-under-review">Pending</span></c:otherwise>
                                                            </c:choose>
                                                        </td>
                                                        <td>
                                                            <div style="display: flex; gap: 0.35rem;">
                                                                <form action="${pageContext.request.contextPath}/officer/verify" method="POST" style="margin: 0;">
                                                                    <input type="hidden" name="action" value="verify_doc">
                                                                    <input type="hidden" name="applicationId" value="${selectedApp.id}">
                                                                    <input type="hidden" name="documentId" value="${doc.id}">
                                                                    <input type="hidden" name="docStatus" value="VERIFIED">
                                                                    <button type="submit" class="btn btn-success btn-sm" title="Mark as Verified">✓ Pass</button>
                                                                </form>

                                                                <form action="${pageContext.request.contextPath}/officer/verify" method="POST" style="margin: 0;">
                                                                    <input type="hidden" name="action" value="verify_doc">
                                                                    <input type="hidden" name="applicationId" value="${selectedApp.id}">
                                                                    <input type="hidden" name="documentId" value="${doc.id}">
                                                                    <input type="hidden" name="docStatus" value="REJECTED">
                                                                    <input type="hidden" name="rejectionReason" value="Document illegible or stamp verification failed">
                                                                    <button type="submit" class="btn btn-danger btn-sm" title="Mark as Rejected">✗ Flag</button>
                                                                </form>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </c:forEach>
                                            </c:otherwise>
                                        </c:choose>
                                    </tbody>
                                </table>
                            </div>

                            <!-- Officer Decision Form -->
                            <div style="border-top: 1px solid var(--border); padding-top: 1.25rem;">
                                <h3 style="font-size: 1rem; font-weight: 600; margin-bottom: 0.75rem;">Officer Decision & Remarks</h3>
                                <form action="${pageContext.request.contextPath}/officer/verify" method="POST">
                                    <input type="hidden" name="applicationId" value="${selectedApp.id}">
                                    
                                    <div class="form-group">
                                        <label class="form-label">Official Review Remarks (recorded in audit log & visible to student)</label>
                                        <textarea name="officerRemarks" class="form-control" rows="2" placeholder="e.g. All documents verified against state portal. Approved for disbursement.">${selectedApp.officerRemarks}</textarea>
                                    </div>

                                    <div style="display: flex; gap: 0.75rem; justify-content: flex-end;">
                                        <button type="submit" name="action" value="request_resubmit" class="btn btn-warning btn-sm">
                                            Request Resubmission
                                        </button>
                                        <button type="submit" name="action" value="reject" class="btn btn-danger btn-sm">
                                            Reject Application
                                        </button>
                                        <button type="submit" name="action" value="approve" class="btn btn-success btn-sm">
                                            Approve Scholarship ✓
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </c:when>
                    <c:otherwise>
                        <div class="card" style="text-align: center; padding: 4rem 2rem; color: var(--text-muted);">
                            <div style="font-size: 2.5rem; margin-bottom: 1rem;">🔍</div>
                            <h3 style="font-size: 1.25rem; font-weight: 600; color: var(--text-secondary); margin-bottom: 0.5rem;">Select an Application to Review</h3>
                            <p style="font-size: 0.9rem;">Click any candidate submission from the queue on the left to inspect documents, evaluate fraud risk flags, and record verification decisions.</p>
                        </div>
                    </c:otherwise>
                </c:choose>
            </div>
        </div>

        <!-- System Audit Log Section -->
        <div class="card" style="margin-top: 2rem;">
            <div class="card-header">
                <h2 class="card-title">Recent System Audit Trail</h2>
                <span style="font-size: 0.8rem; color: var(--text-muted);">Immutable security records</span>
            </div>
            <div class="table-responsive">
                <table class="table" style="font-size: 0.8rem;">
                    <thead>
                        <tr>
                            <th>Timestamp</th>
                            <th>User</th>
                            <th>Action</th>
                            <th>Entity</th>
                            <th>Details</th>
                            <th>IP Address</th>
                        </tr>
                    </thead>
                    <tbody>
                        <c:forEach var="log" items="${recentAudits}">
                            <tr>
                                <td><fmt:formatDate value="${log.createdAt}" pattern="yyyy-MM-dd HH:mm:ss"/></td>
                                <td><strong><c:out value="${log.userFullName}" default="SYSTEM"/></strong> (<c:out value="${log.username}" default="sys"/>)</td>
                                <td><code>${log.action}</code></td>
                                <td>${log.entityType} #${log.entityId}</td>
                                <td>${log.details}</td>
                                <td><code>${log.ipAddress}</code></td>
                            </tr>
                        </c:forEach>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <footer class="footer">
        <div>National Scholarship Verification System &copy; 2026. Java 11 / Tomcat 9 Architecture.</div>
    </footer>
    <script src="${pageContext.request.contextPath}/assets/app.js"></script>
</body>
</html>
