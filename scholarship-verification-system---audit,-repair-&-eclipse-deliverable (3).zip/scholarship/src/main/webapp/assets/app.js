/**
 * Scholarship Verification System - Enterprise UI Enhancement Script
 * Features:
 * 1. Web Audio API Sound Effects Engine (Clicks, Success Chimes, Alerts, Switch)
 * 2. Dark / Light Mode Switcher with localStorage persistence
 * 3. Animated background orb controls
 */

// --- Web Audio API Sound Effects Engine ---
const SoundFX = (function() {
    let audioCtx = null;
    let isMuted = localStorage.getItem('sound_muted') === 'true';

    function getAudioContext() {
        if (!audioCtx) {
            const AudioContextClass = window.AudioContext || window.webkitAudioContext;
            if (AudioContextClass) {
                audioCtx = new AudioContextClass();
            }
        }
        if (audioCtx && audioCtx.state === 'suspended') {
            audioCtx.resume();
        }
        return audioCtx;
    }

    function playTone(freq, type, duration, gainVal, startOffset = 0) {
        if (isMuted) return;
        try {
            const ctx = getAudioContext();
            if (!ctx) return;
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            const now = ctx.currentTime + startOffset;

            osc.type = type;
            osc.frequency.setValueAtTime(freq, now);

            gain.gain.setValueAtTime(gainVal, now);
            gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

            osc.connect(gain);
            gain.connect(ctx.destination);

            osc.start(now);
            osc.stop(now + duration);
        } catch (e) {
            // Audio context safe fallback
        }
    }

    return {
        isMuted: function() { return isMuted; },
        toggleMute: function() {
            isMuted = !isMuted;
            localStorage.setItem('sound_muted', isMuted);
            this.updateMuteButtons();
            if (!isMuted) this.playSuccess();
            return isMuted;
        },
        updateMuteButtons: function() {
            document.querySelectorAll('.sound-toggle-btn').forEach(btn => {
                btn.innerHTML = isMuted 
                    ? '<span class="icon">🔇</span> Sound Off' 
                    : '<span class="icon">🔊</span> Sound On';
                btn.setAttribute('aria-pressed', !isMuted);
            });
        },
        playClick: function() {
            // Crisp, subtle modern UI tap
            playTone(850, 'sine', 0.04, 0.08);
        },
        playSuccess: function() {
            // Harmonic 3-note ascending chime
            playTone(523.25, 'triangle', 0.12, 0.1, 0.00); // C5
            playTone(659.25, 'triangle', 0.14, 0.1, 0.07); // E5
            playTone(783.99, 'triangle', 0.22, 0.12, 0.14); // G5
        },
        playAlert: function() {
            // Low warm alert thud
            playTone(220, 'sawtooth', 0.18, 0.08);
        },
        playTab: function() {
            // Airy switch tick
            playTone(1100, 'sine', 0.03, 0.05);
        },
        playToggle: function() {
            playTone(440, 'sine', 0.05, 0.08, 0.00);
            playTone(660, 'sine', 0.06, 0.08, 0.04);
        }
    };
})();

// --- Dark / Light Mode Switcher ---
const ThemeManager = (function() {
    const savedTheme = localStorage.getItem('app_theme') || 'dark';

    function applyTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        localStorage.setItem('app_theme', theme);
        document.querySelectorAll('.theme-toggle-btn').forEach(btn => {
            btn.innerHTML = theme === 'dark' 
                ? '<span class="icon">☀️</span> Light Mode' 
                : '<span class="icon">🌙</span> Dark Mode';
        });
    }

    return {
        init: function() {
            applyTheme(savedTheme);
        },
        toggle: function() {
            const current = document.documentElement.getAttribute('data-theme') || 'dark';
            const next = current === 'dark' ? 'light' : 'dark';
            applyTheme(next);
            SoundFX.playToggle();
            return next;
        }
    };
})();

// --- Initialize Interactive Audio & Theme on DOM Load ---
document.addEventListener('DOMContentLoaded', function() {
    ThemeManager.init();
    SoundFX.updateMuteButtons();

    // Attach click sounds to interactive controls
    document.addEventListener('click', function(e) {
        const target = e.target.closest('button, .btn, .nav-link, input[type="submit"], input[type="button"], .tab-btn');
        if (!target) return;

        if (target.classList.contains('sound-toggle-btn')) {
            SoundFX.toggleMute();
            return;
        }
        if (target.classList.contains('theme-toggle-btn')) {
            ThemeManager.toggle();
            return;
        }
        if (target.classList.contains('btn-success') || target.classList.contains('btn-approve')) {
            SoundFX.playSuccess();
        } else if (target.classList.contains('btn-danger') || target.classList.contains('btn-reject')) {
            SoundFX.playAlert();
        } else if (target.classList.contains('nav-link') || target.classList.contains('tab-btn')) {
            SoundFX.playTab();
        } else {
            SoundFX.playClick();
        }
    });
});
