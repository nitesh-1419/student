package com.scholarship;

import com.scholarship.util.PasswordUtil;
import org.junit.Test;

import static org.junit.Assert.*;

public class PasswordUtilTest {

    @Test
    public void testPbkdf2HashAndVerify() {
        String rawPassword = "SecurePassword@2026!";
        String salt = PasswordUtil.generateSalt();
        assertNotNull("Salt must be generated", salt);
        assertEquals("Salt length should be 32 hex chars (16 bytes)", 32, salt.length());

        String hash = PasswordUtil.hashPassword(rawPassword, salt);
        assertTrue("Hash must follow PBKDF2 format", hash.startsWith("pbkdf2:65536:"));

        boolean verified = PasswordUtil.verifyPassword(rawPassword, hash, salt);
        assertTrue("Password verification must succeed", verified);

        boolean wrongVerified = PasswordUtil.verifyPassword("WrongPassword123", hash, salt);
        assertFalse("Wrong password must be rejected", wrongVerified);
    }

    @Test
    public void testConstantTimeEquals() {
        assertTrue("Identical strings must return true",
                PasswordUtil.constantTimeEquals("abcdef123456", "abcdef123456"));
        assertFalse("Different strings must return false",
                PasswordUtil.constantTimeEquals("abcdef123456", "abcdef123457"));
        assertFalse("Different length strings must return false",
                PasswordUtil.constantTimeEquals("short", "longerstring"));
    }
}
