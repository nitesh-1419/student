package com.scholarship;

import com.scholarship.model.Application;
import com.scholarship.model.Document;
import com.scholarship.model.Scholarship;
import com.scholarship.model.Student;
import com.scholarship.service.FraudDetectionService;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

public class FraudDetectionServiceTest {

    private FraudDetectionService service;
    private Application app;
    private Student student;
    private Scholarship scholarship;
    private List<Document> completeDocs;

    @Before
    public void setUp() {
        service = new FraudDetectionService();

        student = new Student();
        student.setId(10);
        student.setBankAccountNo("123456789012");
        student.setIfscCode("SBIN0001234");
        student.setAnnualFamilyIncome(new BigDecimal("150000.00"));

        scholarship = new Scholarship();
        scholarship.setId(1);
        scholarship.setRequiredDocs("INCOME_CERTIFICATE,MARKSHEET");

        app = new Application();
        app.setId(100);

        completeDocs = new ArrayList<>();
        Document doc1 = new Document();
        doc1.setDocType("INCOME_CERTIFICATE");
        doc1.setFileName("income.pdf");
        doc1.setFileSize(20000);
        doc1.setVerificationStatus("VERIFIED");
        completeDocs.add(doc1);

        Document doc2 = new Document();
        doc2.setDocType("MARKSHEET");
        doc2.setFileName("marksheet.pdf");
        doc2.setFileSize(50000);
        doc2.setVerificationStatus("VERIFIED");
        completeDocs.add(doc2);
    }

    @Test
    public void testCleanSubmissionProducesLowRisk() {
        FraudDetectionService.FraudResult result = service.analyze(app, student, scholarship, completeDocs);
        assertEquals("Clean submission should be LOW risk", "LOW", result.getRiskLevel());
        assertTrue("Risk score should be below 20", result.getRiskScore().doubleValue() < 20.0);
    }

    @Test
    public void testMissingMandatoryDocIncreasesRisk() {
        List<Document> emptyDocs = new ArrayList<>();
        FraudDetectionService.FraudResult result = service.analyze(app, student, scholarship, emptyDocs);
        assertTrue("Risk score should increase for missing documents", result.getRiskScore().doubleValue() >= 20.0);
        assertFalse("Flagged factors must list missing documents", result.getFlaggedFactors().isEmpty());
    }

    @Test
    public void testRejectedDocTriggersElevatedRisk() {
        Document rejectedDoc = new Document();
        rejectedDoc.setDocType("INCOME_CERTIFICATE");
        rejectedDoc.setFileName("fake.pdf");
        rejectedDoc.setVerificationStatus("REJECTED");
        rejectedDoc.setRejectionReason("Forged seal");

        List<Document> docsWithRejected = new ArrayList<>();
        docsWithRejected.add(rejectedDoc);

        FraudDetectionService.FraudResult result = service.analyze(app, student, scholarship, docsWithRejected);
        assertTrue("Risk score should reflect rejected documents", result.getRiskScore().doubleValue() >= 20.0);
    }
}
