package com.scholarship;

import com.scholarship.model.Scholarship;
import com.scholarship.model.Student;
import com.scholarship.service.EligibilityService;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;

import static org.junit.Assert.*;

public class EligibilityServiceTest {

    private EligibilityService service;
    private Scholarship scholarship;
    private Student eligibleStudent;
    private Student lowGpaStudent;

    @Before
    public void setUp() {
        service = new EligibilityService();

        scholarship = new Scholarship();
        scholarship.setId(1);
        scholarship.setCode("TEST-SCH");
        scholarship.setTitle("Test Merit Scholarship");
        scholarship.setMinGpa(new BigDecimal("3.20"));
        scholarship.setMaxAnnualIncome(new BigDecimal("300000.00"));
        scholarship.setEligibleCategories("ALL");
        scholarship.setDeadline(Date.valueOf(LocalDate.now().plusMonths(2)));

        eligibleStudent = new Student();
        eligibleStudent.setId(1);
        eligibleStudent.setCurrentGpa(new BigDecimal("3.80"));
        eligibleStudent.setAnnualFamilyIncome(new BigDecimal("200000.00"));
        eligibleStudent.setCategory("OBC");

        lowGpaStudent = new Student();
        lowGpaStudent.setId(2);
        lowGpaStudent.setCurrentGpa(new BigDecimal("2.90"));
        lowGpaStudent.setAnnualFamilyIncome(new BigDecimal("150000.00"));
        lowGpaStudent.setCategory("GENERAL");
    }

    @Test
    public void testEligibleStudentPasses() {
        EligibilityService.EligibilityResult result = service.evaluate(eligibleStudent, scholarship);
        assertTrue("Eligible student should qualify", result.isEligible());
        assertTrue("Score should be >= 70%", result.getScore().doubleValue() >= 70.0);
        assertTrue("Failed criteria list should be empty", result.getFailedCriteria().isEmpty());
    }

    @Test
    public void testLowGpaStudentFails() {
        EligibilityService.EligibilityResult result = service.evaluate(lowGpaStudent, scholarship);
        assertFalse("Low GPA candidate should not be eligible", result.isEligible());
        assertFalse("Failed criteria should contain GPA warning", result.getFailedCriteria().isEmpty());
    }

    @Test
    public void testIncomeCeilingExceeded() {
        Student wealthyStudent = new Student();
        wealthyStudent.setCurrentGpa(new BigDecimal("3.95"));
        wealthyStudent.setAnnualFamilyIncome(new BigDecimal("800000.00"));
        wealthyStudent.setCategory("GENERAL");

        EligibilityService.EligibilityResult result = service.evaluate(wealthyStudent, scholarship);
        assertFalse("High income candidate should not qualify", result.isEligible());
    }
}
