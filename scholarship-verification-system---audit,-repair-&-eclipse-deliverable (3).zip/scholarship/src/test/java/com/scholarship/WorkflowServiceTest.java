package com.scholarship;

import com.scholarship.service.WorkflowService;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class WorkflowServiceTest {

    private WorkflowService workflowService;

    @Before
    public void setUp() {
        workflowService = new WorkflowService();
    }

    @Test
    public void testPermittedWorkflowTransitions() {
        assertTrue("SUBMITTED -> UNDER_REVIEW must be permitted",
                workflowService.canTransition("SUBMITTED", "UNDER_REVIEW"));
        assertTrue("UNDER_REVIEW -> APPROVED must be permitted",
                workflowService.canTransition("UNDER_REVIEW", "APPROVED"));
        assertTrue("UNDER_REVIEW -> REJECTED must be permitted",
                workflowService.canTransition("UNDER_REVIEW", "REJECTED"));
        assertTrue("UNDER_REVIEW -> RESUBMISSION_REQUESTED must be permitted",
                workflowService.canTransition("UNDER_REVIEW", "RESUBMISSION_REQUESTED"));
        assertTrue("RESUBMISSION_REQUESTED -> SUBMITTED must be permitted",
                workflowService.canTransition("RESUBMISSION_REQUESTED", "SUBMITTED"));
    }

    @Test
    public void testProhibitedWorkflowTransitions() {
        assertFalse("APPROVED -> SUBMITTED must be forbidden",
                workflowService.canTransition("APPROVED", "SUBMITTED"));
        assertFalse("REJECTED -> APPROVED must be forbidden without appeal",
                workflowService.canTransition("REJECTED", "APPROVED"));
    }
}
