# Eclipse IDE & Apache Tomcat 9 Deployment Guide

This guide describes how to import, configure, and launch the **Scholarship Verification System** in **Eclipse IDE for Enterprise Java and Web Developers** running on **Apache Tomcat 9.0**.

---

## 1. Prerequisites
- **JDK 11 Installed:** Ensure `JAVA_HOME` points to JDK 11 (e.g. OpenJDK 11, Eclipse Temurin 11, or Oracle JDK 11).
- **Eclipse IDE:** Eclipse 2020-06 or newer with "Enterprise Java and Web Developer Tools" (WTP).
- **Apache Tomcat 9:** Download and extract Tomcat 9.0.x core zip/tar.gz to a local folder.
- **MySQL 8.0+:** MySQL Server running with `scholarship_db` initialized via `schema.sql`.

---

## 2. Importing into Eclipse
1. Launch Eclipse and select your workspace directory.
2. In the top menu, go to **File** → **Import...**
3. Expand **Maven** and select **Existing Maven Projects**, then click **Next >**.
4. In the **Root Directory** field, click **Browse...** and select the unzipped `scholarship` folder containing `pom.xml`.
5. Eclipse will scan and detect `/pom.xml com.scholarship:scholarship-verification-system:1.0.0:war`.
6. Ensure the checkbox is checked, then click **Finish**.
7. Wait for Eclipse and m2e to download dependencies and build the project workspace.

---

## 3. Configuring Apache Tomcat 9 in Eclipse
1. Open the **Servers** view in Eclipse (**Window** → **Show View** → **Servers**).
2. Right-click inside the Servers view → **New** → **Server**.
3. Expand **Apache** → select **Tomcat v9.0 Server**. Click **Next >**.
4. In **Tomcat installation directory**, click **Browse...** and select your extracted Apache Tomcat 9 folder.
5. In **JRE**, select **JavaSE-11** (or your installed JDK 11). Click **Next >**.
6. On the **Add and Remove** screen:
   - Select `scholarship-verification-system` in the Available list.
   - Click **Add >** to move it to the Configured list.
   - Click **Finish**.

---

## 4. Database Connection Setup (`db.properties`)
1. Open `scholarship/src/main/resources/db.properties` in Eclipse.
2. Verify or update your MySQL credentials:
   ```properties
   db.driver=com.mysql.cj.jdbc.Driver
   db.url=jdbc:mysql://localhost:3306/scholarship_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC&characterEncoding=UTF-8
   db.username=your_mysql_username
   db.password=your_mysql_password
   ```
3. Save the file. Eclipse will automatically publish it to `target/classes/db.properties`.

---

## 5. Running the Application
1. In the **Servers** view, right-click **Tomcat v9.0 Server at localhost** → select **Start** (or **Debug**).
2. Watch the **Console** view for startup logs:
   ```
   INFO: Starting Servlet engine: [Apache Tomcat/9.0.xx]
   INFO: Deploying web application directory .../webapps/scholarship-system
   INFO: MySQL JDBC driver successfully loaded: com.mysql.cj.jdbc.Driver
   INFO: DBConnection loaded configuration from db.properties
   ```
3. Open your web browser and navigate to:
   ```
   http://localhost:8080/scholarship-system/
   ```
4. Sign in as an Officer (`officer1` / `Password@123`) or Student (`rahul_sharma` / `Password@123`).

---

## 6. Troubleshooting Common Eclipse & Tomcat Issues

### Issue 1: HTTP 404 on `http://localhost:8080/scholarship-system/`
- **Cause:** Context path mismatch.
- **Fix:** In Eclipse Servers view, double-click **Tomcat v9.0 Server**, switch to the **Modules** tab at the bottom, select your module, click **Edit...**, and verify that **Path** is set to `/scholarship-system`.

### Issue 2: `java.lang.ClassNotFoundException: com.mysql.cj.jdbc.Driver`
- **Cause:** Maven dependencies not mapped to Deployment Assembly.
- **Fix:** Right-click the project in Eclipse → **Properties** → **Deployment Assembly** → Click **Add...** → **Java Build Path Entries** → select **Maven Dependencies** → **Finish** → **Apply and Close**.

### Issue 3: Port 8080 Already in Use
- **Cause:** Another process or service is listening on port 8080.
- **Fix:** In Tomcat configuration in Eclipse, change the HTTP port from 8080 to 8088 or 9090, save, and restart.

### Issue 4: Java Compiler Level / Facet Version Mismatch
- **Fix:** Right-click project → **Properties** → **Java Compiler** → verify JDK Compliance is 11. Under **Project Facets**, ensure **Java** is 11 and **Dynamic Web Module** is 4.0.
