-- =============================================================================
-- Advanced Scholarship Management, Verification & Fraud-Risk Assistance System
-- Database: MySQL 8.0+ | Engine: InnoDB | Character Set: utf8mb4
-- =============================================================================

CREATE DATABASE IF NOT EXISTS scholarship_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE scholarship_db;

-- -----------------------------------------------------------------------------
-- Clean Drop in Reverse Dependency Order
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS fraud_flags;
DROP TABLE IF EXISTS application_status_history;
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS audit_logs;
DROP TABLE IF EXISTS documents;
DROP TABLE IF EXISTS applications;
DROP TABLE IF EXISTS scholarships;
DROP TABLE IF EXISTS students;
DROP TABLE IF EXISTS users;

-- -----------------------------------------------------------------------------
-- 1. USERS TABLE
-- -----------------------------------------------------------------------------
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    salt VARCHAR(64) DEFAULT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) DEFAULT NULL,
    role ENUM('STUDENT', 'OFFICER', 'ADMIN') NOT NULL DEFAULT 'STUDENT',
    status ENUM('ACTIVE', 'SUSPENDED') NOT NULL DEFAULT 'ACTIVE',
    failed_login_attempts INT NOT NULL DEFAULT 0,
    locked_until TIMESTAMP NULL DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_role (role),
    INDEX idx_user_email (email),
    INDEX idx_user_status (status)
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- 2. STUDENTS TABLE
-- -----------------------------------------------------------------------------
CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    roll_number VARCHAR(50) NOT NULL UNIQUE,
    department VARCHAR(100) NOT NULL,
    course VARCHAR(100) NOT NULL,
    year_of_study INT NOT NULL DEFAULT 1,
    current_gpa DECIMAL(3,2) NOT NULL DEFAULT 0.00,
    annual_family_income DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    category ENUM('GENERAL', 'OBC', 'SC', 'ST', 'EWS') NOT NULL DEFAULT 'GENERAL',
    bank_account_no VARCHAR(30) DEFAULT NULL,
    ifsc_code VARCHAR(15) DEFAULT NULL,
    bank_name VARCHAR(100) DEFAULT NULL,
    aadhar_hash VARCHAR(128) DEFAULT NULL,
    address TEXT DEFAULT NULL,
    profile_completion_pct INT NOT NULL DEFAULT 100,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_students_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_student_roll (roll_number),
    INDEX idx_student_gpa (current_gpa),
    INDEX idx_student_income (annual_family_income)
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- 3. SCHOLARSHIPS TABLE
-- -----------------------------------------------------------------------------
CREATE TABLE scholarships (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(30) NOT NULL UNIQUE,
    title VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    sponsor VARCHAR(150) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    min_gpa DECIMAL(3,2) NOT NULL DEFAULT 3.00,
    max_annual_income DECIMAL(12,2) NOT NULL DEFAULT 500000.00,
    eligible_categories VARCHAR(255) NOT NULL DEFAULT 'ALL',
    deadline DATE NOT NULL,
    total_slots INT NOT NULL DEFAULT 50,
    available_slots INT NOT NULL DEFAULT 50,
    status ENUM('ACTIVE', 'CLOSED', 'ARCHIVED') NOT NULL DEFAULT 'ACTIVE',
    required_docs VARCHAR(500) NOT NULL DEFAULT 'INCOME_CERTIFICATE,MARKSHEET,IDENTITY_PROOF,BANK_PASSBOOK',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_scholarship_status (status),
    INDEX idx_scholarship_deadline (deadline)
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- 4. APPLICATIONS TABLE
-- -----------------------------------------------------------------------------
CREATE TABLE applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    application_no VARCHAR(50) NOT NULL UNIQUE,
    student_id INT NOT NULL,
    scholarship_id INT NOT NULL,
    applied_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('DRAFT', 'SUBMITTED', 'UNDER_REVIEW', 'RESUBMISSION_REQUESTED', 'APPROVED', 'REJECTED') NOT NULL DEFAULT 'SUBMITTED',
    eligibility_score DECIMAL(5,2) DEFAULT 0.00,
    fraud_risk_score DECIMAL(5,2) DEFAULT 0.00,
    fraud_risk_level ENUM('LOW', 'MEDIUM', 'HIGH') DEFAULT 'LOW',
    flagged_reasons TEXT DEFAULT NULL,
    officer_remarks TEXT DEFAULT NULL,
    verified_by INT DEFAULT NULL,
    verified_date TIMESTAMP NULL DEFAULT NULL,
    draft_step INT DEFAULT 1,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_app_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    CONSTRAINT fk_app_scholarship FOREIGN KEY (scholarship_id) REFERENCES scholarships(id) ON DELETE RESTRICT,
    CONSTRAINT fk_app_officer FOREIGN KEY (verified_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_app_status (status),
    INDEX idx_app_student (student_id),
    INDEX idx_app_scholarship (scholarship_id),
    INDEX idx_app_applied_date (applied_date)
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- 5. DOCUMENTS TABLE
-- -----------------------------------------------------------------------------
CREATE TABLE documents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    application_id INT NOT NULL,
    student_id INT NOT NULL,
    doc_type ENUM('INCOME_CERTIFICATE', 'MARKSHEET', 'IDENTITY_PROOF', 'BANK_PASSBOOK', 'CASTE_CERTIFICATE') NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_size BIGINT NOT NULL DEFAULT 0,
    mime_type VARCHAR(100) NOT NULL,
    file_hash VARCHAR(128) DEFAULT NULL,
    file_signature VARCHAR(32) DEFAULT NULL,
    version INT NOT NULL DEFAULT 1,
    verification_status ENUM('PENDING', 'VERIFIED', 'REJECTED') NOT NULL DEFAULT 'PENDING',
    rejection_reason VARCHAR(255) DEFAULT NULL,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_doc_app FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE,
    CONSTRAINT fk_doc_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    INDEX idx_doc_app (application_id),
    INDEX idx_doc_hash (file_hash)
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- 6. APPLICATION STATUS HISTORY TABLE
-- -----------------------------------------------------------------------------
CREATE TABLE application_status_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    application_id INT NOT NULL,
    previous_status VARCHAR(50) NOT NULL,
    new_status VARCHAR(50) NOT NULL,
    changed_by INT DEFAULT NULL,
    remarks TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_history_app FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE,
    CONSTRAINT fk_history_user FOREIGN KEY (changed_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_history_app (application_id)
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- 7. FRAUD FLAGS TABLE (Explainable Risk Auditing)
-- -----------------------------------------------------------------------------
CREATE TABLE fraud_flags (
    id INT AUTO_INCREMENT PRIMARY KEY,
    application_id INT NOT NULL,
    risk_factor VARCHAR(100) NOT NULL,
    explanation TEXT NOT NULL,
    severity ENUM('LOW', 'MEDIUM', 'HIGH') NOT NULL DEFAULT 'LOW',
    is_dismissed BOOLEAN NOT NULL DEFAULT FALSE,
    dismissed_by INT DEFAULT NULL,
    dismissal_reason TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_flags_app FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE,
    CONSTRAINT fk_flags_officer FOREIGN KEY (dismissed_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_flags_app (application_id)
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- 8. IN-APP NOTIFICATIONS TABLE
-- -----------------------------------------------------------------------------
CREATE TABLE notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(150) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('INFO', 'SUCCESS', 'WARNING', 'DANGER') NOT NULL DEFAULT 'INFO',
    is_read BOOLEAN NOT NULL DEFAULT FALSE,
    link_url VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_notif_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_notif_user (user_id),
    INDEX idx_notif_read (is_read)
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- 9. AUDIT LOGS TABLE
-- -----------------------------------------------------------------------------
CREATE TABLE audit_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT DEFAULT NULL,
    action VARCHAR(100) NOT NULL,
    entity_type VARCHAR(50) NOT NULL,
    entity_id INT DEFAULT NULL,
    details TEXT DEFAULT NULL,
    ip_address VARCHAR(45) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_audit_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_audit_action (action),
    INDEX idx_audit_created (created_at)
) ENGINE=InnoDB;
