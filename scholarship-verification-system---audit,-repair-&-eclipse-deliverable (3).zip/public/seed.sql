-- =============================================================================
-- Seed Data for Local Development, Testing, and Audit Demonstrations
-- All sample personal data is fictional. Default password for all seed accounts:
-- Password: "Password@123"
-- Format: PBKDF2WithHmacSHA256 and legacy SHA-256 fallback supported
-- =============================================================================

USE scholarship_db;

-- 1. SEED USERS
-- Password hash for 'Password@123' (legacy SHA-256 with salt / verified by PasswordUtil):
-- hash: e9d73d74c0e660e5ab3747b99c7d42cfc0883d6a695b21764eb14bf4e8f7fa9e
INSERT INTO users (id, username, password_hash, salt, email, full_name, phone, role, status) VALUES
(1, 'admin', 'e9d73d74c0e660e5ab3747b99c7d42cfc0883d6a695b21764eb14bf4e8f7fa9e', 'salt_admin_001', 'admin@scholarship.gov', 'Dr. Arvind Sharma (System Director)', '+91-9876543210', 'ADMIN', 'ACTIVE'),
(2, 'officer1', 'e9d73d74c0e660e5ab3747b99c7d42cfc0883d6a695b21764eb14bf4e8f7fa9e', 'salt_off_001', 'officer1@scholarship.gov', 'Sunita Rao (Senior Verification Officer)', '+91-9876543211', 'OFFICER', 'ACTIVE'),
(3, 'officer2', 'e9d73d74c0e660e5ab3747b99c7d42cfc0883d6a695b21764eb14bf4e8f7fa9e', 'salt_off_002', 'officer2@scholarship.gov', 'Rajesh Kulkarni (Verification Officer)', '+91-9876543212', 'OFFICER', 'ACTIVE'),
(4, 'rahul_sharma', 'e9d73d74c0e660e5ab3747b99c7d42cfc0883d6a695b21764eb14bf4e8f7fa9e', 'salt_stu_001', 'rahul.sharma@campus.edu', 'Rahul Sharma', '+91-9123456780', 'STUDENT', 'ACTIVE'),
(5, 'priya_patel', 'e9d73d74c0e660e5ab3747b99c7d42cfc0883d6a695b21764eb14bf4e8f7fa9e', 'salt_stu_002', 'priya.patel@campus.edu', 'Priya Patel', '+91-9123456781', 'STUDENT', 'ACTIVE'),
(6, 'ananya_sen', 'e9d73d74c0e660e5ab3747b99c7d42cfc0883d6a695b21764eb14bf4e8f7fa9e', 'salt_stu_003', 'ananya.sen@campus.edu', 'Ananya Sen', '+91-9123456782', 'STUDENT', 'ACTIVE'),
(7, 'vikram_kumar', 'e9d73d74c0e660e5ab3747b99c7d42cfc0883d6a695b21764eb14bf4e8f7fa9e', 'salt_stu_004', 'vikram.kumar@campus.edu', 'Vikram Kumar', '+91-9123456783', 'STUDENT', 'ACTIVE');

-- 2. SEED STUDENTS
INSERT INTO students (id, user_id, roll_number, department, course, year_of_study, current_gpa, annual_family_income, category, bank_account_no, ifsc_code, bank_name, aadhar_hash, address, profile_completion_pct) VALUES
(1, 4, 'CS-2022-045', 'Computer Science & Engineering', 'B.Tech', 3, 3.85, 240000.00, 'OBC', '910023485712', 'SBIN0001234', 'State Bank of India', 'aadh_hsh_001_rahul', 'Plot 42, Civil Lines, Jaipur, Rajasthan', 100),
(2, 5, 'EE-2023-018', 'Electrical Engineering', 'B.Tech', 2, 3.92, 180000.00, 'EWS', '623049182374', 'HDFC0004567', 'HDFC Bank', 'aadh_hsh_002_priya', '12/A Subhash Road, Ahmedabad, Gujarat', 100),
(3, 6, 'BT-2021-089', 'Biotechnology', 'M.Tech', 1, 3.65, 320000.00, 'GENERAL', '491028374619', 'ICIC0007890', 'ICICI Bank', 'aadh_hsh_003_ananya', 'Flat 4B, Greenfield Apts, Kolkata, WB', 90),
(4, 7, 'ME-2022-104', 'Mechanical Engineering', 'B.Tech', 3, 2.95, 450000.00, 'SC', '812938475620', 'PUNB0002345', 'Punjab National Bank', 'aadh_hsh_004_vikram', 'House 88, Sector 14, Chandigarh', 85);

-- 3. SEED SCHOLARSHIPS
INSERT INTO scholarships (id, code, title, description, sponsor, amount, min_gpa, max_annual_income, eligible_categories, deadline, total_slots, available_slots, status, required_docs) VALUES
(1, 'SCH-MCM-2026', 'Merit-Cum-Means National Scholarship', 'Financial assistance for brilliant students from economically weaker backgrounds enrolled in accredited undergraduate technical programs.', 'Ministry of Education & Human Resources', 50000.00, 3.20, 300000.00, 'ALL', '2026-12-31', 120, 119, 'ACTIVE', 'INCOME_CERTIFICATE,MARKSHEET,IDENTITY_PROOF,BANK_PASSBOOK'),
(2, 'SCH-STEM-2026', 'National STEM Excellence Grant', 'Prestige grant supporting top-tier academic rank holders in Engineering, Mathematics, and Computer Science streams.', 'National Science Foundation', 75000.00, 3.75, 600000.00, 'ALL', '2026-11-30', 40, 40, 'ACTIVE', 'MARKSHEET,IDENTITY_PROOF,BANK_PASSBOOK'),
(3, 'SCH-WOMEN-TECH', 'Women in Tech Leadership Fellowship', 'Dedicated scholarship to empower female undergraduates pursuing engineering and artificial intelligence disciplines.', 'Global Tech Equality Foundation', 60000.00, 3.40, 500000.00, 'ALL', '2026-12-15', 50, 50, 'ACTIVE', 'INCOME_CERTIFICATE,MARKSHEET,IDENTITY_PROOF,BANK_PASSBOOK'),
(4, 'SCH-SCST-EWS', 'Social Inclusion & Upliftment Scholarship', 'Targeted full-fee waiver stipend for SC/ST and EWS students displaying consistent academic dedication.', 'Social Justice Directorate', 45000.00, 2.80, 400000.00, 'SC,ST,EWS', '2026-10-31', 80, 80, 'ACTIVE', 'INCOME_CERTIFICATE,MARKSHEET,CASTE_CERTIFICATE,BANK_PASSBOOK');

-- 4. SEED APPLICATIONS
INSERT INTO applications (id, application_no, student_id, scholarship_id, applied_date, status, eligibility_score, fraud_risk_score, fraud_risk_level, flagged_reasons, officer_remarks, verified_by, verified_date) VALUES
(1, 'APP-2026-001', 1, 1, '2026-09-10 10:30:00', 'APPROVED', 92.50, 4.20, 'LOW', 'None. Validated against university records.', 'All criteria met. Verified income certificate with Tehsildar stamp. GPA verified.', 2, '2026-09-15 14:20:00'),
(2, 'APP-2026-002', 2, 3, '2026-09-12 11:15:00', 'UNDER_REVIEW', 98.00, 6.50, 'LOW', 'None. Documents currently under inspection.', 'Document review underway by Officer Sunita Rao.', 2, NULL),
(3, 'APP-2026-003', 3, 2, '2026-09-14 09:45:00', 'SUBMITTED', 88.00, 8.00, 'LOW', 'Initial submission awaiting reviewer assignment.', NULL, NULL, NULL),
(4, 'APP-2026-004', 4, 4, '2026-09-16 16:00:00', 'RESUBMISSION_REQUESTED', 72.00, 28.50, 'MEDIUM', 'Income certificate image blurred; caste certificate validity expired', 'Please upload a clear scanned PDF of your Tehsildar income certificate and updated caste certificate issued in 2026.', 3, '2026-09-18 11:00:00');

-- 5. SEED DOCUMENTS
INSERT INTO documents (id, application_id, student_id, doc_type, file_name, file_path, file_size, mime_type, file_hash, file_signature, version, verification_status, rejection_reason) VALUES
(1, 1, 1, 'INCOME_CERTIFICATE', 'income_cert_rahul_2026.pdf', 'uploads/docs/income_cert_rahul_2026.pdf', 342100, 'application/pdf', 'sha256_e4c3a2f1b809', '%PDF', 1, 'VERIFIED', NULL),
(2, 1, 1, 'MARKSHEET', 'semester_4_gradecard.pdf', 'uploads/docs/semester_4_gradecard.pdf', 512000, 'application/pdf', 'sha256_89a0b1c2d3e4', '%PDF', 1, 'VERIFIED', NULL),
(3, 1, 1, 'IDENTITY_PROOF', 'aadhar_card_rahul.jpg', 'uploads/docs/aadhar_card_rahul.jpg', 214500, 'image/jpeg', 'sha256_77f88e99a0b1', 'JPEG', 1, 'VERIFIED', NULL),
(4, 1, 1, 'BANK_PASSBOOK', 'sbi_passbook_rahul.pdf', 'uploads/docs/sbi_passbook_rahul.pdf', 189000, 'application/pdf', 'sha256_11a22b33c4d5', '%PDF', 1, 'VERIFIED', NULL),
(5, 2, 2, 'INCOME_CERTIFICATE', 'income_cert_priya.pdf', 'uploads/docs/income_cert_priya.pdf', 412000, 'application/pdf', 'sha256_55e66f77a88b', '%PDF', 1, 'VERIFIED', NULL),
(6, 2, 2, 'MARKSHEET', 'btech_sem2_marksheet.pdf', 'uploads/docs/btech_sem2_marksheet.pdf', 623100, 'application/pdf', 'sha256_99b88c77d66e', '%PDF', 1, 'PENDING', NULL),
(7, 2, 2, 'IDENTITY_PROOF', 'passport_priya.pdf', 'uploads/docs/passport_priya.pdf', 280000, 'application/pdf', 'sha256_33d44e55f66a', '%PDF', 1, 'VERIFIED', NULL),
(8, 3, 3, 'MARKSHEET', 'mtech_sem1_grades.pdf', 'uploads/docs/mtech_sem1_grades.pdf', 485000, 'application/pdf', 'sha256_22c33d44e55f', '%PDF', 1, 'PENDING', NULL),
(9, 4, 4, 'INCOME_CERTIFICATE', 'income_doc_blurry.jpg', 'uploads/docs/income_doc_blurry.jpg', 89000, 'image/jpeg', 'sha256_aa11bb22cc33', 'JPEG', 1, 'REJECTED', 'Image resolution too low and stamp unreadable.'),
(10, 4, 4, 'CASTE_CERTIFICATE', 'caste_cert_expired.pdf', 'uploads/docs/caste_cert_expired.pdf', 302000, 'application/pdf', 'sha256_bb22cc33dd44', '%PDF', 1, 'REJECTED', 'Certificate expired on 2024-03-31.');

-- 6. SEED STATUS HISTORY
INSERT INTO application_status_history (application_id, previous_status, new_status, changed_by, remarks, created_at) VALUES
(1, 'SUBMITTED', 'UNDER_REVIEW', 2, 'Application review commenced.', '2026-09-12 09:00:00'),
(1, 'UNDER_REVIEW', 'APPROVED', 2, 'Candidate satisfied all merit and financial criteria.', '2026-09-15 14:20:00'),
(2, 'SUBMITTED', 'UNDER_REVIEW', 2, 'Assigned to Officer Sunita Rao.', '2026-09-13 10:00:00'),
(4, 'SUBMITTED', 'UNDER_REVIEW', 3, 'Assigned to Officer Rajesh Kulkarni.', '2026-09-17 10:15:00'),
(4, 'UNDER_REVIEW', 'RESUBMISSION_REQUESTED', 3, 'Caste certificate expired and income doc blurry.', '2026-09-18 11:00:00');

-- 7. SEED FRAUD FLAGS
INSERT INTO fraud_flags (application_id, risk_factor, explanation, severity, is_dismissed, dismissed_by, dismissal_reason) VALUES
(4, 'REJECTED_DOC', 'Income certificate resolution is below 150 DPI and seal is unreadable.', 'MEDIUM', FALSE, NULL, NULL),
(4, 'EXPIRED_CERT', 'Caste certificate issue date indicates expiration on 2024-03-31.', 'HIGH', FALSE, NULL, NULL);

-- 8. SEED NOTIFICATIONS
INSERT INTO notifications (user_id, title, message, type, is_read, link_url, created_at) VALUES
(4, '🎉 Scholarship Approved!', 'Your application APP-2026-001 has been approved for INR 50,000.', 'SUCCESS', TRUE, 'student/tracking?appId=1', '2026-09-15 14:21:00'),
(5, 'Application Under Review', 'Officer Sunita Rao is reviewing your application APP-2026-002.', 'INFO', FALSE, 'student/tracking?appId=2', '2026-09-13 10:05:00'),
(7, '⚠️ Action Required: Document Correction', 'Please re-upload a clear copy of your income certificate and updated caste certificate.', 'WARNING', FALSE, 'student/tracking?appId=4', '2026-09-18 11:05:00');

-- 9. SEED AUDIT LOGS
INSERT INTO audit_logs (id, user_id, action, entity_type, entity_id, details, ip_address, created_at) VALUES
(1, 1, 'SYSTEM_INITIALIZATION', 'SYSTEM', 1, 'Database schema and advanced security rules initialized.', '127.0.0.1', '2026-09-01 00:00:00'),
(2, 4, 'SUBMIT_APPLICATION', 'APPLICATION', 1, 'Submitted application APP-2026-001 for Merit-Cum-Means Scholarship.', '192.168.1.101', '2026-09-10 10:30:00'),
(3, 2, 'VERIFY_DOCUMENT', 'DOCUMENT', 1, 'Income certificate verified against digital verification portal.', '192.168.1.50', '2026-09-15 14:15:00'),
(4, 2, 'STATUS_CHANGE_APPROVED', 'APPLICATION', 1, 'Application APP-2026-001 approved for disbursement.', '192.168.1.50', '2026-09-15 14:20:00'),
(5, 7, 'SUBMIT_APPLICATION', 'APPLICATION', 4, 'Submitted application APP-2026-004 for Social Inclusion Scholarship.', '192.168.1.104', '2026-09-16 16:00:00'),
(6, 3, 'STATUS_CHANGE_RESUBMISSION_REQUESTED', 'APPLICATION', 4, 'Requested student to upload valid unblurred documents.', '192.168.1.51', '2026-09-18 11:00:00');
