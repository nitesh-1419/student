# Advanced Scholarship Management, Verification & Fraud-Risk Assistance System

## 1. System Overview & Technology Stack
- **Target Java Version:** Java 11 (LTS)
- **Framework & Web Layer:** Java EE 8 / Jakarta Web Profile targeting **Apache Tomcat 9.0.x** with `javax.servlet:javax.servlet-api:4.0.1` (provided scope), JavaServer Pages (JSP 2.3), JSTL 1.2
- **Persistence & Database:** Pure JDBC with parameterized `PreparedStatement` on **MySQL 8.0+** InnoDB with connection pooling
- **Security Architecture:** PBKDF2WithHmacSHA256 (65,536 iterations, 16-byte random salt), CSRF token defense, login rate-limiting throttler, file magic bytes verification, secure non-public document streaming
- **Build & Packaging:** Apache Maven (`pom.xml`) generating deployable `scholarship-system.war`
- **IDE Compatibility:** Eclipse IDE for Enterprise Java and Web Developers (2020-06 through 2024+) with standard Maven Web Project import

---

## 2. Directory Structure & Architecture
```
scholarship/
├── pom.xml                                       # Maven build descriptor (Java 11, Tomcat 9, MySQL Connector 8.4.0)
├── .project                                      # Eclipse project metadata with Java & WTP Facet natures
├── .classpath                                    # Eclipse classpath referencing JavaSE-11 and Maven Dependencies
├── .settings/
│   ├── org.eclipse.core.resources.prefs          # UTF-8 character encoding configuration
│   ├── org.eclipse.wst.common.component          # Deployment Assembly mapping /src/main/webapp and classes
│   └── org.eclipse.wst.common.project.facet.core.xml # Facet definitions: java 11, jst.web 4.0
├── src/
│   ├── main/
│   │   ├── java/com/scholarship/
│   │   │   ├── model/                            # Domain Entities
│   │   │   │   ├── User.java                     # Authenticated actors (STUDENT, OFFICER, ADMIN)
│   │   │   │   ├── Student.java                  # Academic & demographic profiles
│   │   │   │   ├── Scholarship.java              # Grant criteria, slots, funding limits
│   │   │   │   ├── Application.java              # Submission lifecycle & draft status
│   │   │   │   ├── Document.java                 # Uploaded proofs, SHA-256 hashes, status
│   │   │   │   ├── AuditLog.java                 # Immutable security audit trail
│   │   │   │   ├── Notification.java             # In-app alerts and notifications
│   │   │   │   ├── StatusHistory.java            # Detailed workflow transition log
│   │   │   │   ├── FraudFlag.java                # Explainable risk factors and dismissals
│   │   │   │   └── ReportSummary.java            # Aggregated analytics for Admin portal
│   │   │   ├── dao/                              # Data Access Layer (JDBC PreparedStatements)
│   │   │   │   ├── UserDAO.java
│   │   │   │   ├── StudentDAO.java
│   │   │   │   ├── ScholarshipDAO.java
│   │   │   │   ├── ApplicationDAO.java
│   │   │   │   ├── DocumentDAO.java
│   │   │   │   ├── VerificationDAO.java
│   │   │   │   ├── NotificationDAO.java
│   │   │   │   ├── StatusHistoryDAO.java
│   │   │   │   ├── FraudFlagDAO.java
│   │   │   │   ├── ReportDAO.java
│   │   │   │   └── AuditDAO.java
│   │   │   ├── service/                          # Business Intelligence Layer
│   │   │   │   ├── EligibilityService.java       # Weighted Merit (60%) + Need (40%) calculation
│   │   │   │   ├── FraudDetectionService.java    # Duplicate hash & anomaly rule engine
│   │   │   │   ├── WorkflowService.java          # State machine: DRAFT -> SUBMITTED -> REVIEW -> DECISION
│   │   │   │   ├── NotificationService.java      # Milestone alert dispatcher
│   │   │   │   └── EmailService.java             # Asynchronous SMTP client with safe fallback
│   │   │   ├── servlet/                          # Controller / HTTP Handlers
│   │   │   │   ├── LoginServlet.java             # Authentication, session fixation defense, registration
│   │   │   │   ├── LogoutServlet.java            # Session invalidation & cookie cleanup
│   │   │   │   ├── ApplicationServlet.java       # Application submission & multi-step drafts
│   │   │   │   ├── DocumentUploadServlet.java    # Magic bytes check, SHA-256 checksum, upload
│   │   │   │   ├── DocumentDownloadServlet.java  # Authorized document streaming (IDOR & Traversal defense)
│   │   │   │   ├── OfficerDashboardServlet.java  # Review queue & applicant dossier inspector
│   │   │   │   ├── VerifyServlet.java            # Officer approval, rejection, and flag dismissal
│   │   │   │   ├── ResubmitApplicationServlet.java # Student resubmission after corrections
│   │   │   │   ├── AdminDashboardServlet.java    # System metrics, user governance & diagnostics
│   │   │   │   ├── ReportServlet.java            # Analytics reports & streaming CSV export
│   │   │   │   └── NotificationServlet.java      # Student alert polling and read status
│   │   │   ├── filter/                           # Security Interceptors
│   │   │   │   ├── AuthFilter.java               # Role boundary enforcement (STUDENT, OFFICER, ADMIN)
│   │   │   │   └── SecurityHeaderFilter.java     # X-Frame-Options, XSS protection, anti-cache
│   │   │   └── util/                             # Infrastructure Utilities
│   │   │       ├── DBConnection.java             # Connection pool & failover manager
│   │   │       ├── PasswordUtil.java             # PBKDF2WithHmacSHA256 slow hashing
│   │   │       ├── CSRFUtil.java                 # Anti-CSRF token verification
│   │   │       ├── LoginThrottler.java           # Brute-force rate limiting
│   │   │       └── FileSecurityUtil.java         # Magic bytes signature validation
│   │   ├── resources/
│   │   │   ├── db.properties                     # Database connection pool settings
│   │   │   ├── schema.sql                        # Complete MySQL 8 DDL with constraints & indexes
│   │   │   └── seed.sql                          # Development seed data for testing
│   │   └── webapp/
│   │       ├── assets/
│   │       │   └── app.css                       # Responsive enterprise UI stylesheet
│   │       ├── WEB-INF/
│   │       │   └── web.xml                       # Servlet 4.0 configuration & error pages
│   │       ├── index.jsp                         # Portal landing, sign-in & registration
│   │       ├── student/
│   │       │   ├── dashboard.jsp                 # Student overview & active scholarships
│   │       │   ├── apply.jsp                     # Multi-step application wizard & criteria check
│   │       │   ├── tracking.jsp                  # Status timeline, document manager & resubmission
│   │       │   └── notifications.jsp             # In-app message center
│   │       ├── officer/
│   │       │   └── dashboard.jsp                 # Verification workbench & fraud risk dismissal
│   │       └── admin/
│   │           ├── dashboard.jsp                 # KPI cards, user governance & runtime health
│   │           └── reports.jsp                   # Filterable intelligence & CSV export
│   └── test/
│       └── java/com/scholarship/                 # Automated Unit Tests
│           ├── EligibilityServiceTest.java       # Merit/need scoring and rule tests
│           ├── FraudDetectionServiceTest.java    # Risk detection & document check tests
│           ├── WorkflowServiceTest.java          # State machine transition rules
│           └── PasswordUtilTest.java             # PBKDF2 hashing & constant-time comparison
└── README_ECLIPSE.md                             # Step-by-step Eclipse import & deployment guide
```

---

## 3. Database Initialization (MySQL 8)
1. Verify MySQL 8.0+ server is running on port 3306.
2. In terminal or command prompt:
```bash
mysql -u root -p
```
3. Execute the schema creation and seed data:
```sql
SOURCE /path/to/scholarship/src/main/resources/schema.sql;
SOURCE /path/to/scholarship/src/main/resources/seed.sql;
```
4. Verify table initialization:
```sql
USE scholarship_db;
SHOW TABLES;
```

---

## 4. Default Seed Accounts
| Username | Default Password | Role | Description |
|---|---|---|---|
| `admin` | `Password@123` | ADMIN | System Administrator (Dr. Arvind Sharma) |
| `officer1` | `Password@123` | OFFICER | Senior Verification Officer (Sunita Rao) |
| `officer2` | `Password@123` | OFFICER | Verification Officer (Rajesh Kulkarni) |
| `rahul_sharma` | `Password@123` | STUDENT | B.Tech CS Student (Approved Application) |
| `priya_patel` | `Password@123` | STUDENT | B.Tech EE Student (Under Review Application) |
| `vikram_kumar` | `Password@123` | STUDENT | B.Tech ME Student (Resubmission Requested) |

---

## 5. Building and Testing with Maven
```bash
cd scholarship
mvn clean test
mvn clean package
```
Deployable WAR artifact will be generated at `target/scholarship-system.war`.
