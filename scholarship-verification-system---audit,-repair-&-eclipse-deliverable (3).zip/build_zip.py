import os
import zipfile
import shutil

def make_zip(source_dir, output_zip, prefix=""):
    with zipfile.ZipFile(output_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(source_dir):
            # Exclude unwanted directories
            dirs[:] = [d for d in dirs if d not in ('target', '.git', 'node_modules', '.DS_Store')]
            for file in files:
                if file.endswith('.class') or file == '.DS_Store':
                    continue
                file_path = os.path.join(root, file)
                rel_path = os.path.relpath(file_path, os.path.dirname(source_dir) if prefix else source_dir)
                if prefix and not rel_path.startswith(prefix):
                    rel_path = os.path.join(prefix, rel_path)
                zipf.write(file_path, rel_path)
    print(f"Created {output_zip} (size: {os.path.getsize(output_zip):,} bytes)")

if __name__ == "__main__":
    os.makedirs("/public", exist_ok=True)
    
    # 1. Archive with 'scholarship/' top directory for standard extraction
    make_zip("/scholarship", "/public/scholarship-system-corrected.zip", prefix="scholarship")
    shutil.copy2("/public/scholarship-system-corrected.zip", "/scholarship-system-corrected.zip")
    
    # 2. Eclipse project zip
    shutil.copy2("/public/scholarship-system-corrected.zip", "/public/scholarship-eclipse-project.zip")
    shutil.copy2("/public/scholarship-system-corrected.zip", "/scholarship-eclipse-project.zip")
    
    # 3. Full codebase zip
    shutil.copy2("/public/scholarship-system-corrected.zip", "/public/scholarship-full-codebase.zip")
    shutil.copy2("/public/scholarship-system-corrected.zip", "/scholarship-full-codebase.zip")

    # Also copy key files to public for easy viewing/downloading
    for f in ["pom.xml", "README.md", "README_ECLIPSE.md"]:
        src = os.path.join("/scholarship", f)
        if os.path.exists(src):
            shutil.copy2(src, os.path.join("/public", f))
            
    for f in ["schema.sql", "seed.sql"]:
        src = os.path.join("/scholarship/src/main/resources", f)
        if os.path.exists(src):
            shutil.copy2(src, os.path.join("/public", f))

    print("All zip archives and public assets updated successfully.")
