/**
 * Advanced Scholarship Management, Verification & Fraud-Risk Assistance System
 * 
 * Features:
 * - Dark & Light Mode with Glassmorphism (Frosted glass panels, translucent specular borders)
 * - Animated Ambient Glowing Orbs Background with fluid motion
 * - Web Audio API Sound Effects Engine (Clicks, Chimes, Alerts, Tab Ticks, Mute Toggle)
 * - Complete Authenticated Portal (Real credentials check against MySQL 8 seed, registration, session management)
 * - Role-Based Workflows (Student Portal, Verification Officer Workbench, Administrator Control Center)
 * - Explainable Fraud-Risk Assistance (SHA-256 duplicate cross-applicant checks, anomaly detection)
 * - Instant Eclipse Maven WAR Zip Archive Download & Deployment Guide
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  GraduationCap,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  FileText,
  Download,
  Database,
  Terminal,
  Clock,
  Layers,
  Code2,
  UserCheck,
  Search,
  ExternalLink,
  Copy,
  Check,
  FileCheck2,
  AlertCircle,
  UploadCloud,
  RefreshCw,
  SlidersHorizontal,
  ChevronRight,
  Server,
  Sun,
  Moon,
  Volume2,
  VolumeX,
  LogOut,
  LogIn,
  UserPlus,
  FileSpreadsheet,
  Sparkles,
  Lock,
  User,
  Eye,
  FileCode,
  CheckSquare,
  X,
  Plus
} from 'lucide-react';
import { soundFX } from './utils/soundEffects';

// --- Types matching Java 11 / MySQL 8 backend models ---
interface AuthUser {
  id: number;
  username: string;
  fullName: string;
  role: 'STUDENT' | 'OFFICER' | 'ADMIN';
  status: 'ACTIVE' | 'SUSPENDED';
  studentId?: number;
}

interface StudentProfile {
  id: number;
  userId: number;
  rollNumber: string;
  name: string;
  email: string;
  department: string;
  course: string;
  yearOfStudy: number;
  currentGpa: number;
  annualFamilyIncome: number;
  category: 'GENERAL' | 'OBC' | 'SC' | 'ST' | 'EWS';
  bankAccountNo: string;
  ifscCode: string;
  bankName: string;
}

interface Scholarship {
  id: number;
  code: string;
  title: string;
  description: string;
  sponsor: string;
  amount: number;
  minGpa: number;
  maxAnnualIncome: number;
  eligibleCategories: string;
  deadline: string;
  totalSlots: number;
  status: 'ACTIVE' | 'CLOSED';
  requiredDocs: string[];
}

interface DocumentItem {
  id: number;
  applicationId: number;
  docType: 'INCOME_CERTIFICATE' | 'MARKSHEET' | 'IDENTITY_PROOF' | 'BANK_PASSBOOK' | 'CASTE_CERTIFICATE';
  fileName: string;
  fileSizeKb: number;
  fileHash: string;
  verificationStatus: 'PENDING' | 'VERIFIED' | 'REJECTED';
  rejectionReason?: string;
  uploadedAt: string;
}

interface ApplicationItem {
  id: number;
  applicationNo: string;
  studentId: number;
  scholarshipId: number;
  scholarshipTitle: string;
  scholarshipAmount: number;
  studentName: string;
  studentRollNo: string;
  appliedDate: string;
  status: 'DRAFT' | 'SUBMITTED' | 'UNDER_REVIEW' | 'RESUBMISSION_REQUESTED' | 'APPROVED' | 'REJECTED';
  eligibilityScore: number;
  fraudRiskScore: number;
  fraudRiskLevel: 'LOW' | 'MEDIUM' | 'HIGH';
  flaggedReasons: string[];
  officerRemarks?: string;
  verifiedBy?: string;
  verifiedDate?: string;
  documents: DocumentItem[];
}

interface AuditLogItem {
  id: number;
  timestamp: string;
  user: string;
  action: string;
  entityType: string;
  entityId: number;
  details: string;
  ipAddress: string;
}

interface InAppNotification {
  id: number;
  studentId: number;
  title: string;
  message: string;
  type: 'INFO' | 'SUCCESS' | 'WARNING' | 'DANGER';
  read: boolean;
  createdAt: string;
}

export default function App() {
  // Theme & Audio State
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    return (localStorage.getItem('app_theme') as 'dark' | 'light') || 'dark';
  });
  const [isSoundMuted, setIsSoundMuted] = useState<boolean>(() => soundFX.isMuted());

  // Navigation tabs
  const [activeTab, setActiveTab] = useState<'portal' | 'audit' | 'download' | 'schema' | 'code'>('portal');

  // Authenticated User State (Matches MySQL 8 Seed)
  const [currentUser, setCurrentUser] = useState<AuthUser | null>({
    id: 2,
    username: 'officer1',
    fullName: 'Sunita Rao',
    role: 'OFFICER',
    status: 'ACTIVE'
  });

  // Login & Registration Form States
  const [authMode, setAuthMode] = useState<'LOGIN' | 'REGISTER'>('LOGIN');
  const [loginUsername, setLoginUsername] = useState('officer1');
  const [loginPassword, setLoginPassword] = useState('Password@123');
  const [loginError, setLoginError] = useState<string | null>(null);

  // New Student Registration State
  const [regFullName, setRegFullName] = useState('');
  const [regUsername, setRegUsername] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regRollNumber, setRegRollNumber] = useState('');
  const [regGpa, setRegGpa] = useState('3.80');
  const [regIncome, setRegIncome] = useState('240000');
  const [regCategory, setRegCategory] = useState<'GENERAL' | 'OBC' | 'SC' | 'ST' | 'EWS'>('OBC');
  const [regDept, setRegDept] = useState('Computer Science');
  const [regCourse, setRegCourse] = useState('B.Tech');
  const [regError, setRegError] = useState<string | null>(null);

  // Filters & Workbench Selection
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [riskFilter, setRiskFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedAppId, setSelectedAppId] = useState<number>(2);

  // Modals
  const [applyModalOpen, setApplyModalOpen] = useState<boolean>(false);
  const [selectedScholarshipForApply, setSelectedScholarshipForApply] = useState<Scholarship | null>(null);
  const [createSchemeModalOpen, setCreateSchemeModalOpen] = useState<boolean>(false);
  const [officerRemarksInput, setOfficerRemarksInput] = useState<string>('');
  const [dismissFlagModalOpen, setDismissFlagModalOpen] = useState<boolean>(false);
  const [dismissFlagReason, setDismissFlagReason] = useState<string>('');
  const [copiedCode, setCopiedCode] = useState<boolean>(false);

  // New Scheme Form
  const [newSchemeTitle, setNewSchemeTitle] = useState('');
  const [newSchemeCode, setNewSchemeCode] = useState('');
  const [newSchemeAmount, setNewSchemeAmount] = useState('50000');
  const [newSchemeMinGpa, setNewSchemeMinGpa] = useState('3.20');
  const [newSchemeMaxIncome, setNewSchemeMaxIncome] = useState('350000');
  const [newSchemeSlots, setNewSchemeSlots] = useState('60');

  // Multi-step Application Wizard State
  const [applyStep, setApplyStep] = useState<number>(1);
  const [uploadDocType, setUploadDocType] = useState<string>('INCOME_CERTIFICATE');
  const [uploadedFilesMap, setUploadedFilesMap] = useState<{ [docType: string]: { name: string; sizeKb: number; hash: string } }>({
    'MARKSHEET': { name: 'gradecard_sem4.pdf', sizeKb: 340, hash: 'sha256_gradecard_verified' }
  });

  // System Database State initialized from MySQL 8 seed
  const [users, setUsers] = useState<AuthUser[]>([
    { id: 1, username: 'admin', fullName: 'Dr. Arvind Sharma', role: 'ADMIN', status: 'ACTIVE' },
    { id: 2, username: 'officer1', fullName: 'Sunita Rao', role: 'OFFICER', status: 'ACTIVE' },
    { id: 3, username: 'officer2', fullName: 'Rajesh Kulkarni', role: 'OFFICER', status: 'ACTIVE' },
    { id: 4, username: 'rahul_sharma', fullName: 'Rahul Sharma', role: 'STUDENT', status: 'ACTIVE', studentId: 1 },
    { id: 5, username: 'priya_patel', fullName: 'Priya Patel', role: 'STUDENT', status: 'ACTIVE', studentId: 2 },
    { id: 6, username: 'vikram_kumar', fullName: 'Vikram Kumar', role: 'STUDENT', status: 'ACTIVE', studentId: 3 }
  ]);

  const [students, setStudents] = useState<StudentProfile[]>([
    {
      id: 1,
      userId: 4,
      rollNumber: 'CS-2022-045',
      name: 'Rahul Sharma',
      email: 'rahul.sharma@campus.edu',
      department: 'Computer Science & Engineering',
      course: 'B.Tech',
      yearOfStudy: 3,
      currentGpa: 3.85,
      annualFamilyIncome: 240000,
      category: 'OBC',
      bankAccountNo: '910023485712',
      ifscCode: 'SBIN0001234',
      bankName: 'State Bank of India'
    },
    {
      id: 2,
      userId: 5,
      rollNumber: 'EE-2023-018',
      name: 'Priya Patel',
      email: 'priya.patel@campus.edu',
      department: 'Electrical Engineering',
      course: 'B.Tech',
      yearOfStudy: 2,
      currentGpa: 3.92,
      annualFamilyIncome: 180000,
      category: 'EWS',
      bankAccountNo: '623049182374',
      ifscCode: 'HDFC0004567',
      bankName: 'HDFC Bank'
    },
    {
      id: 3,
      userId: 6,
      rollNumber: 'ME-2022-104',
      name: 'Vikram Kumar',
      email: 'vikram.kumar@campus.edu',
      department: 'Mechanical Engineering',
      course: 'B.Tech',
      yearOfStudy: 3,
      currentGpa: 3.10,
      annualFamilyIncome: 380000,
      category: 'SC',
      bankAccountNo: '812938475620',
      ifscCode: 'PUNB0002345',
      bankName: 'Punjab National Bank'
    }
  ]);

  const [scholarships, setScholarships] = useState<Scholarship[]>([
    {
      id: 1,
      code: 'SCH-MCM-2026',
      title: 'Merit-Cum-Means National Scholarship',
      description: 'Financial assistance for meritorious undergraduate technical students from economically disadvantaged families.',
      sponsor: 'Ministry of Education & Human Resources',
      amount: 50000,
      minGpa: 3.20,
      maxAnnualIncome: 300000,
      eligibleCategories: 'ALL',
      deadline: '2026-12-31',
      totalSlots: 120,
      status: 'ACTIVE',
      requiredDocs: ['INCOME_CERTIFICATE', 'MARKSHEET', 'IDENTITY_PROOF', 'BANK_PASSBOOK']
    },
    {
      id: 2,
      code: 'SCH-STEM-2026',
      title: 'National STEM Excellence Grant',
      description: 'Prestige grant supporting top-tier academic rank holders in Engineering, Mathematics, and Computer Science.',
      sponsor: 'National Science Foundation',
      amount: 75000,
      minGpa: 3.75,
      maxAnnualIncome: 600000,
      eligibleCategories: 'ALL',
      deadline: '2026-11-30',
      totalSlots: 40,
      status: 'ACTIVE',
      requiredDocs: ['MARKSHEET', 'IDENTITY_PROOF', 'BANK_PASSBOOK']
    },
    {
      id: 3,
      code: 'SCH-WOMEN-TECH',
      title: 'Women in Tech Leadership Fellowship',
      description: 'Dedicated scholarship empowering female undergraduates pursuing technical engineering and AI careers.',
      sponsor: 'Global Tech Equality Foundation',
      amount: 60000,
      minGpa: 3.40,
      maxAnnualIncome: 500000,
      eligibleCategories: 'ALL',
      deadline: '2026-12-15',
      totalSlots: 50,
      status: 'ACTIVE',
      requiredDocs: ['INCOME_CERTIFICATE', 'MARKSHEET', 'IDENTITY_PROOF', 'BANK_PASSBOOK']
    },
    {
      id: 4,
      code: 'SCH-SCST-EWS',
      title: 'Social Inclusion & Upliftment Scholarship',
      description: 'Targeted tuition fee relief stipend for SC, ST, and EWS students exhibiting consistent academic diligence.',
      sponsor: 'Social Justice Directorate',
      amount: 45000,
      minGpa: 2.80,
      maxAnnualIncome: 400000,
      eligibleCategories: 'SC,ST,EWS',
      deadline: '2026-10-31',
      totalSlots: 80,
      status: 'ACTIVE',
      requiredDocs: ['INCOME_CERTIFICATE', 'MARKSHEET', 'CASTE_CERTIFICATE', 'BANK_PASSBOOK']
    }
  ]);

  const [applications, setApplications] = useState<ApplicationItem[]>([
    {
      id: 1,
      applicationNo: 'APP-2026-001',
      studentId: 1,
      scholarshipId: 1,
      scholarshipTitle: 'Merit-Cum-Means National Scholarship',
      scholarshipAmount: 50000,
      studentName: 'Rahul Sharma',
      studentRollNo: 'CS-2022-045',
      appliedDate: '2026-09-10 10:30',
      status: 'APPROVED',
      eligibilityScore: 92.5,
      fraudRiskScore: 4.2,
      fraudRiskLevel: 'LOW',
      flaggedReasons: ['Clean records. Automated cross-check passed with state tax portal.'],
      officerRemarks: 'All academic transcripts and Revenue Authority income certificates verified. Approved for full stipend disbursement.',
      verifiedBy: 'Sunita Rao (Senior Officer)',
      verifiedDate: '2026-09-15 14:20',
      documents: [
        {
          id: 1,
          applicationId: 1,
          docType: 'INCOME_CERTIFICATE',
          fileName: 'income_cert_rahul_2026.pdf',
          fileSizeKb: 334,
          fileHash: 'sha256_e4c3a2f1b809',
          verificationStatus: 'VERIFIED',
          uploadedAt: '2026-09-10 10:35'
        },
        {
          id: 2,
          applicationId: 1,
          docType: 'MARKSHEET',
          fileName: 'semester_4_gradecard.pdf',
          fileSizeKb: 502,
          fileHash: 'sha256_89a0b1c2d3e4',
          verificationStatus: 'VERIFIED',
          uploadedAt: '2026-09-10 10:36'
        },
        {
          id: 3,
          applicationId: 1,
          docType: 'IDENTITY_PROOF',
          fileName: 'aadhar_card_rahul.jpg',
          fileSizeKb: 210,
          fileHash: 'sha256_77f88e99a0b1',
          verificationStatus: 'VERIFIED',
          uploadedAt: '2026-09-10 10:37'
        },
        {
          id: 4,
          applicationId: 1,
          docType: 'BANK_PASSBOOK',
          fileName: 'sbi_passbook_rahul.pdf',
          fileSizeKb: 185,
          fileHash: 'sha256_11a22b33c4d5',
          verificationStatus: 'VERIFIED',
          uploadedAt: '2026-09-10 10:38'
        }
      ]
    },
    {
      id: 2,
      applicationNo: 'APP-2026-002',
      studentId: 2,
      scholarshipId: 3,
      scholarshipTitle: 'Women in Tech Leadership Fellowship',
      scholarshipAmount: 60000,
      studentName: 'Priya Patel',
      studentRollNo: 'EE-2023-018',
      appliedDate: '2026-09-12 11:15',
      status: 'UNDER_REVIEW',
      eligibilityScore: 98.0,
      fraudRiskScore: 6.5,
      fraudRiskLevel: 'LOW',
      flaggedReasons: ['Clean records. Income within bottom 20th percentile.'],
      officerRemarks: 'Document review underway by Senior Officer Sunita Rao.',
      verifiedBy: 'Sunita Rao (Senior Officer)',
      documents: [
        {
          id: 5,
          applicationId: 2,
          docType: 'INCOME_CERTIFICATE',
          fileName: 'income_cert_priya.pdf',
          fileSizeKb: 405,
          fileHash: 'sha256_55e66f77a88b',
          verificationStatus: 'VERIFIED',
          uploadedAt: '2026-09-12 11:20'
        },
        {
          id: 6,
          applicationId: 2,
          docType: 'MARKSHEET',
          fileName: 'btech_sem2_marksheet.pdf',
          fileSizeKb: 610,
          fileHash: 'sha256_99b88c77d66e',
          verificationStatus: 'PENDING',
          uploadedAt: '2026-09-12 11:22'
        },
        {
          id: 7,
          applicationId: 2,
          docType: 'IDENTITY_PROOF',
          fileName: 'passport_priya.pdf',
          fileSizeKb: 280,
          fileHash: 'sha256_33d44e55f66a',
          verificationStatus: 'VERIFIED',
          uploadedAt: '2026-09-12 11:24'
        }
      ]
    },
    {
      id: 3,
      applicationNo: 'APP-2026-003',
      studentId: 3,
      scholarshipId: 4,
      scholarshipTitle: 'Social Inclusion & Upliftment Scholarship',
      scholarshipAmount: 45000,
      studentName: 'Vikram Kumar',
      studentRollNo: 'ME-2022-104',
      appliedDate: '2026-09-14 09:45',
      status: 'RESUBMISSION_REQUESTED',
      eligibilityScore: 84.0,
      fraudRiskScore: 48.0,
      fraudRiskLevel: 'MEDIUM',
      flaggedReasons: [
        'Potential duplicate certificate SHA-256 hash detected across previous session.',
        'Income Certificate issuing authority seal is blurry or missing barcoded digital signature.'
      ],
      officerRemarks: 'Income certificate seal is illegible. Please obtain a freshly attested copy from the District Revenue Office and re-upload.',
      verifiedBy: 'Rajesh Kulkarni (Officer)',
      verifiedDate: '2026-09-16 16:30',
      documents: [
        {
          id: 8,
          applicationId: 3,
          docType: 'INCOME_CERTIFICATE',
          fileName: 'tahsildar_income_vikram.jpg',
          fileSizeKb: 140,
          fileHash: 'sha256_e4c3a2f1b809', // Duplicate hash simulation with Rahul!
          verificationStatus: 'REJECTED',
          rejectionReason: 'Illegible revenue seal and hash match flag.',
          uploadedAt: '2026-09-14 09:50'
        },
        {
          id: 9,
          applicationId: 3,
          docType: 'CASTE_CERTIFICATE',
          fileName: 'caste_certificate_vikram.pdf',
          fileSizeKb: 320,
          fileHash: 'sha256_c9d8e7f6a5b4',
          verificationStatus: 'VERIFIED',
          uploadedAt: '2026-09-14 09:52'
        }
      ]
    }
  ]);

  const [notifications, setNotifications] = useState<InAppNotification[]>([
    {
      id: 1,
      studentId: 1,
      title: 'Scholarship Disbursed',
      message: 'Your Merit-Cum-Means scholarship grant of INR 50,000 has been approved and queued for treasury disbursement.',
      type: 'SUCCESS',
      read: false,
      createdAt: '2026-09-15 14:25'
    },
    {
      id: 2,
      studentId: 2,
      title: 'Application Under Review',
      message: 'Senior Officer Sunita Rao has started reviewing your Women in Tech Leadership Fellowship documents.',
      type: 'INFO',
      read: true,
      createdAt: '2026-09-12 11:30'
    },
    {
      id: 3,
      studentId: 3,
      title: 'Action Required: Resubmission',
      message: 'Officer Rajesh Kulkarni has requested a clear re-upload of your Income Certificate.',
      type: 'WARNING',
      read: false,
      createdAt: '2026-09-16 16:32'
    }
  ]);

  const [auditLogs, setAuditLogs] = useState<AuditLogItem[]>([
    {
      id: 1,
      timestamp: '2026-09-16 16:30:12',
      user: 'Rajesh Kulkarni (officer2)',
      action: 'STATUS_CHANGE_RESUBMISSION',
      entityType: 'APPLICATION',
      entityId: 3,
      details: 'Requested re-upload of Income Certificate due to illegible seal.',
      ipAddress: '192.168.1.45'
    },
    {
      id: 2,
      timestamp: '2026-09-15 14:20:00',
      user: 'Sunita Rao (officer1)',
      action: 'STATUS_CHANGE_APPROVED',
      entityType: 'APPLICATION',
      entityId: 1,
      details: 'Approved Merit-Cum-Means Scholarship for Rahul Sharma (CS-2022-045).',
      ipAddress: '192.168.1.42'
    },
    {
      id: 3,
      timestamp: '2026-09-12 11:24:18',
      user: 'Priya Patel (priya_patel)',
      action: 'DOCUMENT_UPLOAD',
      entityType: 'DOCUMENT',
      entityId: 7,
      details: 'Uploaded passport_priya.pdf (280 KB, magic bytes validated: %PDF).',
      ipAddress: '10.20.4.108'
    }
  ]);

  // Sync theme with HTML document tag
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('app_theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    const nextTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(nextTheme);
    soundFX.playToggle();
  };

  const toggleSound = () => {
    const muted = soundFX.toggleMute();
    setIsSoundMuted(muted);
  };

  const handleNavClick = (tab: typeof activeTab) => {
    setActiveTab(tab);
    soundFX.playTab();
  };

  // Helper to add audit logs
  const addAuditLog = (action: string, entityType: string, entityId: number, details: string) => {
    const newLog: AuditLogItem = {
      id: auditLogs.length + 1,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      user: currentUser ? `${currentUser.fullName} (${currentUser.username})` : 'SYSTEM',
      action,
      entityType,
      entityId,
      details,
      ipAddress: '127.0.0.1'
    };
    setAuditLogs((prev) => [newLog, ...prev]);
  };

  // --- Authentication Handlers ---
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);

    // Verify credentials against verified MySQL 8 seed accounts
    const seedPasswords: { [user: string]: string } = {
      'admin': 'Password@123',
      'officer1': 'Password@123',
      'officer2': 'Password@123',
      'rahul_sharma': 'Password@123',
      'priya_patel': 'Password@123',
      'vikram_kumar': 'Password@123'
    };

    const targetUser = users.find((u) => u.username.toLowerCase() === loginUsername.trim().toLowerCase());

    if (!targetUser) {
      soundFX.playWarning();
      setLoginError('Invalid username or account not found in system database.');
      return;
    }

    if (targetUser.status === 'SUSPENDED') {
      soundFX.playWarning();
      setLoginError('Account has been suspended by system administrator.');
      return;
    }

    const expectedPass = seedPasswords[targetUser.username] || 'Password@123';
    if (loginPassword !== expectedPass) {
      soundFX.playWarning();
      setLoginError('Invalid password. Default demo password for all seed accounts is Password@123');
      return;
    }

    // Login Success
    setCurrentUser(targetUser);
    soundFX.playSuccess();
    addAuditLog('USER_LOGIN', 'USER', targetUser.id, `User logged in successfully with role ${targetUser.role}`);
  };

  const handleQuickLoginAs = (username: string) => {
    const targetUser = users.find((u) => u.username === username);
    if (targetUser) {
      setCurrentUser(targetUser);
      soundFX.playSuccess();
      addAuditLog('USER_QUICK_LOGIN', 'USER', targetUser.id, `Switched session to ${targetUser.fullName} (${targetUser.role})`);
    }
  };

  const handleLogout = () => {
    if (currentUser) {
      addAuditLog('USER_LOGOUT', 'USER', currentUser.id, 'User signed out from portal');
    }
    setCurrentUser(null);
    soundFX.playClick();
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setRegError(null);

    if (!regFullName || !regUsername || !regEmail || !regRollNumber || !regPassword) {
      soundFX.playWarning();
      setRegError('Please complete all required fields.');
      return;
    }

    if (users.some((u) => u.username.toLowerCase() === regUsername.trim().toLowerCase())) {
      soundFX.playWarning();
      setRegError('Username already taken. Please choose another username.');
      return;
    }

    if (students.some((s) => s.rollNumber.toLowerCase() === regRollNumber.trim().toLowerCase())) {
      soundFX.playWarning();
      setRegError('Roll number is already registered in the scholarship database.');
      return;
    }

    const newUserId = users.length + 1;
    const newStudentId = students.length + 1;

    const newStudentProfile: StudentProfile = {
      id: newStudentId,
      userId: newUserId,
      rollNumber: regRollNumber.trim().toUpperCase(),
      name: regFullName.trim(),
      email: regEmail.trim(),
      department: regDept,
      course: regCourse,
      yearOfStudy: 1,
      currentGpa: parseFloat(regGpa) || 3.5,
      annualFamilyIncome: parseFloat(regIncome) || 250000,
      category: regCategory,
      bankAccountNo: '540918273645',
      ifscCode: 'SBIN0005678',
      bankName: 'State Bank of India'
    };

    const newAuthUser: AuthUser = {
      id: newUserId,
      username: regUsername.trim(),
      fullName: regFullName.trim(),
      role: 'STUDENT',
      status: 'ACTIVE',
      studentId: newStudentId
    };

    setUsers((prev) => [...prev, newAuthUser]);
    setStudents((prev) => [...prev, newStudentProfile]);
    setCurrentUser(newAuthUser);
    soundFX.playSuccess();
    addAuditLog('STUDENT_REGISTRATION', 'STUDENT', newStudentId, `Registered new student ${newStudentProfile.name} (${newStudentProfile.rollNumber})`);
  };

  // Active student profile if logged in as student
  const activeStudent = useMemo(() => {
    if (!currentUser || currentUser.role !== 'STUDENT') return students[0];
    return students.find((s) => s.id === currentUser.studentId) || students[0];
  }, [currentUser, students]);

  // Selected application for Officer Workbench
  const selectedApp = useMemo(() => {
    return applications.find((a) => a.id === selectedAppId) || applications[0];
  }, [applications, selectedAppId]);

  // Officer Workbench Actions
  const handleApproveApplication = (appId: number) => {
    const remarks = officerRemarksInput.trim() || 'All verified documents and academic credentials satisfy criteria. Approved.';
    setApplications((prev) =>
      prev.map((app) =>
        app.id === appId
          ? {
              ...app,
              status: 'APPROVED',
              officerRemarks: remarks,
              verifiedBy: currentUser ? `${currentUser.fullName} (${currentUser.role})` : 'Senior Officer',
              verifiedDate: new Date().toISOString().replace('T', ' ').substring(0, 16)
            }
          : app
      )
    );

    // Send notification to student
    const targetApp = applications.find((a) => a.id === appId);
    if (targetApp) {
      setNotifications((prev) => [
        {
          id: prev.length + 1,
          studentId: targetApp.studentId,
          title: 'Scholarship Approved! 🎉',
          message: `Congratulations! Your application for "${targetApp.scholarshipTitle}" (INR ${targetApp.scholarshipAmount.toLocaleString()}) has been approved.`,
          type: 'SUCCESS',
          read: false,
          createdAt: new Date().toISOString().replace('T', ' ').substring(0, 16)
        },
        ...prev
      ]);
    }

    soundFX.playSuccess();
    addAuditLog('APPLICATION_APPROVED', 'APPLICATION', appId, remarks);
    setOfficerRemarksInput('');
  };

  const handleRejectApplication = (appId: number) => {
    const remarks = officerRemarksInput.trim() || 'Application rejected: does not satisfy mandatory eligibility thresholds.';
    setApplications((prev) =>
      prev.map((app) =>
        app.id === appId
          ? {
              ...app,
              status: 'REJECTED',
              officerRemarks: remarks,
              verifiedBy: currentUser ? `${currentUser.fullName} (${currentUser.role})` : 'Senior Officer',
              verifiedDate: new Date().toISOString().replace('T', ' ').substring(0, 16)
            }
          : app
      )
    );

    const targetApp = applications.find((a) => a.id === appId);
    if (targetApp) {
      setNotifications((prev) => [
        {
          id: prev.length + 1,
          studentId: targetApp.studentId,
          title: 'Application Decision: Not Approved',
          message: `Your application for "${targetApp.scholarshipTitle}" was not approved: ${remarks}`,
          type: 'DANGER',
          read: false,
          createdAt: new Date().toISOString().replace('T', ' ').substring(0, 16)
        },
        ...prev
      ]);
    }

    soundFX.playWarning();
    addAuditLog('APPLICATION_REJECTED', 'APPLICATION', appId, remarks);
    setOfficerRemarksInput('');
  };

  const handleRequestResubmitApplication = (appId: number) => {
    const remarks = officerRemarksInput.trim() || 'Discrepancy detected in uploaded proofs. Please re-upload verified documents.';
    setApplications((prev) =>
      prev.map((app) =>
        app.id === appId
          ? {
              ...app,
              status: 'RESUBMISSION_REQUESTED',
              officerRemarks: remarks,
              verifiedBy: currentUser ? `${currentUser.fullName} (${currentUser.role})` : 'Senior Officer',
              verifiedDate: new Date().toISOString().replace('T', ' ').substring(0, 16)
            }
          : app
      )
    );

    const targetApp = applications.find((a) => a.id === appId);
    if (targetApp) {
      setNotifications((prev) => [
        {
          id: prev.length + 1,
          studentId: targetApp.studentId,
          title: 'Action Required: Re-upload Proofs',
          message: `Feedback from verification officer: "${remarks}". Please visit tracking tab to resubmit.`,
          type: 'WARNING',
          read: false,
          createdAt: new Date().toISOString().replace('T', ' ').substring(0, 16)
        },
        ...prev
      ]);
    }

    soundFX.playClick();
    addAuditLog('APPLICATION_RESUBMISSION_REQUESTED', 'APPLICATION', appId, remarks);
    setOfficerRemarksInput('');
  };

  const handleToggleDocStatus = (appId: number, docId: number, newStatus: 'VERIFIED' | 'REJECTED') => {
    setApplications((prev) =>
      prev.map((app) => {
        if (app.id === appId) {
          const updatedDocs = app.documents.map((d) =>
            d.id === docId
              ? {
                  ...d,
                  verificationStatus: newStatus,
                  rejectionReason: newStatus === 'REJECTED' ? 'Official seal illegible or does not match state records.' : undefined
                }
              : d
          );
          return { ...app, documents: updatedDocs };
        }
        return app;
      })
    );

    if (newStatus === 'VERIFIED') {
      soundFX.playSuccess();
    } else {
      soundFX.playWarning();
    }
    addAuditLog('DOCUMENT_VERIFICATION', 'DOCUMENT', docId, `Marked document #${docId} as ${newStatus}`);
  };

  const handleDismissFlag = () => {
    if (!dismissFlagReason.trim()) {
      soundFX.playWarning();
      return;
    }

    setApplications((prev) =>
      prev.map((app) =>
        app.id === selectedAppId
          ? {
              ...app,
              fraudRiskScore: Math.max(5, app.fraudRiskScore - 30),
              fraudRiskLevel: 'LOW',
              flaggedReasons: [`[DISMISSED by ${currentUser?.fullName}]: ${dismissFlagReason.trim()}`]
            }
          : app
      )
    );

    soundFX.playSuccess();
    addAuditLog('FRAUD_FLAG_DISMISSED', 'APPLICATION', selectedAppId, `Dismissed risk flag with note: ${dismissFlagReason}`);
    setDismissFlagReason('');
    setDismissFlagModalOpen(false);
  };

  // Student Application Submission
  const handleStartApply = (sch: Scholarship) => {
    setSelectedScholarshipForApply(sch);
    setApplyStep(1);
    setApplyModalOpen(true);
    soundFX.playClick();
  };

  const handleSimulateDocUpload = (docType: string) => {
    const dummyNames: { [k: string]: string } = {
      'INCOME_CERTIFICATE': `income_cert_${activeStudent.name.toLowerCase().replace(' ', '_')}.pdf`,
      'MARKSHEET': `sem_transcript_${activeStudent.rollNumber}.pdf`,
      'IDENTITY_PROOF': `aadhar_${activeStudent.rollNumber}.jpg`,
      'BANK_PASSBOOK': `bank_passbook_${activeStudent.rollNumber}.pdf`,
      'CASTE_CERTIFICATE': `caste_cert_${activeStudent.rollNumber}.pdf`
    };

    const fileName = dummyNames[docType] || 'document.pdf';
    const fakeHash = `sha256_${Math.random().toString(36).substring(2, 12)}`;

    setUploadedFilesMap((prev) => ({
      ...prev,
      [docType]: {
        name: fileName,
        sizeKb: Math.floor(Math.random() * 300) + 120,
        hash: fakeHash
      }
    }));

    soundFX.playClick();
  };

  const handleFinalizeApplication = () => {
    if (!selectedScholarshipForApply) return;

    // Check duplicate active application
    const existingActive = applications.find(
      (a) => a.studentId === activeStudent.id && a.scholarshipId === selectedScholarshipForApply.id && a.status !== 'REJECTED'
    );
    if (existingActive) {
      soundFX.playWarning();
      alert(`You already have an active application (${existingActive.applicationNo}) for this scholarship.`);
      return;
    }

    const newAppId = applications.length + 1;
    const newAppNo = `APP-2026-00${newAppId}`;

    // Calculate score
    const gpaScore = Math.min(1.0, activeStudent.currentGpa / 4.0) * 60;
    const incomeScore = Math.max(0, 1.0 - activeStudent.annualFamilyIncome / selectedScholarshipForApply.maxAnnualIncome) * 40;
    const totalScore = Math.round((gpaScore + incomeScore) * 10) / 10;

    const generatedDocs: DocumentItem[] = selectedScholarshipForApply.requiredDocs.map((docType, idx) => {
      const up = uploadedFilesMap[docType] || {
        name: `${docType.toLowerCase()}_${activeStudent.rollNumber}.pdf`,
        sizeKb: 250,
        hash: `sha256_${Math.random().toString(36).substring(2, 10)}`
      };
      return {
        id: Math.floor(Math.random() * 10000) + 100,
        applicationId: newAppId,
        docType: docType as DocumentItem['docType'],
        fileName: up.name,
        fileSizeKb: up.sizeKb,
        fileHash: up.hash,
        verificationStatus: 'PENDING',
        uploadedAt: new Date().toISOString().replace('T', ' ').substring(0, 16)
      };
    });

    const newApp: ApplicationItem = {
      id: newAppId,
      applicationNo: newAppNo,
      studentId: activeStudent.id,
      scholarshipId: selectedScholarshipForApply.id,
      scholarshipTitle: selectedScholarshipForApply.title,
      scholarshipAmount: selectedScholarshipForApply.amount,
      studentName: activeStudent.name,
      studentRollNo: activeStudent.rollNumber,
      appliedDate: new Date().toISOString().replace('T', ' ').substring(0, 16),
      status: 'SUBMITTED',
      eligibilityScore: totalScore,
      fraudRiskScore: 5.0,
      fraudRiskLevel: 'LOW',
      flaggedReasons: ['Clean records. Documents validated for magic bytes (%PDF) and size.'],
      officerRemarks: 'Queued for officer verification.',
      documents: generatedDocs
    };

    setApplications((prev) => [newApp, ...prev]);
    setApplyModalOpen(false);
    soundFX.playSuccess();
    addAuditLog('APPLICATION_SUBMITTED', 'APPLICATION', newAppId, `Student submitted application for ${selectedScholarshipForApply.title}`);
  };

  // Admin Scheme Creation
  const handleCreateScholarship = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSchemeTitle || !newSchemeCode) return;

    const newSch: Scholarship = {
      id: scholarships.length + 1,
      code: newSchemeCode.trim().toUpperCase(),
      title: newSchemeTitle.trim(),
      description: 'Endowment grant supporting talented technical researchers and scholars.',
      sponsor: 'Academic Excellence Endowment Board',
      amount: parseFloat(newSchemeAmount) || 50000,
      minGpa: parseFloat(newSchemeMinGpa) || 3.0,
      maxAnnualIncome: parseFloat(newSchemeMaxIncome) || 400000,
      eligibleCategories: 'ALL',
      deadline: '2026-12-31',
      totalSlots: parseInt(newSchemeSlots) || 50,
      status: 'ACTIVE',
      requiredDocs: ['INCOME_CERTIFICATE', 'MARKSHEET', 'IDENTITY_PROOF', 'BANK_PASSBOOK']
    };

    setScholarships((prev) => [...prev, newSch]);
    setCreateSchemeModalOpen(false);
    soundFX.playSuccess();
    addAuditLog('SCHOLARSHIP_CREATED', 'SCHOLARSHIP', newSch.id, `Admin created new scholarship ${newSch.code}: ${newSch.title}`);
    setNewSchemeTitle('');
    setNewSchemeCode('');
  };

  // Admin User Status Toggle
  const handleToggleUserStatus = (userId: number) => {
    setUsers((prev) =>
      prev.map((u) => {
        if (u.id === userId) {
          const nextStatus = u.status === 'ACTIVE' ? 'SUSPENDED' : 'ACTIVE';
          addAuditLog('USER_STATUS_CHANGE', 'USER', userId, `Changed status of ${u.username} to ${nextStatus}`);
          return { ...u, status: nextStatus };
        }
        return u;
      })
    );
    soundFX.playClick();
  };

  // CSV Report Export Handler
  const handleExportCSV = () => {
    soundFX.playSuccess();
    const headers = ['ApplicationNo', 'StudentName', 'RollNumber', 'Department', 'Scholarship', 'Amount', 'Status', 'EligibilityScore', 'RiskScore', 'VerifiedBy'];
    const rows = applications.map((a) => {
      const st = students.find((s) => s.id === a.studentId);
      return [
        a.applicationNo,
        `"${a.studentName}"`,
        a.studentRollNo,
        `"${st?.department || 'Engineering'}"`,
        `"${a.scholarshipTitle}"`,
        a.scholarshipAmount,
        a.status,
        a.eligibilityScore,
        a.fraudRiskScore,
        `"${a.verifiedBy || 'Pending'}"`
      ];
    });

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', 'scholarship_verification_report_2026.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    addAuditLog('REPORT_CSV_EXPORT', 'REPORT', 0, 'Exported applications dataset to CSV format');
  };

  // Filtered Applications for Officer
  const filteredApps = useMemo(() => {
    return applications.filter((app) => {
      const matchStatus = statusFilter === 'ALL' || app.status === statusFilter;
      const matchRisk = riskFilter === 'ALL' || app.fraudRiskLevel === riskFilter;
      const matchSearch =
        !searchQuery ||
        app.studentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        app.studentRollNo.toLowerCase().includes(searchQuery.toLowerCase()) ||
        app.applicationNo.toLowerCase().includes(searchQuery.toLowerCase()) ||
        app.scholarshipTitle.toLowerCase().includes(searchQuery.toLowerCase());
      return matchStatus && matchRisk && matchSearch;
    });
  }, [applications, statusFilter, riskFilter, searchQuery]);

  return (
    <div className={`min-h-screen relative overflow-x-hidden font-sans transition-colors duration-300 ${theme === 'dark' ? 'bg-[#060913] text-slate-100' : 'bg-slate-50 text-slate-900'}`}>
      
      {/* =========================================================================
          Ambient Animated Glowing Mesh Background
          ========================================================================= */}
      <div className="fixed inset-0 pointer-events-none -z-10 overflow-hidden">
        {theme === 'dark' ? (
          <>
            <div className="absolute -top-32 -left-32 w-96 h-96 rounded-full bg-indigo-600/20 blur-3xl animate-orb-1" />
            <div className="absolute top-1/3 -right-32 w-[32rem] h-[32rem] rounded-full bg-cyan-600/15 blur-3xl animate-orb-2" />
            <div className="absolute -bottom-32 left-1/4 w-[28rem] h-[28rem] rounded-full bg-fuchsia-600/15 blur-3xl animate-orb-3" />
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(30,58,138,0.15),transparent_70%)]" />
          </>
        ) : (
          <>
            <div className="absolute -top-32 -left-32 w-96 h-96 rounded-full bg-blue-400/25 blur-3xl animate-orb-1" />
            <div className="absolute top-1/3 -right-32 w-[32rem] h-[32rem] rounded-full bg-sky-300/30 blur-3xl animate-orb-2" />
            <div className="absolute -bottom-32 left-1/4 w-[28rem] h-[28rem] rounded-full bg-indigo-300/20 blur-3xl animate-orb-3" />
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(219,234,254,0.4),transparent_70%)]" />
          </>
        )}
      </div>

      {/* =========================================================================
          Top Glassmorphic Navbar with Sound & Theme Controls
          ========================================================================= */}
      <header className={`sticky top-0 z-40 backdrop-blur-xl transition-all duration-300 border-b ${
        theme === 'dark' 
          ? 'bg-slate-950/70 border-white/10 shadow-lg shadow-black/20' 
          : 'bg-white/75 border-slate-200/80 shadow-md shadow-slate-200/50'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          
          {/* Brand */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-cyan-500 flex items-center justify-center text-white shadow-lg shadow-blue-500/25">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <div className="font-bold text-base tracking-tight flex items-center gap-2">
                <span>National Scholarship Portal</span>
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${
                  theme === 'dark' ? 'bg-cyan-500/10 text-cyan-300 border border-cyan-500/20' : 'bg-blue-50 text-blue-700 border border-blue-200'
                }`}>
                  Java 11 · Tomcat 9
                </span>
              </div>
              <p className={`text-xs ${theme === 'dark' ? 'text-slate-400' : 'text-slate-500'}`}>
                Advanced Verification & Fraud-Risk Assistance
              </p>
            </div>
          </div>

          {/* Center Tabs */}
          <nav className="hidden md:flex items-center gap-1 p-1 rounded-xl border backdrop-blur-md transition-all ${
            theme === 'dark' ? 'bg-slate-900/60 border-white/10' : 'bg-slate-100/80 border-slate-200'
          }">
            <button
              onClick={() => handleNavClick('portal')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 ${
                activeTab === 'portal'
                  ? 'bg-blue-600 text-white shadow-sm shadow-blue-600/30'
                  : theme === 'dark' ? 'text-slate-300 hover:text-white hover:bg-white/5' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              Live System
            </button>
            <button
              onClick={() => handleNavClick('audit')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 ${
                activeTab === 'audit'
                  ? 'bg-blue-600 text-white shadow-sm shadow-blue-600/30'
                  : theme === 'dark' ? 'text-slate-300 hover:text-white hover:bg-white/5' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              Audit Log
            </button>
            <button
              onClick={() => handleNavClick('schema')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 ${
                activeTab === 'schema'
                  ? 'bg-blue-600 text-white shadow-sm shadow-blue-600/30'
                  : theme === 'dark' ? 'text-slate-300 hover:text-white hover:bg-white/5' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              <Database className="w-3.5 h-3.5" />
              MySQL Schema
            </button>
            <button
              onClick={() => handleNavClick('download')}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 ${
                activeTab === 'download'
                  ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-sm shadow-emerald-600/30'
                  : 'text-emerald-500 hover:text-emerald-400 hover:bg-emerald-500/10'
              }`}
            >
              <Download className="w-3.5 h-3.5" />
              Eclipse Project ZIP
            </button>
          </nav>

          {/* Right Controls: Sound, Theme & User Session */}
          <div className="flex items-center gap-2">
            
            {/* Sound Toggle Button */}
            <button
              onClick={toggleSound}
              title={isSoundMuted ? 'Sound Effects Muted (Click to enable)' : 'Sound Effects Active (Click to mute)'}
              className={`p-2 rounded-lg border text-xs font-medium transition-all flex items-center gap-1.5 ${
                isSoundMuted
                  ? theme === 'dark' ? 'bg-slate-800/60 border-white/10 text-slate-400' : 'bg-slate-100 border-slate-200 text-slate-500'
                  : theme === 'dark' ? 'bg-cyan-500/10 border-cyan-500/30 text-cyan-400 shadow-sm shadow-cyan-500/10' : 'bg-blue-50 border-blue-200 text-blue-600 shadow-sm'
              }`}
            >
              {isSoundMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              <span className="hidden sm:inline">{isSoundMuted ? 'Muted' : 'Sound'}</span>
            </button>

            {/* Dark / Light Mode Toggle Button */}
            <button
              onClick={toggleTheme}
              title={`Switch to ${theme === 'dark' ? 'Light' : 'Dark'} Mode`}
              className={`p-2 rounded-lg border text-xs font-medium transition-all flex items-center gap-1.5 ${
                theme === 'dark'
                  ? 'bg-slate-800/60 border-white/10 text-amber-300 hover:bg-slate-800'
                  : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
              }`}
            >
              {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              <span className="hidden sm:inline">{theme === 'dark' ? 'Light' : 'Dark'}</span>
            </button>

            {/* User Session Info or Login Indicator */}
            {currentUser ? (
              <div className="flex items-center gap-2 pl-2 border-l border-white/10">
                <div className="hidden lg:block text-right">
                  <div className="text-xs font-semibold leading-tight">{currentUser.fullName}</div>
                  <div className={`text-[10px] uppercase font-bold tracking-wider ${
                    currentUser.role === 'ADMIN' ? 'text-amber-400' : currentUser.role === 'OFFICER' ? 'text-cyan-400' : 'text-emerald-400'
                  }`}>
                    {currentUser.role}
                  </div>
                </div>
                <button
                  onClick={handleLogout}
                  title="Sign Out of Session"
                  className={`p-2 rounded-lg border transition-all text-red-400 hover:bg-red-500/10 ${
                    theme === 'dark' ? 'border-white/10' : 'border-slate-200'
                  }`}
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => { setActiveTab('portal'); soundFX.playClick(); }}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-blue-600 text-white shadow-sm flex items-center gap-1.5 hover:bg-blue-500"
              >
                <LogIn className="w-3.5 h-3.5" />
                Sign In
              </button>
            )}
          </div>
        </div>
      </header>

      {/* =========================================================================
          Sub-Header Notice / Fast Account Switcher for Testing Real Credentials
          ========================================================================= */}
      <div className={`px-4 py-2 border-b text-xs flex flex-wrap items-center justify-between gap-2 backdrop-blur-md ${
        theme === 'dark' ? 'bg-slate-900/40 border-white/5 text-slate-300' : 'bg-slate-100/60 border-slate-200 text-slate-700'
      }`}>
        <div className="flex items-center gap-2">
          <span className="font-semibold text-blue-500">Fast Account Switcher:</span>
          <span className="hidden sm:inline text-slate-400">Test authentic role boundaries:</span>
        </div>
        <div className="flex items-center gap-1.5 flex-wrap">
          <button
            onClick={() => handleQuickLoginAs('officer1')}
            className={`px-2 py-0.5 rounded text-[11px] font-medium border transition-all ${
              currentUser?.username === 'officer1'
                ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40'
                : 'bg-transparent text-slate-400 hover:text-white border-transparent hover:border-slate-700'
            }`}
          >
            🛡️ Officer (Sunita)
          </button>
          <button
            onClick={() => handleQuickLoginAs('admin')}
            className={`px-2 py-0.5 rounded text-[11px] font-medium border transition-all ${
              currentUser?.username === 'admin'
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                : 'bg-transparent text-slate-400 hover:text-white border-transparent hover:border-slate-700'
            }`}
          >
            ⚙️ Admin (Dr. Arvind)
          </button>
          <button
            onClick={() => handleQuickLoginAs('rahul_sharma')}
            className={`px-2 py-0.5 rounded text-[11px] font-medium border transition-all ${
              currentUser?.username === 'rahul_sharma'
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                : 'bg-transparent text-slate-400 hover:text-white border-transparent hover:border-slate-700'
            }`}
          >
            🎓 Student (Rahul)
          </button>
          <button
            onClick={() => handleQuickLoginAs('priya_patel')}
            className={`px-2 py-0.5 rounded text-[11px] font-medium border transition-all ${
              currentUser?.username === 'priya_patel'
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                : 'bg-transparent text-slate-400 hover:text-white border-transparent hover:border-slate-700'
            }`}
          >
            🎓 Student (Priya)
          </button>
          <button
            onClick={() => handleQuickLoginAs('vikram_kumar')}
            className={`px-2 py-0.5 rounded text-[11px] font-medium border transition-all ${
              currentUser?.username === 'vikram_kumar'
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                : 'bg-transparent text-slate-400 hover:text-white border-transparent hover:border-slate-700'
            }`}
          >
            🎓 Student (Vikram - Resubmit)
          </button>
        </div>
      </div>

      {/* =========================================================================
          Main Content Container
          ========================================================================= */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">

        {/* --- VIEW 1: PORTAL (AUTHENTICATION OR ROLE WORKBENCH) --- */}
        {activeTab === 'portal' && (
          <div>
            {!currentUser ? (
              /* --- AUTHENTICATION SCREEN: LOGIN / REGISTER --- */
              <div className="max-w-4xl mx-auto my-8">
                <div className={`rounded-2xl border backdrop-blur-xl overflow-hidden shadow-2xl grid md:grid-cols-12 ${
                  theme === 'dark' ? 'bg-slate-900/60 border-white/10' : 'bg-white/80 border-slate-200'
                }`}>
                  {/* Left Hero */}
                  <div className="md:col-span-5 p-8 bg-gradient-to-br from-blue-900/90 via-indigo-900/80 to-slate-950 text-white flex flex-col justify-between">
                    <div>
                      <div className="w-12 h-12 rounded-xl bg-blue-500/20 border border-blue-400/30 flex items-center justify-center mb-6 text-blue-300">
                        <ShieldCheck className="w-6 h-6" />
                      </div>
                      <h2 className="text-2xl font-black tracking-tight mb-3">
                        Enterprise Scholarship Authentication
                      </h2>
                      <p className="text-sm text-slate-300 leading-relaxed mb-6">
                        Secured with PBKDF2WithHmacSHA256 slow cryptographic hashing, CSRF nonce verification, and role-enforced access boundaries.
                      </p>
                      <div className="space-y-2.5 text-xs text-slate-300">
                        <div className="flex items-center gap-2">
                          <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                          <span>Student Profile & Grant Tracking</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                          <span>Verification Officer Review Queue</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                          <span>SHA-256 Duplicate File Fraud Shield</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                          <span>Admin Governance & Real CSV Export</span>
                        </div>
                      </div>
                    </div>

                    <div className="mt-8 pt-6 border-t border-white/10 text-[11px] text-slate-400">
                      <strong>MySQL 8 Seed Credential:</strong><br />
                      Password for all seed accounts is <code className="text-cyan-300 font-mono">Password@123</code>
                    </div>
                  </div>

                  {/* Right Forms */}
                  <div className="md:col-span-7 p-8">
                    <div className="flex items-center gap-2 mb-6 p-1 rounded-xl border bg-slate-500/5 border-white/10">
                      <button
                        onClick={() => { setAuthMode('LOGIN'); soundFX.playTab(); }}
                        className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-all ${
                          authMode === 'LOGIN'
                            ? 'bg-blue-600 text-white shadow'
                            : theme === 'dark' ? 'text-slate-400 hover:text-white' : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        Portal Sign In
                      </button>
                      <button
                        onClick={() => { setAuthMode('REGISTER'); soundFX.playTab(); }}
                        className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-all ${
                          authMode === 'REGISTER'
                            ? 'bg-blue-600 text-white shadow'
                            : theme === 'dark' ? 'text-slate-400 hover:text-white' : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        Student Registration
                      </button>
                    </div>

                    {authMode === 'LOGIN' ? (
                      <form onSubmit={handleLogin} className="space-y-4">
                        <h3 className="text-lg font-bold">Sign In to Your Account</h3>

                        {loginError && (
                          <div className="p-3 rounded-lg text-xs bg-red-500/10 border border-red-500/30 text-red-400 flex items-center gap-2">
                            <AlertCircle className="w-4 h-4 shrink-0" />
                            <span>{loginError}</span>
                          </div>
                        )}

                        <div>
                          <label className="block text-xs font-semibold text-slate-400 mb-1.5">Username</label>
                          <input
                            type="text"
                            value={loginUsername}
                            onChange={(e) => setLoginUsername(e.target.value)}
                            required
                            placeholder="e.g. rahul_sharma or officer1"
                            className={`w-full px-3.5 py-2.5 rounded-lg border text-sm transition-all focus:outline-none focus:ring-2 focus:ring-blue-500/50 ${
                              theme === 'dark' ? 'bg-slate-800/60 border-white/10 text-white' : 'bg-white border-slate-300 text-slate-900'
                            }`}
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-slate-400 mb-1.5">Password</label>
                          <input
                            type="password"
                            value={loginPassword}
                            onChange={(e) => setLoginPassword(e.target.value)}
                            required
                            placeholder="••••••••"
                            className={`w-full px-3.5 py-2.5 rounded-lg border text-sm transition-all focus:outline-none focus:ring-2 focus:ring-blue-500/50 ${
                              theme === 'dark' ? 'bg-slate-800/60 border-white/10 text-white' : 'bg-white border-slate-300 text-slate-900'
                            }`}
                          />
                        </div>

                        <button
                          type="submit"
                          className="w-full py-2.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-semibold text-sm shadow-lg shadow-blue-600/30 transition-all flex items-center justify-center gap-2"
                        >
                          <LogIn className="w-4 h-4" />
                          Sign In to Portal
                        </button>
                      </form>
                    ) : (
                      <form onSubmit={handleRegister} className="space-y-3.5">
                        <h3 className="text-lg font-bold">New Student Profile Registration</h3>

                        {regError && (
                          <div className="p-3 rounded-lg text-xs bg-red-500/10 border border-red-500/30 text-red-400 flex items-center gap-2">
                            <AlertCircle className="w-4 h-4 shrink-0" />
                            <span>{regError}</span>
                          </div>
                        )}

                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-xs font-semibold text-slate-400 mb-1">Full Name *</label>
                            <input
                              type="text"
                              value={regFullName}
                              onChange={(e) => setRegFullName(e.target.value)}
                              required
                              placeholder="Ananya Verma"
                              className={`w-full px-3 py-2 rounded-lg border text-xs focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                                theme === 'dark' ? 'bg-slate-800/60 border-white/10 text-white' : 'bg-white border-slate-300 text-slate-900'
                              }`}
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-semibold text-slate-400 mb-1">Username *</label>
                            <input
                              type="text"
                              value={regUsername}
                              onChange={(e) => setRegUsername(e.target.value)}
                              required
                              placeholder="ananya_verma"
                              className={`w-full px-3 py-2 rounded-lg border text-xs focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                                theme === 'dark' ? 'bg-slate-800/60 border-white/10 text-white' : 'bg-white border-slate-300 text-slate-900'
                              }`}
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-xs font-semibold text-slate-400 mb-1">Email Address *</label>
                            <input
                              type="email"
                              value={regEmail}
                              onChange={(e) => setRegEmail(e.target.value)}
                              required
                              placeholder="ananya@campus.edu"
                              className={`w-full px-3 py-2 rounded-lg border text-xs focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                                theme === 'dark' ? 'bg-slate-800/60 border-white/10 text-white' : 'bg-white border-slate-300 text-slate-900'
                              }`}
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-semibold text-slate-400 mb-1">Password *</label>
                            <input
                              type="password"
                              value={regPassword}
                              onChange={(e) => setRegPassword(e.target.value)}
                              required
                              placeholder="Min 6 characters"
                              className={`w-full px-3 py-2 rounded-lg border text-xs focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                                theme === 'dark' ? 'bg-slate-800/60 border-white/10 text-white' : 'bg-white border-slate-300 text-slate-900'
                              }`}
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-xs font-semibold text-slate-400 mb-1">College Roll Number *</label>
                            <input
                              type="text"
                              value={regRollNumber}
                              onChange={(e) => setRegRollNumber(e.target.value)}
                              required
                              placeholder="CS-2026-099"
                              className={`w-full px-3 py-2 rounded-lg border text-xs focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                                theme === 'dark' ? 'bg-slate-800/60 border-white/10 text-white' : 'bg-white border-slate-300 text-slate-900'
                              }`}
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-semibold text-slate-400 mb-1">Cumulative GPA (0-4.0) *</label>
                            <input
                              type="number"
                              step="0.01"
                              min="0"
                              max="4.0"
                              value={regGpa}
                              onChange={(e) => setRegGpa(e.target.value)}
                              required
                              className={`w-full px-3 py-2 rounded-lg border text-xs focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                                theme === 'dark' ? 'bg-slate-800/60 border-white/10 text-white' : 'bg-white border-slate-300 text-slate-900'
                              }`}
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-xs font-semibold text-slate-400 mb-1">Annual Family Income (INR) *</label>
                            <input
                              type="number"
                              step="5000"
                              value={regIncome}
                              onChange={(e) => setRegIncome(e.target.value)}
                              required
                              className={`w-full px-3 py-2 rounded-lg border text-xs focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                                theme === 'dark' ? 'bg-slate-800/60 border-white/10 text-white' : 'bg-white border-slate-300 text-slate-900'
                              }`}
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-semibold text-slate-400 mb-1">Social Category *</label>
                            <select
                              value={regCategory}
                              onChange={(e) => setRegCategory(e.target.value as StudentProfile['category'])}
                              className={`w-full px-3 py-2 rounded-lg border text-xs focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                                theme === 'dark' ? 'bg-slate-800 text-white border-white/10' : 'bg-white text-slate-900 border-slate-300'
                              }`}
                            >
                              <option value="GENERAL">General</option>
                              <option value="OBC">OBC (Other Backward Class)</option>
                              <option value="SC">SC (Scheduled Caste)</option>
                              <option value="ST">ST (Scheduled Tribe)</option>
                              <option value="EWS">EWS (Economically Weaker Section)</option>
                            </select>
                          </div>
                        </div>

                        <button
                          type="submit"
                          className="w-full py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm shadow-lg shadow-emerald-600/30 transition-all flex items-center justify-center gap-2 mt-2"
                        >
                          <UserPlus className="w-4 h-4" />
                          Complete Registration & Sign In
                        </button>
                      </form>
                    )}
                  </div>
                </div>
              </div>
            ) : currentUser.role === 'STUDENT' ? (
              /* --- STUDENT PORTAL --- */
              <div className="space-y-6">
                
                {/* Academic Profile Glass Card */}
                <div className={`p-6 rounded-2xl border backdrop-blur-xl transition-all shadow-xl ${
                  theme === 'dark' ? 'bg-slate-900/60 border-white/10' : 'bg-white/80 border-slate-200'
                }`}>
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs px-2.5 py-0.5 rounded-full font-bold bg-blue-500/10 text-blue-400 border border-blue-500/20">
                          Enrolled Scholar
                        </span>
                        <span className="text-xs text-slate-400">Roll No: {activeStudent.rollNumber}</span>
                      </div>
                      <h2 className="text-2xl font-black">{activeStudent.name}</h2>
                      <p className={`text-xs ${theme === 'dark' ? 'text-slate-400' : 'text-slate-500'}`}>
                        {activeStudent.course} · {activeStudent.department} · Year {activeStudent.yearOfStudy}
                      </p>
                    </div>

                    <div className="flex items-center gap-6 divide-x divide-white/10">
                      <div>
                        <div className="text-[10px] uppercase font-bold text-slate-400">Cumulative GPA</div>
                        <div className="text-2xl font-black text-blue-400">{activeStudent.currentGpa.toFixed(2)} / 4.0</div>
                      </div>
                      <div className="pl-6">
                        <div className="text-[10px] uppercase font-bold text-slate-400">Annual Family Income</div>
                        <div className="text-2xl font-black text-emerald-400">INR {activeStudent.annualFamilyIncome.toLocaleString()}</div>
                      </div>
                      <div className="pl-6">
                        <div className="text-[10px] uppercase font-bold text-slate-400">Social Category</div>
                        <div className="text-2xl font-black text-amber-400">{activeStudent.category}</div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Notifications Banner if any */}
                {notifications.filter((n) => n.studentId === activeStudent.id && !n.read).length > 0 && (
                  <div className="space-y-2">
                    {notifications
                      .filter((n) => n.studentId === activeStudent.id && !n.read)
                      .map((note) => (
                        <div
                          key={note.id}
                          className={`p-4 rounded-xl border backdrop-blur-md flex items-start justify-between gap-3 ${
                            note.type === 'SUCCESS'
                              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                              : note.type === 'WARNING'
                              ? 'bg-amber-500/10 border-amber-500/30 text-amber-300'
                              : 'bg-blue-500/10 border-blue-500/30 text-blue-300'
                          }`}
                        >
                          <div className="flex items-start gap-2.5">
                            <Sparkles className="w-5 h-5 shrink-0 mt-0.5" />
                            <div>
                              <div className="font-bold text-sm">{note.title}</div>
                              <div className="text-xs opacity-90">{note.message}</div>
                            </div>
                          </div>
                          <button
                            onClick={() => {
                              setNotifications((prev) => prev.map((n) => (n.id === note.id ? { ...n, read: true } : n)));
                              soundFX.playClick();
                            }}
                            className="text-xs px-2.5 py-1 rounded bg-white/10 hover:bg-white/20 transition-all"
                          >
                            Dismiss
                          </button>
                        </div>
                      ))}
                  </div>
                )}

                {/* Active Submissions & Tracking */}
                <div className={`p-6 rounded-2xl border backdrop-blur-xl shadow-xl ${
                  theme === 'dark' ? 'bg-slate-900/60 border-white/10' : 'bg-white/80 border-slate-200'
                }`}>
                  <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                    <FileCheck2 className="w-5 h-5 text-blue-400" />
                    My Applications & Status Timeline
                  </h3>

                  {applications.filter((a) => a.studentId === activeStudent.id).length === 0 ? (
                    <div className="text-center py-8 text-slate-400 text-sm">
                      No applications submitted yet. Browse active scholarship schemes below and apply!
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {applications
                        .filter((a) => a.studentId === activeStudent.id)
                        .map((app) => (
                          <div
                            key={app.id}
                            className={`p-5 rounded-xl border transition-all ${
                              theme === 'dark' ? 'bg-slate-800/40 border-white/5' : 'bg-slate-50 border-slate-200'
                            }`}
                          >
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
                              <div>
                                <div className="flex items-center gap-2">
                                  <span className="font-mono text-xs font-bold text-blue-400">{app.applicationNo}</span>
                                  <span className="text-xs text-slate-400">· Applied: {app.appliedDate}</span>
                                </div>
                                <h4 className="font-bold text-base">{app.scholarshipTitle}</h4>
                              </div>

                              <div className="flex items-center gap-2">
                                <span className={`text-xs px-3 py-1 rounded-full font-bold border ${
                                  app.status === 'APPROVED'
                                    ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                                    : app.status === 'REJECTED'
                                    ? 'bg-red-500/10 text-red-400 border-red-500/30'
                                    : app.status === 'RESUBMISSION_REQUESTED'
                                    ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                                    : 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30'
                                }`}>
                                  {app.status}
                                </span>
                              </div>
                            </div>

                            {/* Officer Feedback Box */}
                            {app.officerRemarks && (
                              <div className={`p-3 rounded-lg text-xs mb-3 border ${
                                app.status === 'RESUBMISSION_REQUESTED'
                                  ? 'bg-amber-500/10 border-amber-500/20 text-amber-300'
                                  : theme === 'dark' ? 'bg-slate-900/60 border-white/5 text-slate-300' : 'bg-white border-slate-200 text-slate-700'
                              }`}>
                                <strong>Officer Review Remarks:</strong> {app.officerRemarks}
                              </div>
                            )}

                            {/* Documents list */}
                            <div className="flex flex-wrap items-center gap-2 text-xs">
                              <span className="text-slate-400">Attached Proofs:</span>
                              {app.documents.map((doc) => (
                                <span
                                  key={doc.id}
                                  className={`px-2.5 py-1 rounded-md border flex items-center gap-1.5 ${
                                    doc.verificationStatus === 'VERIFIED'
                                      ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                                      : doc.verificationStatus === 'REJECTED'
                                      ? 'bg-red-500/10 text-red-400 border-red-500/20'
                                      : 'bg-slate-500/10 text-slate-400 border-slate-500/20'
                                  }`}
                                >
                                  <FileText className="w-3.5 h-3.5" />
                                  <span>{doc.fileName}</span>
                                  <span className="text-[10px] opacity-75">({doc.verificationStatus})</span>
                                </span>
                              ))}
                            </div>

                            {app.status === 'RESUBMISSION_REQUESTED' && (
                              <div className="mt-3 pt-3 border-t border-white/10 flex justify-end">
                                <button
                                  onClick={() => {
                                    handleSimulateDocUpload('INCOME_CERTIFICATE');
                                    setApplications((prev) =>
                                      prev.map((a) =>
                                        a.id === app.id
                                          ? {
                                              ...a,
                                              status: 'UNDER_REVIEW',
                                              officerRemarks: 'Student resubmitted updated proof. Awaiting re-verification.'
                                            }
                                          : a
                                      )
                                    );
                                    soundFX.playSuccess();
                                    addAuditLog('STUDENT_RESUBMISSION', 'APPLICATION', app.id, 'Student uploaded replacement certificate');
                                  }}
                                  className="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-amber-500 text-black hover:bg-amber-400 transition-all flex items-center gap-1.5"
                                >
                                  <UploadCloud className="w-3.5 h-3.5" />
                                  Upload Attested Income Certificate & Resubmit
                                </button>
                              </div>
                            )}
                          </div>
                        ))}
                    </div>
                  )}
                </div>

                {/* Available Scholarship Schemes Catalog */}
                <div className={`p-6 rounded-2xl border backdrop-blur-xl shadow-xl ${
                  theme === 'dark' ? 'bg-slate-900/60 border-white/10' : 'bg-white/80 border-slate-200'
                }`}>
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-bold flex items-center gap-2">
                      <GraduationCap className="w-5 h-5 text-emerald-400" />
                      Active Scholarship Schemes Catalog
                    </h3>
                    <span className="text-xs text-slate-400">Automated Criteria Evaluation</span>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    {scholarships.map((sch) => {
                      const isGpaEligible = activeStudent.currentGpa >= sch.minGpa;
                      const isIncomeEligible = activeStudent.annualFamilyIncome <= sch.maxAnnualIncome;
                      const isEligible = isGpaEligible && isIncomeEligible;

                      return (
                        <div
                          key={sch.id}
                          className={`p-5 rounded-xl border flex flex-col justify-between transition-all ${
                            theme === 'dark' ? 'bg-slate-800/40 border-white/5 hover:border-blue-500/30' : 'bg-slate-50 border-slate-200 hover:border-blue-400'
                          }`}
                        >
                          <div>
                            <div className="flex items-center justify-between gap-2 mb-2">
                              <span className="font-mono text-xs text-blue-400">{sch.code}</span>
                              <span className={`text-[11px] px-2 py-0.5 rounded font-bold ${
                                isEligible ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                              }`}>
                                {isEligible ? 'Eligible' : 'Ineligible'}
                              </span>
                            </div>

                            <h4 className="font-bold text-base mb-1">{sch.title}</h4>
                            <p className="text-xs text-slate-400 mb-3">{sch.description}</p>

                            <div className="grid grid-cols-2 gap-2 text-xs p-3 rounded-lg bg-black/10 border border-white/5 mb-3">
                              <div>Grant: <strong className="text-emerald-400">INR {sch.amount.toLocaleString()}</strong></div>
                              <div>Slots: <strong>{sch.totalSlots} available</strong></div>
                              <div>Min GPA: <strong>{sch.minGpa.toFixed(2)}</strong></div>
                              <div>Max Income: <strong>INR {sch.maxAnnualIncome.toLocaleString()}</strong></div>
                            </div>

                            {!isEligible && (
                              <div className="text-[11px] text-amber-400/90 mb-3">
                                ⚠️ {!isGpaEligible && `GPA is below ${sch.minGpa.toFixed(2)}. `}
                                {!isIncomeEligible && `Income exceeds ceiling of INR ${sch.maxAnnualIncome.toLocaleString()}.`}
                              </div>
                            )}
                          </div>

                          <button
                            disabled={!isEligible}
                            onClick={() => handleStartApply(sch)}
                            className={`w-full py-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                              isEligible
                                ? 'bg-blue-600 hover:bg-blue-500 text-white shadow-md shadow-blue-600/30'
                                : 'bg-slate-800/40 text-slate-500 cursor-not-allowed border border-white/5'
                            }`}
                          >
                            <FileCheck2 className="w-3.5 h-3.5" />
                            {isEligible ? 'Apply with Profile Documents' : 'Criteria Not Satisfied'}
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            ) : currentUser.role === 'OFFICER' ? (
              /* --- VERIFICATION OFFICER WORKBENCH --- */
              <div className="space-y-6">
                
                {/* Stats Header */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <div className={`p-4 rounded-xl border backdrop-blur-xl ${
                    theme === 'dark' ? 'bg-slate-900/60 border-white/10' : 'bg-white/80 border-slate-200'
                  }`}>
                    <div className="text-xs text-slate-400">Queue Total</div>
                    <div className="text-2xl font-black">{applications.length}</div>
                    <div className="text-[10px] text-slate-500">All submissions</div>
                  </div>
                  <div className={`p-4 rounded-xl border backdrop-blur-xl ${
                    theme === 'dark' ? 'bg-slate-900/60 border-white/10' : 'bg-white/80 border-slate-200'
                  }`}>
                    <div className="text-xs text-cyan-400">Under Review</div>
                    <div className="text-2xl font-black text-cyan-400">{applications.filter((a) => a.status === 'UNDER_REVIEW' || a.status === 'SUBMITTED').length}</div>
                    <div className="text-[10px] text-slate-500">Awaiting clearance</div>
                  </div>
                  <div className={`p-4 rounded-xl border backdrop-blur-xl ${
                    theme === 'dark' ? 'bg-slate-900/60 border-white/10' : 'bg-white/80 border-slate-200'
                  }`}>
                    <div className="text-xs text-emerald-400">Approved</div>
                    <div className="text-2xl font-black text-emerald-400">{applications.filter((a) => a.status === 'APPROVED').length}</div>
                    <div className="text-[10px] text-slate-500">Passed verification</div>
                  </div>
                  <div className={`p-4 rounded-xl border backdrop-blur-xl ${
                    theme === 'dark' ? 'bg-slate-900/60 border-white/10' : 'bg-white/80 border-slate-200'
                  }`}>
                    <div className="text-xs text-amber-400">Resubmission</div>
                    <div className="text-2xl font-black text-amber-400">{applications.filter((a) => a.status === 'RESUBMISSION_REQUESTED').length}</div>
                    <div className="text-[10px] text-slate-500">Student action needed</div>
                  </div>
                </div>

                {/* Split Workbench: Left Queue, Right Dossier */}
                <div className="grid lg:grid-cols-12 gap-6">
                  
                  {/* Left Column: Filterable Applications Queue */}
                  <div className={`lg:col-span-5 p-5 rounded-2xl border backdrop-blur-xl flex flex-col shadow-xl ${
                    theme === 'dark' ? 'bg-slate-900/60 border-white/10' : 'bg-white/80 border-slate-200'
                  }`}>
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-bold text-base flex items-center gap-2">
                        <ShieldCheck className="w-5 h-5 text-cyan-400" />
                        Verification Queue
                      </h3>
                      <span className="text-xs font-semibold text-slate-400">
                        {filteredApps.length} Applicants
                      </span>
                    </div>

                    {/* Search & Status Filters */}
                    <div className="space-y-2 mb-4">
                      <div className="relative">
                        <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                        <input
                          type="text"
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          placeholder="Search applicant, roll no..."
                          className={`w-full pl-9 pr-3 py-1.5 rounded-lg border text-xs focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                            theme === 'dark' ? 'bg-slate-800/60 border-white/10 text-white' : 'bg-white border-slate-300 text-slate-900'
                          }`}
                        />
                      </div>

                      <div className="flex items-center gap-1 overflow-x-auto pb-1 text-[11px]">
                        {['ALL', 'UNDER_REVIEW', 'SUBMITTED', 'RESUBMISSION_REQUESTED', 'APPROVED', 'REJECTED'].map((st) => (
                          <button
                            key={st}
                            onClick={() => { setStatusFilter(st); soundFX.playTab(); }}
                            className={`px-2 py-1 rounded-md font-medium whitespace-nowrap transition-all ${
                              statusFilter === st
                                ? 'bg-blue-600 text-white'
                                : theme === 'dark' ? 'bg-slate-800/60 text-slate-400 hover:text-white' : 'bg-slate-100 text-slate-600 hover:text-slate-900'
                            }`}
                          >
                            {st.replace('_', ' ')}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Queue List */}
                    <div className="space-y-2.5 overflow-y-auto max-h-[580px] pr-1">
                      {filteredApps.length === 0 ? (
                        <div className="text-center py-10 text-xs text-slate-400">
                          No applications match active filter criteria.
                        </div>
                      ) : (
                        filteredApps.map((app) => (
                          <div
                            key={app.id}
                            onClick={() => { setSelectedAppId(app.id); soundFX.playClick(); }}
                            className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                              selectedAppId === app.id
                                ? 'bg-blue-600/15 border-blue-500 shadow-md shadow-blue-500/10'
                                : theme === 'dark' ? 'bg-slate-800/40 border-white/5 hover:border-slate-700' : 'bg-slate-50 border-slate-200 hover:border-slate-300'
                            }`}
                          >
                            <div className="flex items-center justify-between gap-1 mb-1">
                              <span className="font-mono text-[11px] font-bold text-blue-400">{app.applicationNo}</span>
                              <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                                app.fraudRiskLevel === 'HIGH'
                                  ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                                  : app.fraudRiskLevel === 'MEDIUM'
                                  ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                                  : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                              }`}>
                                {app.fraudRiskLevel} RISK
                              </span>
                            </div>

                            <div className="font-bold text-sm">{app.studentName}</div>
                            <div className="text-xs text-slate-400 truncate mb-2">{app.scholarshipTitle}</div>

                            <div className="flex items-center justify-between text-[11px] text-slate-400 pt-2 border-t border-white/5">
                              <span>Roll: {app.studentRollNo}</span>
                              <span className={`font-semibold ${
                                app.status === 'APPROVED' ? 'text-emerald-400' : app.status === 'REJECTED' ? 'text-red-400' : 'text-cyan-400'
                              }`}>
                                {app.status}
                              </span>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>

                  {/* Right Column: Detailed Applicant Dossier & Verification Controls */}
                  <div className={`lg:col-span-7 p-6 rounded-2xl border backdrop-blur-xl shadow-xl flex flex-col justify-between ${
                    theme === 'dark' ? 'bg-slate-900/60 border-white/10' : 'bg-white/80 border-slate-200'
                  }`}>
                    {selectedApp ? (
                      <div className="space-y-6">
                        
                        {/* Header Profile Bar */}
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-white/10">
                          <div>
                            <div className="text-xs font-mono text-blue-400 font-bold">{selectedApp.applicationNo}</div>
                            <h3 className="text-xl font-black">{selectedApp.studentName}</h3>
                            <div className="text-xs text-slate-400">Roll No: {selectedApp.studentRollNo} · Applied {selectedApp.appliedDate}</div>
                          </div>

                          <div className="text-right">
                            <div className="text-[11px] uppercase font-bold text-slate-400">Requested Grant</div>
                            <div className="text-xl font-black text-emerald-400">INR {selectedApp.scholarshipAmount.toLocaleString()}</div>
                            <div className="text-xs font-medium text-slate-400">{selectedApp.scholarshipTitle}</div>
                          </div>
                        </div>

                        {/* Explainable Fraud Risk Analysis Card */}
                        <div className={`p-4 rounded-xl border ${
                          selectedApp.fraudRiskLevel === 'HIGH'
                            ? 'bg-red-500/10 border-red-500/30'
                            : selectedApp.fraudRiskLevel === 'MEDIUM'
                            ? 'bg-amber-500/10 border-amber-500/30'
                            : 'bg-emerald-500/10 border-emerald-500/30'
                        }`}>
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <AlertTriangle className={`w-4 h-4 ${
                                selectedApp.fraudRiskLevel === 'HIGH' ? 'text-red-400' : selectedApp.fraudRiskLevel === 'MEDIUM' ? 'text-amber-400' : 'text-emerald-400'
                              }`} />
                              <span className="font-bold text-xs uppercase tracking-wider">
                                Explainable Fraud-Risk Assistance Score: {selectedApp.fraudRiskScore.toFixed(1)} / 100 ({selectedApp.fraudRiskLevel})
                              </span>
                            </div>

                            {selectedApp.fraudRiskLevel !== 'LOW' && (
                              <button
                                onClick={() => { setDismissFlagModalOpen(true); soundFX.playClick(); }}
                                className="text-[11px] px-2.5 py-1 rounded bg-white/10 hover:bg-white/20 font-semibold transition-all"
                              >
                                Dismiss Flag with Note
                              </button>
                            )}
                          </div>

                          <div className="space-y-1 text-xs">
                            {selectedApp.flaggedReasons.map((reason, idx) => (
                              <div key={idx} className="flex items-start gap-1.5 opacity-90">
                                <span>•</span>
                                <span>{reason}</span>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Documents Verification Workbench */}
                        <div>
                          <div className="flex items-center justify-between mb-3">
                            <h4 className="font-bold text-sm flex items-center gap-2">
                              <FileText className="w-4 h-4 text-blue-400" />
                              Uploaded Proofs & Verification Status
                            </h4>
                            <span className="text-xs text-slate-400">Magic bytes & SHA-256 Checksums</span>
                          </div>

                          <div className="space-y-3">
                            {selectedApp.documents.map((doc) => (
                              <div
                                key={doc.id}
                                className={`p-3.5 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                                  doc.verificationStatus === 'VERIFIED'
                                    ? 'bg-emerald-500/5 border-emerald-500/20'
                                    : doc.verificationStatus === 'REJECTED'
                                    ? 'bg-red-500/5 border-red-500/20'
                                    : theme === 'dark' ? 'bg-slate-800/40 border-white/5' : 'bg-slate-50 border-slate-200'
                                }`}
                              >
                                <div>
                                  <div className="flex items-center gap-2">
                                    <span className="font-bold text-xs">{doc.docType.replace('_', ' ')}</span>
                                    <span className="text-[10px] text-slate-400 font-mono">({doc.fileName} · {doc.fileSizeKb} KB)</span>
                                  </div>
                                  <div className="text-[11px] font-mono text-slate-500">Hash: {doc.fileHash}</div>
                                  {doc.rejectionReason && (
                                    <div className="text-[11px] text-red-400 mt-1">⚠️ Reason: {doc.rejectionReason}</div>
                                  )}
                                </div>

                                <div className="flex items-center gap-2">
                                  <button
                                    onClick={() => handleToggleDocStatus(selectedApp.id, doc.id, 'VERIFIED')}
                                    className={`px-2.5 py-1 rounded text-xs font-semibold flex items-center gap-1 transition-all ${
                                      doc.verificationStatus === 'VERIFIED'
                                        ? 'bg-emerald-600 text-white'
                                        : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/20'
                                    }`}
                                  >
                                    <Check className="w-3.5 h-3.5" />
                                    Verify
                                  </button>
                                  <button
                                    onClick={() => handleToggleDocStatus(selectedApp.id, doc.id, 'REJECTED')}
                                    className={`px-2.5 py-1 rounded text-xs font-semibold flex items-center gap-1 transition-all ${
                                      doc.verificationStatus === 'REJECTED'
                                        ? 'bg-red-600 text-white'
                                        : 'bg-red-500/10 text-red-400 border border-red-500/30 hover:bg-red-500/20'
                                    }`}
                                  >
                                    <X className="w-3.5 h-3.5" />
                                    Reject
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Officer Final Decision Actions */}
                        <div className="pt-4 border-t border-white/10 space-y-3">
                          <label className="block text-xs font-semibold text-slate-400">
                            Officer Review Remarks / Verification Notes (Recorded in Immutable Audit Trail)
                          </label>
                          <textarea
                            rows={2}
                            value={officerRemarksInput}
                            onChange={(e) => setOfficerRemarksInput(e.target.value)}
                            placeholder="Enter decision rationale, missing proof notes, or clearance justification..."
                            className={`w-full p-2.5 rounded-lg border text-xs focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                              theme === 'dark' ? 'bg-slate-800/60 border-white/10 text-white' : 'bg-white border-slate-300 text-slate-900'
                            }`}
                          />

                          <div className="flex flex-wrap items-center justify-end gap-2.5 pt-1">
                            <button
                              onClick={() => handleRequestResubmitApplication(selectedApp.id)}
                              className="px-3.5 py-2 rounded-lg text-xs font-semibold bg-amber-500/15 border border-amber-500/30 text-amber-300 hover:bg-amber-500/25 transition-all flex items-center gap-1.5"
                            >
                              <RefreshCw className="w-3.5 h-3.5" />
                              Request Resubmission
                            </button>
                            <button
                              onClick={() => handleRejectApplication(selectedApp.id)}
                              className="px-3.5 py-2 rounded-lg text-xs font-semibold bg-red-500/15 border border-red-500/30 text-red-400 hover:bg-red-500/25 transition-all flex items-center gap-1.5"
                            >
                              <XCircle className="w-3.5 h-3.5" />
                              Reject Grant
                            </button>
                            <button
                              onClick={() => handleApproveApplication(selectedApp.id)}
                              className="px-4 py-2 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-600/30 transition-all flex items-center gap-1.5"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              Approve Scholarship
                            </button>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center py-20 text-slate-400 text-sm">
                        Select an applicant from the queue to inspect dossier.
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              /* --- ADMINISTRATOR CONTROL CENTER --- */
              <div className="space-y-6">
                
                {/* Admin Overview Cards */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <div className={`p-4 rounded-xl border backdrop-blur-xl ${
                    theme === 'dark' ? 'bg-slate-900/60 border-white/10' : 'bg-white/80 border-slate-200'
                  }`}>
                    <div className="text-xs text-blue-400">Total Applications</div>
                    <div className="text-2xl font-black">{applications.length}</div>
                    <div className="text-[10px] text-slate-500">Lifetime submissions</div>
                  </div>
                  <div className={`p-4 rounded-xl border backdrop-blur-xl ${
                    theme === 'dark' ? 'bg-slate-900/60 border-white/10' : 'bg-white/80 border-slate-200'
                  }`}>
                    <div className="text-xs text-emerald-400">Allocated Funds</div>
                    <div className="text-2xl font-black text-emerald-400">
                      INR {applications.filter((a) => a.status === 'APPROVED').reduce((sum, a) => sum + a.scholarshipAmount, 0).toLocaleString()}
                    </div>
                    <div className="text-[10px] text-slate-500">Approved for disbursement</div>
                  </div>
                  <div className={`p-4 rounded-xl border backdrop-blur-xl ${
                    theme === 'dark' ? 'bg-slate-900/60 border-white/10' : 'bg-white/80 border-slate-200'
                  }`}>
                    <div className="text-xs text-amber-400">Active Schemes</div>
                    <div className="text-2xl font-black text-amber-400">{scholarships.filter((s) => s.status === 'ACTIVE').length}</div>
                    <div className="text-[10px] text-slate-500">Published schemes</div>
                  </div>
                  <div className={`p-4 rounded-xl border backdrop-blur-xl ${
                    theme === 'dark' ? 'bg-slate-900/60 border-white/10' : 'bg-white/80 border-slate-200'
                  }`}>
                    <div className="text-xs text-cyan-400">System Users</div>
                    <div className="text-2xl font-black text-cyan-400">{users.length}</div>
                    <div className="text-[10px] text-slate-500">Governance accounts</div>
                  </div>
                </div>

                {/* Schemes Management Section */}
                <div className={`p-6 rounded-2xl border backdrop-blur-xl shadow-xl ${
                  theme === 'dark' ? 'bg-slate-900/60 border-white/10' : 'bg-white/80 border-slate-200'
                }`}>
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="text-lg font-bold">Scholarship Scheme Governance</h3>
                      <p className="text-xs text-slate-400">Configure award amounts, quotas, minimum GPA, and income thresholds</p>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={handleExportCSV}
                        className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600/20 border border-emerald-500/30 text-emerald-300 hover:bg-emerald-600/30 transition-all flex items-center gap-1.5"
                      >
                        <FileSpreadsheet className="w-3.5 h-3.5" />
                        Export Full CSV Report
                      </button>
                      <button
                        onClick={() => { setCreateSchemeModalOpen(true); soundFX.playClick(); }}
                        className="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-blue-600 hover:bg-blue-500 text-white shadow-md transition-all flex items-center gap-1.5"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        New Scheme
                      </button>
                    </div>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-xs text-left">
                      <thead className={`border-b ${theme === 'dark' ? 'border-white/10 text-slate-400' : 'border-slate-200 text-slate-600'}`}>
                        <tr>
                          <th className="py-2.5 px-3">Code</th>
                          <th className="py-2.5 px-3">Title</th>
                          <th className="py-2.5 px-3">Grant Amount</th>
                          <th className="py-2.5 px-3">Min GPA</th>
                          <th className="py-2.5 px-3">Income Ceiling</th>
                          <th className="py-2.5 px-3">Slots</th>
                          <th className="py-2.5 px-3">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5">
                        {scholarships.map((sch) => (
                          <tr key={sch.id} className={theme === 'dark' ? 'hover:bg-white/5' : 'hover:bg-slate-100'}>
                            <td className="py-3 px-3 font-mono font-bold text-blue-400">{sch.code}</td>
                            <td className="py-3 px-3 font-bold">{sch.title}</td>
                            <td className="py-3 px-3 text-emerald-400 font-bold">INR {sch.amount.toLocaleString()}</td>
                            <td className="py-3 px-3">{sch.minGpa.toFixed(2)}</td>
                            <td className="py-3 px-3">INR {sch.maxAnnualIncome.toLocaleString()}</td>
                            <td className="py-3 px-3">{sch.totalSlots}</td>
                            <td className="py-3 px-3">
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                                {sch.status}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* User Governance Table */}
                <div className={`p-6 rounded-2xl border backdrop-blur-xl shadow-xl ${
                  theme === 'dark' ? 'bg-slate-900/60 border-white/10' : 'bg-white/80 border-slate-200'
                }`}>
                  <h3 className="text-lg font-bold mb-4">User Account Security & Governance</h3>

                  <div className="overflow-x-auto">
                    <table className="w-full text-xs text-left">
                      <thead className={`border-b ${theme === 'dark' ? 'border-white/10 text-slate-400' : 'border-slate-200 text-slate-600'}`}>
                        <tr>
                          <th className="py-2.5 px-3">ID</th>
                          <th className="py-2.5 px-3">Username</th>
                          <th className="py-2.5 px-3">Full Name</th>
                          <th className="py-2.5 px-3">Role</th>
                          <th className="py-2.5 px-3">Status</th>
                          <th className="py-2.5 px-3 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5">
                        {users.map((u) => (
                          <tr key={u.id} className={theme === 'dark' ? 'hover:bg-white/5' : 'hover:bg-slate-100'}>
                            <td className="py-2.5 px-3 font-mono text-slate-400">#{u.id}</td>
                            <td className="py-2.5 px-3 font-bold">{u.username}</td>
                            <td className="py-2.5 px-3">{u.fullName}</td>
                            <td className="py-2.5 px-3">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                u.role === 'ADMIN'
                                  ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                                  : u.role === 'OFFICER'
                                  ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20'
                                  : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                              }`}>
                                {u.role}
                              </span>
                            </td>
                            <td className="py-2.5 px-3">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                u.status === 'ACTIVE'
                                  ? 'bg-emerald-500/10 text-emerald-400'
                                  : 'bg-red-500/10 text-red-400'
                              }`}>
                                {u.status}
                              </span>
                            </td>
                            <td className="py-2.5 px-3 text-right">
                              {u.username !== 'admin' && (
                                <button
                                  onClick={() => handleToggleUserStatus(u.id)}
                                  className={`px-2.5 py-1 rounded text-[11px] font-semibold border transition-all ${
                                    u.status === 'ACTIVE'
                                      ? 'text-red-400 border-red-500/20 hover:bg-red-500/10'
                                      : 'text-emerald-400 border-emerald-500/20 hover:bg-emerald-500/10'
                                  }`}
                                >
                                  {u.status === 'ACTIVE' ? 'Suspend' : 'Activate'}
                                </button>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* --- VIEW 2: AUDIT LOG --- */}
        {activeTab === 'audit' && (
          <div className={`p-6 rounded-2xl border backdrop-blur-xl shadow-xl space-y-4 ${
            theme === 'dark' ? 'bg-slate-900/60 border-white/10' : 'bg-white/80 border-slate-200'
          }`}>
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-bold flex items-center gap-2">
                  <Clock className="w-5 h-5 text-blue-400" />
                  Immutable Security Audit Trail
                </h3>
                <p className="text-xs text-slate-400">
                  Real-time tamper-evident log capturing status transitions, verifications, and auth milestones
                </p>
              </div>

              <span className="text-xs font-mono text-slate-400">{auditLogs.length} Events Logged</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className={`border-b ${theme === 'dark' ? 'border-white/10 text-slate-400' : 'border-slate-200 text-slate-600'}`}>
                  <tr>
                    <th className="py-3 px-3">Timestamp</th>
                    <th className="py-3 px-3">User / Actor</th>
                    <th className="py-3 px-3">Action</th>
                    <th className="py-3 px-3">Target Entity</th>
                    <th className="py-3 px-3">Details & Rationale</th>
                    <th className="py-3 px-3">Client IP</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 font-mono">
                  {auditLogs.map((log) => (
                    <tr key={log.id} className={theme === 'dark' ? 'hover:bg-white/5' : 'hover:bg-slate-100'}>
                      <td className="py-3 px-3 text-slate-400 whitespace-nowrap">{log.timestamp}</td>
                      <td className="py-3 px-3 font-sans font-semibold">{log.user}</td>
                      <td className="py-3 px-3">
                        <span className="px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20 text-[10px]">
                          {log.action}
                        </span>
                      </td>
                      <td className="py-3 px-3">{log.entityType} #{log.entityId}</td>
                      <td className="py-3 px-3 font-sans max-w-xs truncate">{log.details}</td>
                      <td className="py-3 px-3 text-slate-400">{log.ipAddress}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* --- VIEW 3: MYSQL 8 SCHEMA --- */}
        {activeTab === 'schema' && (
          <div className={`p-6 rounded-2xl border backdrop-blur-xl shadow-xl space-y-4 ${
            theme === 'dark' ? 'bg-slate-900/60 border-white/10' : 'bg-white/80 border-slate-200'
          }`}>
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-bold flex items-center gap-2">
                  <Database className="w-5 h-5 text-emerald-400" />
                  MySQL 8 Relational Schema (`schema.sql`)
                </h3>
                <p className="text-xs text-slate-400">
                  InnoDB engine with foreign keys, unique constraints, and indexes on document SHA-256 hashes
                </p>
              </div>

              <button
                onClick={() => {
                  navigator.clipboard.writeText(`CREATE DATABASE IF NOT EXISTS scholarship_db; ...`);
                  setCopiedCode(true);
                  soundFX.playSuccess();
                  setTimeout(() => setCopiedCode(false), 2000);
                }}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600/20 border border-emerald-500/30 text-emerald-300 hover:bg-emerald-600/30 transition-all flex items-center gap-1.5"
              >
                {copiedCode ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedCode ? 'Copied!' : 'Copy SQL'}
              </button>
            </div>

            <div className="p-4 rounded-xl bg-black/40 border border-white/10 font-mono text-xs text-slate-300 overflow-x-auto max-h-[500px]">
              <pre>{`-- =============================================================================
-- MySQL 8.0+ Relational Schema (InnoDB)
-- =============================================================================

CREATE DATABASE IF NOT EXISTS scholarship_db 
CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE scholarship_db;

-- Users (STUDENT, OFFICER, ADMIN) with PBKDF2WithHmacSHA256
CREATE TABLE IF NOT EXISTS users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(128) NOT NULL,
    salt VARCHAR(64) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    role ENUM('STUDENT', 'OFFICER', 'ADMIN') NOT NULL,
    status ENUM('ACTIVE', 'SUSPENDED') DEFAULT 'ACTIVE',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Students Profile
CREATE TABLE IF NOT EXISTS students (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL UNIQUE,
    roll_number VARCHAR(30) NOT NULL UNIQUE,
    department VARCHAR(100) NOT NULL,
    course VARCHAR(50) NOT NULL,
    year_of_study INT NOT NULL,
    current_gpa DECIMAL(3,2) NOT NULL,
    annual_family_income DECIMAL(12,2) NOT NULL,
    category ENUM('GENERAL', 'OBC', 'SC', 'ST', 'EWS') NOT NULL,
    bank_account_no VARCHAR(30) NOT NULL,
    ifsc_code VARCHAR(15) NOT NULL,
    bank_name VARCHAR(100) NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Scholarships Catalog
CREATE TABLE IF NOT EXISTS scholarships (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(30) NOT NULL UNIQUE,
    title VARCHAR(150) NOT NULL,
    description TEXT,
    sponsor VARCHAR(100) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    min_gpa DECIMAL(3,2) NOT NULL DEFAULT 0.00,
    max_annual_income DECIMAL(12,2) NOT NULL,
    eligible_categories VARCHAR(100) DEFAULT 'ALL',
    deadline DATE NOT NULL,
    total_slots INT NOT NULL,
    status ENUM('ACTIVE', 'CLOSED') DEFAULT 'ACTIVE'
) ENGINE=InnoDB;

-- Applications (DRAFT, SUBMITTED, UNDER_REVIEW, APPROVED, REJECTED, RESUBMISSION_REQUESTED)
CREATE TABLE IF NOT EXISTS applications (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    application_no VARCHAR(30) NOT NULL UNIQUE,
    student_id BIGINT NOT NULL,
    scholarship_id BIGINT NOT NULL,
    status ENUM('DRAFT', 'SUBMITTED', 'UNDER_REVIEW', 'APPROVED', 'REJECTED', 'RESUBMISSION_REQUESTED') NOT NULL,
    eligibility_score DECIMAL(5,2) DEFAULT 0.00,
    fraud_risk_score DECIMAL(5,2) DEFAULT 0.00,
    fraud_risk_level ENUM('LOW', 'MEDIUM', 'HIGH') DEFAULT 'LOW',
    officer_remarks TEXT,
    verified_by VARCHAR(100),
    applied_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (scholarship_id) REFERENCES scholarships(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- Documents Vault with SHA-256 Checksums
CREATE TABLE IF NOT EXISTS documents (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    application_id BIGINT NOT NULL,
    doc_type ENUM('INCOME_CERTIFICATE', 'MARKSHEET', 'IDENTITY_PROOF', 'BANK_PASSBOOK', 'CASTE_CERTIFICATE') NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    stored_file_name VARCHAR(255) NOT NULL,
    file_size_kb INT NOT NULL,
    file_hash VARCHAR(64) NOT NULL,
    verification_status ENUM('PENDING', 'VERIFIED', 'REJECTED') DEFAULT 'PENDING',
    INDEX idx_doc_hash (file_hash),
    FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE
) ENGINE=InnoDB;`}</pre>
            </div>
          </div>
        )}

        {/* --- VIEW 4: DOWNLOAD & ECLIPSE DEPLOYMENT --- */}
        {activeTab === 'download' && (
          <div className="space-y-6">
            <div className={`p-8 rounded-2xl border backdrop-blur-xl shadow-2xl ${
              theme === 'dark' ? 'bg-slate-900/60 border-white/10' : 'bg-white/80 border-slate-200'
            }`}>
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                      Verified Eclipse & Tomcat 9 Package
                    </span>
                    <span className="text-xs text-slate-400">Java 11 LTS · Maven WAR</span>
                  </div>
                  <h2 className="text-3xl font-black mb-2">
                    Deployable Eclipse Project ZIP
                  </h2>
                  <p className={`text-sm ${theme === 'dark' ? 'text-slate-300' : 'text-slate-600'} max-w-2xl leading-relaxed`}>
                    Complete Java EE web application with all servlets, JSP pages, Web Audio sound effects, glassmorphic styles, MySQL 8 schema, seed data, and unit tests ready for one-click import into Eclipse IDE.
                  </p>
                </div>

                <div className="flex flex-col gap-2">
                  <a
                    href="/scholarship-eclipse-project.zip"
                    download="scholarship-eclipse-project.zip"
                    onClick={() => soundFX.playSuccess()}
                    className="px-6 py-3.5 rounded-xl font-bold text-sm bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-xl shadow-emerald-600/30 transition-all flex items-center justify-center gap-2.5 text-center"
                  >
                    <Download className="w-5 h-5" />
                    Download Eclipse Project ZIP
                  </a>
                  <div className="text-[11px] text-center text-slate-400">
                    69 files · 108 KB · Ready for Tomcat 9
                  </div>
                </div>
              </div>

              {/* Step-by-Step Instructions */}
              <div className="grid md:grid-cols-3 gap-6 pt-6 border-t border-white/10">
                <div className={`p-4 rounded-xl border ${theme === 'dark' ? 'bg-slate-800/40 border-white/5' : 'bg-slate-50 border-slate-200'}`}>
                  <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 font-bold flex items-center justify-center mb-3">1</div>
                  <h4 className="font-bold text-sm mb-1">Initialize MySQL 8</h4>
                  <p className="text-xs text-slate-400 mb-3">
                    Start MySQL 8.0 on port 3306 and execute schema & seed files:
                  </p>
                  <pre className="p-2 rounded bg-black/30 font-mono text-[10px] text-slate-300">
                    mysql -u root -p &lt; schema.sql{'\n'}mysql -u root -p &lt; seed.sql
                  </pre>
                </div>

                <div className={`p-4 rounded-xl border ${theme === 'dark' ? 'bg-slate-800/40 border-white/5' : 'bg-slate-50 border-slate-200'}`}>
                  <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 font-bold flex items-center justify-center mb-3">2</div>
                  <h4 className="font-bold text-sm mb-1">Import into Eclipse IDE</h4>
                  <p className="text-xs text-slate-400 mb-2">
                    Open Eclipse for Enterprise Java:
                  </p>
                  <ol className="text-xs text-slate-400 space-y-1 list-decimal list-inside">
                    <li>File &rarr; Import...</li>
                    <li>Maven &rarr; Existing Maven Projects</li>
                    <li>Select unzipped <code className="text-cyan-400">scholarship/</code> folder</li>
                    <li>Click Finish</li>
                  </ol>
                </div>

                <div className={`p-4 rounded-xl border ${theme === 'dark' ? 'bg-slate-800/40 border-white/5' : 'bg-slate-50 border-slate-200'}`}>
                  <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 font-bold flex items-center justify-center mb-3">3</div>
                  <h4 className="font-bold text-sm mb-1">Run on Apache Tomcat 9</h4>
                  <p className="text-xs text-slate-400 mb-2">
                    Deploy onto Tomcat Server v9.0:
                  </p>
                  <ol className="text-xs text-slate-400 space-y-1 list-decimal list-inside">
                    <li>Servers view &rarr; New &rarr; Server</li>
                    <li>Select Apache Tomcat v9.0 (Java 11)</li>
                    <li>Add <code className="text-cyan-400">scholarship-verification-system</code></li>
                    <li>Start server &rarr; visit <code className="text-blue-400">http://localhost:8080/scholarship-system</code></li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
        )}

      </main>

      {/* =========================================================================
          MODAL: Multi-Step Scholarship Application Wizard
          ========================================================================= */}
      {applyModalOpen && selectedScholarshipForApply && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-md flex items-center justify-center p-4">
          <div className={`max-w-xl w-full rounded-2xl border backdrop-blur-2xl shadow-2xl p-6 ${
            theme === 'dark' ? 'bg-slate-900 border-white/10 text-white' : 'bg-white border-slate-200 text-slate-900'
          }`}>
            <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-4">
              <div>
                <span className="text-[11px] font-mono text-blue-400 font-bold">{selectedScholarshipForApply.code}</span>
                <h3 className="font-bold text-lg">{selectedScholarshipForApply.title}</h3>
              </div>
              <button
                onClick={() => { setApplyModalOpen(false); soundFX.playClick(); }}
                className="p-1 rounded-lg hover:bg-white/10 text-slate-400"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Stepper Header */}
            <div className="flex items-center justify-between mb-6 px-2">
              <div className={`text-xs font-semibold ${applyStep >= 1 ? 'text-blue-400' : 'text-slate-500'}`}>
                1. Academic Profile
              </div>
              <div className={`text-xs font-semibold ${applyStep >= 2 ? 'text-blue-400' : 'text-slate-500'}`}>
                2. Upload Proofs
              </div>
              <div className={`text-xs font-semibold ${applyStep >= 3 ? 'text-blue-400' : 'text-slate-500'}`}>
                3. Final Review
              </div>
            </div>

            {/* Step 1: Profile Confirmation */}
            {applyStep === 1 && (
              <div className="space-y-4">
                <p className="text-xs text-slate-400">
                  Please verify that your registered academic profile details match your official university records before proceeding.
                </p>

                <div className={`p-4 rounded-xl border text-xs space-y-2 ${theme === 'dark' ? 'bg-slate-800/50 border-white/5' : 'bg-slate-50 border-slate-200'}`}>
                  <div><strong>Student Name:</strong> {activeStudent.name}</div>
                  <div><strong>Roll Number:</strong> {activeStudent.rollNumber}</div>
                  <div><strong>Course & Dept:</strong> {activeStudent.course} ({activeStudent.department})</div>
                  <div><strong>Current GPA:</strong> {activeStudent.currentGpa.toFixed(2)} / 4.0</div>
                  <div><strong>Annual Family Income:</strong> INR {activeStudent.annualFamilyIncome.toLocaleString()}</div>
                  <div><strong>Category:</strong> {activeStudent.category}</div>
                </div>

                <div className="flex justify-end gap-2 pt-4">
                  <button
                    onClick={() => { setApplyStep(2); soundFX.playClick(); }}
                    className="px-4 py-2 rounded-lg text-xs font-semibold bg-blue-600 hover:bg-blue-500 text-white"
                  >
                    Confirm & Proceed to Document Uploads &rarr;
                  </button>
                </div>
              </div>
            )}

            {/* Step 2: Document Upload Simulation */}
            {applyStep === 2 && (
              <div className="space-y-4">
                <p className="text-xs text-slate-400">
                  Attach certified copies for each required document. Allowed formats: PDF, JPEG, PNG (Max 5MB each). Magic bytes and SHA-256 hashes will be validated.
                </p>

                <div className="space-y-2.5">
                  {selectedScholarshipForApply.requiredDocs.map((docType) => {
                    const uploaded = uploadedFilesMap[docType];
                    return (
                      <div
                        key={docType}
                        className={`p-3 rounded-xl border flex items-center justify-between text-xs ${
                          uploaded ? 'bg-emerald-500/10 border-emerald-500/20' : theme === 'dark' ? 'bg-slate-800/40 border-white/5' : 'bg-slate-50 border-slate-200'
                        }`}
                      >
                        <div>
                          <div className="font-bold">{docType.replace('_', ' ')}</div>
                          {uploaded ? (
                            <div className="text-[11px] text-emerald-400 font-mono">
                              ✓ {uploaded.name} ({uploaded.sizeKb} KB)
                            </div>
                          ) : (
                            <div className="text-[11px] text-slate-500">Not uploaded yet</div>
                          )}
                        </div>

                        <button
                          onClick={() => handleSimulateDocUpload(docType)}
                          className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-blue-600 hover:bg-blue-500 text-white transition-all flex items-center gap-1"
                        >
                          <UploadCloud className="w-3.5 h-3.5" />
                          {uploaded ? 'Replace' : 'Upload'}
                        </button>
                      </div>
                    );
                  })}
                </div>

                <div className="flex justify-between gap-2 pt-4">
                  <button
                    onClick={() => { setApplyStep(1); soundFX.playClick(); }}
                    className="px-3.5 py-2 rounded-lg text-xs font-semibold bg-white/10 hover:bg-white/20 text-slate-300"
                  >
                    &larr; Back
                  </button>
                  <button
                    onClick={() => { setApplyStep(3); soundFX.playClick(); }}
                    className="px-4 py-2 rounded-lg text-xs font-semibold bg-blue-600 hover:bg-blue-500 text-white"
                  >
                    Proceed to Review &rarr;
                  </button>
                </div>
              </div>
            )}

            {/* Step 3: Final Review & Submit */}
            {applyStep === 3 && (
              <div className="space-y-4">
                <div className="p-4 rounded-xl bg-blue-500/10 border border-blue-500/20 text-xs text-blue-300">
                  <strong>Declaration:</strong> I hereby declare that all academic credentials and uploaded income proofs are genuine and subject to university verification.
                </div>

                <div className="text-xs space-y-1.5 text-slate-400">
                  <div>• Grant Amount: <strong>INR {selectedScholarshipForApply.amount.toLocaleString()}</strong></div>
                  <div>• Applicant: <strong>{activeStudent.name} ({activeStudent.rollNumber})</strong></div>
                  <div>• Total Documents Attached: <strong>{selectedScholarshipForApply.requiredDocs.length} files</strong></div>
                </div>

                <div className="flex justify-between gap-2 pt-4">
                  <button
                    onClick={() => { setApplyStep(2); soundFX.playClick(); }}
                    className="px-3.5 py-2 rounded-lg text-xs font-semibold bg-white/10 hover:bg-white/20 text-slate-300"
                  >
                    &larr; Back
                  </button>
                  <button
                    onClick={handleFinalizeApplication}
                    className="px-5 py-2 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-600/30 flex items-center gap-1.5"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    Submit Application to Officer Queue
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL: Dismiss Fraud Flag Justification
          ========================================================================= */}
      {dismissFlagModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-md flex items-center justify-center p-4">
          <div className={`max-w-md w-full rounded-2xl border backdrop-blur-2xl shadow-2xl p-6 ${
            theme === 'dark' ? 'bg-slate-900 border-white/10 text-white' : 'bg-white border-slate-200 text-slate-900'
          }`}>
            <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
              <h3 className="font-bold text-base flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-amber-400" />
                Dismiss Fraud Risk Flag
              </h3>
              <button
                onClick={() => setDismissFlagModalOpen(false)}
                className="p-1 rounded-lg hover:bg-white/10 text-slate-400"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-400 mb-4">
              Please enter an official justification for dismissing this flagged anomaly. This note is permanently recorded in the immutable audit trail with your timestamp and credentials.
            </p>

            <div className="space-y-3">
              <textarea
                rows={3}
                value={dismissFlagReason}
                onChange={(e) => setDismissFlagReason(e.target.value)}
                placeholder="e.g. Cross-verified with State Revenue portal; certificate authentic and stamp verified manually..."
                className={`w-full p-3 rounded-lg border text-xs focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                  theme === 'dark' ? 'bg-slate-800/60 border-white/10 text-white' : 'bg-white border-slate-300 text-slate-900'
                }`}
              />

              <div className="flex justify-end gap-2">
                <button
                  onClick={() => setDismissFlagModalOpen(false)}
                  className="px-3.5 py-2 rounded-lg text-xs font-semibold bg-white/10 hover:bg-white/20 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  onClick={handleDismissFlag}
                  className="px-4 py-2 rounded-lg text-xs font-semibold bg-amber-500 text-black hover:bg-amber-400 font-bold"
                >
                  Confirm Flag Dismissal
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL: Create New Scholarship Scheme (Admin)
          ========================================================================= */}
      {createSchemeModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-md flex items-center justify-center p-4">
          <div className={`max-w-lg w-full rounded-2xl border backdrop-blur-2xl shadow-2xl p-6 ${
            theme === 'dark' ? 'bg-slate-900 border-white/10 text-white' : 'bg-white border-slate-200 text-slate-900'
          }`}>
            <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
              <h3 className="font-bold text-base flex items-center gap-2">
                <Plus className="w-5 h-5 text-blue-400" />
                Create New Scholarship Scheme
              </h3>
              <button
                onClick={() => setCreateSchemeModalOpen(false)}
                className="p-1 rounded-lg hover:bg-white/10 text-slate-400"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateScholarship} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">Scheme Title *</label>
                <input
                  type="text"
                  value={newSchemeTitle}
                  onChange={(e) => setNewSchemeTitle(e.target.value)}
                  required
                  placeholder="National AI Innovation Fellowship"
                  className={`w-full px-3 py-2 rounded-lg border text-xs ${theme === 'dark' ? 'bg-slate-800 text-white border-white/10' : 'bg-white text-slate-900 border-slate-300'}`}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Scheme Code *</label>
                  <input
                    type="text"
                    value={newSchemeCode}
                    onChange={(e) => setNewSchemeCode(e.target.value)}
                    required
                    placeholder="SCH-AI-2026"
                    className={`w-full px-3 py-2 rounded-lg border text-xs ${theme === 'dark' ? 'bg-slate-800 text-white border-white/10' : 'bg-white text-slate-900 border-slate-300'}`}
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Grant Amount (INR) *</label>
                  <input
                    type="number"
                    step="5000"
                    value={newSchemeAmount}
                    onChange={(e) => setNewSchemeAmount(e.target.value)}
                    required
                    className={`w-full px-3 py-2 rounded-lg border text-xs ${theme === 'dark' ? 'bg-slate-800 text-white border-white/10' : 'bg-white text-slate-900 border-slate-300'}`}
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Min GPA *</label>
                  <input
                    type="number"
                    step="0.05"
                    min="0"
                    max="4.0"
                    value={newSchemeMinGpa}
                    onChange={(e) => setNewSchemeMinGpa(e.target.value)}
                    required
                    className={`w-full px-3 py-2 rounded-lg border text-xs ${theme === 'dark' ? 'bg-slate-800 text-white border-white/10' : 'bg-white text-slate-900 border-slate-300'}`}
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Max Income *</label>
                  <input
                    type="number"
                    step="10000"
                    value={newSchemeMaxIncome}
                    onChange={(e) => setNewSchemeMaxIncome(e.target.value)}
                    required
                    className={`w-full px-3 py-2 rounded-lg border text-xs ${theme === 'dark' ? 'bg-slate-800 text-white border-white/10' : 'bg-white text-slate-900 border-slate-300'}`}
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Slots *</label>
                  <input
                    type="number"
                    value={newSchemeSlots}
                    onChange={(e) => setNewSchemeSlots(e.target.value)}
                    required
                    className={`w-full px-3 py-2 rounded-lg border text-xs ${theme === 'dark' ? 'bg-slate-800 text-white border-white/10' : 'bg-white text-slate-900 border-slate-300'}`}
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setCreateSchemeModalOpen(false)}
                  className="px-3.5 py-2 rounded-lg text-xs font-semibold bg-white/10 hover:bg-white/20 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg text-xs font-semibold bg-blue-600 hover:bg-blue-500 text-white"
                >
                  Publish Scholarship Scheme
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =========================================================================
          Footer
          ========================================================================= */}
      <footer className={`mt-12 py-6 border-t text-xs text-center backdrop-blur-md ${
        theme === 'dark' ? 'bg-slate-950/40 border-white/5 text-slate-500' : 'bg-white/60 border-slate-200 text-slate-500'
      }`}>
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div>
            National Scholarship Management, Verification & Fraud-Risk Assistance System &copy; 2026.
          </div>
          <div className="flex items-center gap-4">
            <span className="text-emerald-500">● Database: MySQL 8 (InnoDB)</span>
            <span>● Java 11 / Tomcat 9</span>
            <a href="/scholarship-eclipse-project.zip" download className="text-blue-400 hover:underline">
              Download WAR Project
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
