import os
import zipfile
import shutil

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def make_zip(source_dir, output_zip, prefix="scholarship"):
    with zipfile.ZipFile(output_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(source_dir):
            # Exclude unwanted directories
            dirs[:] = [d for d in dirs if d not in ('target', '.git', 'node_modules', '.DS_Store', 'dist')]
            for file in files:
                if file.endswith('.class') or file == '.DS_Store':
                    continue
                file_path = os.path.join(root, file)
                rel_path = os.path.relpath(file_path, source_dir)
                archive_name = os.path.join(prefix, rel_path) if prefix else rel_path
                zipf.write(file_path, archive_name)
    print(f"Created {output_zip} ({os.path.getsize(output_zip):,} bytes)")

if __name__ == "__main__":
    scholarship_dir = os.path.join(BASE_DIR, "scholarship")
    public_dir = os.path.join(BASE_DIR, "public")
    os.makedirs(public_dir, exist_ok=True)
    
    # 1. Main corrected project zip
    target_zip = os.path.join(public_dir, "scholarship-system-corrected.zip")
    make_zip(scholarship_dir, target_zip, prefix="scholarship")
    shutil.copy2(target_zip, os.path.join(BASE_DIR, "scholarship-system-corrected.zip"))
    
    # 2. Eclipse project zip
    eclipse_zip = os.path.join(public_dir, "scholarship-eclipse-project.zip")
    shutil.copy2(target_zip, eclipse_zip)
    shutil.copy2(target_zip, os.path.join(BASE_DIR, "scholarship-eclipse-project.zip"))
    
    # 3. Full codebase zip
    full_zip = os.path.join(public_dir, "scholarship-full-codebase.zip")
    shutil.copy2(target_zip, full_zip)
    shutil.copy2(target_zip, os.path.join(BASE_DIR, "scholarship-full-codebase.zip"))

    # Copy schema, seed, and README into public directory
    for f in ["pom.xml", "README.md", "README_ECLIPSE.md"]:
        src = os.path.join(scholarship_dir, f)
        if os.path.exists(src):
            shutil.copy2(src, os.path.join(public_dir, f))
            
    for f in ["schema.sql", "seed.sql", "db.properties"]:
        src = os.path.join(scholarship_dir, "src/main/resources", f)
        if os.path.exists(src):
            shutil.copy2(src, os.path.join(public_dir, f))

    print("Success: All zip files generated and synchronized.")
